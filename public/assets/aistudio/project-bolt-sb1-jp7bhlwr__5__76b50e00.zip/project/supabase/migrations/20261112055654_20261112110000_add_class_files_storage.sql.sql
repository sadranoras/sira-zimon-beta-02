/*
# Class files: teacher uploads for enrolled students

1. New storage
- Private bucket `class-files` (50 MB per file). Files are stored under a folder named after the class id.

2. New table
- `class_files`: id, class_id (the class), uploaded_by (defaults to the signed-in user), file_name, storage_path (unique), mime_type, size_bytes, created_at.

3. Security
- RLS enabled on `class_files` with four separate policies.
- Only the class teacher or an admin can add, rename, or delete files.
- The class teacher, enrolled students, and admins can read file records.
- Clients can write only file_name on update; uploaded_by and storage_path cannot be changed.
- Storage rules for `class-files` mirror the same rules, keyed on the class folder in the file path.
- Downloads use short-lived signed links; the bucket is never public.

4. Notes
- Each file path is `<class id>/<random id>-<file name>`, so names cannot collide between classes.
*/

INSERT INTO storage.buckets (id, name, public, file_size_limit)
VALUES ('class-files', 'class-files', false, 52428800)
ON CONFLICT (id) DO UPDATE SET public = false, file_size_limit = 52428800;

CREATE TABLE IF NOT EXISTS public.class_files (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  class_id uuid NOT NULL REFERENCES public.classes(id) ON DELETE CASCADE,
  uploaded_by uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  file_name text NOT NULL CHECK (char_length(file_name) BETWEEN 1 AND 200),
  storage_path text NOT NULL UNIQUE,
  mime_type text,
  size_bytes bigint NOT NULL CHECK (size_bytes >= 0),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS class_files_class_id_idx ON public.class_files (class_id, created_at DESC);

ALTER TABLE public.class_files ENABLE ROW LEVEL SECURITY;

REVOKE ALL ON public.class_files FROM anon, authenticated;
GRANT SELECT, DELETE ON public.class_files TO authenticated;
GRANT INSERT (class_id, file_name, storage_path, mime_type, size_bytes) ON public.class_files TO authenticated;
GRANT UPDATE (file_name) ON public.class_files TO authenticated;

DROP POLICY IF EXISTS "class_files_select_members" ON public.class_files;
CREATE POLICY "class_files_select_members" ON public.class_files FOR SELECT
TO authenticated
USING (
  public.is_admin()
  OR EXISTS (SELECT 1 FROM public.classes c WHERE c.id = class_files.class_id AND c.teacher_id = auth.uid())
  OR EXISTS (SELECT 1 FROM public.enrollments e WHERE e.class_id = class_files.class_id AND e.user_id = auth.uid())
);

DROP POLICY IF EXISTS "class_files_insert_teacher" ON public.class_files;
CREATE POLICY "class_files_insert_teacher" ON public.class_files FOR INSERT
TO authenticated
WITH CHECK (
  public.is_admin()
  OR EXISTS (SELECT 1 FROM public.classes c WHERE c.id = class_files.class_id AND c.teacher_id = auth.uid())
);

DROP POLICY IF EXISTS "class_files_update_teacher" ON public.class_files;
CREATE POLICY "class_files_update_teacher" ON public.class_files FOR UPDATE
TO authenticated
USING (
  public.is_admin()
  OR EXISTS (SELECT 1 FROM public.classes c WHERE c.id = class_files.class_id AND c.teacher_id = auth.uid())
)
WITH CHECK (
  public.is_admin()
  OR EXISTS (SELECT 1 FROM public.classes c WHERE c.id = class_files.class_id AND c.teacher_id = auth.uid())
);

DROP POLICY IF EXISTS "class_files_delete_teacher" ON public.class_files;
CREATE POLICY "class_files_delete_teacher" ON public.class_files FOR DELETE
TO authenticated
USING (
  public.is_admin()
  OR EXISTS (SELECT 1 FROM public.classes c WHERE c.id = class_files.class_id AND c.teacher_id = auth.uid())
);

DROP POLICY IF EXISTS "class_files_storage_select" ON storage.objects;
CREATE POLICY "class_files_storage_select" ON storage.objects FOR SELECT
TO authenticated
USING (
  bucket_id = 'class-files'
  AND (
    public.is_admin()
    OR EXISTS (
      SELECT 1 FROM public.classes c
      WHERE c.id::text = (storage.foldername(name))[1] AND c.teacher_id = auth.uid()
    )
    OR EXISTS (
      SELECT 1 FROM public.enrollments e
      WHERE e.class_id::text = (storage.foldername(name))[1] AND e.user_id = auth.uid()
    )
  )
);

DROP POLICY IF EXISTS "class_files_storage_insert" ON storage.objects;
CREATE POLICY "class_files_storage_insert" ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'class-files'
  AND (
    public.is_admin()
    OR EXISTS (
      SELECT 1 FROM public.classes c
      WHERE c.id::text = (storage.foldername(name))[1] AND c.teacher_id = auth.uid()
    )
  )
);

DROP POLICY IF EXISTS "class_files_storage_delete" ON storage.objects;
CREATE POLICY "class_files_storage_delete" ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'class-files'
  AND (
    public.is_admin()
    OR EXISTS (
      SELECT 1 FROM public.classes c
      WHERE c.id::text = (storage.foldername(name))[1] AND c.teacher_id = auth.uid()
    )
  )
);
