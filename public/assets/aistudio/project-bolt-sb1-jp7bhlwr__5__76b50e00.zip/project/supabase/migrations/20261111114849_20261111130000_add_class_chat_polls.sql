/*
# Add private class chat, polls, and vote results

1. New Tables
- `class_messages`: messages written inside one class by an enrolled student or the class teacher.
- `class_polls`: questions created by the teacher of a class, with an open/closed state.
- `class_poll_options`: answer choices belonging to a class poll.
- `class_poll_votes`: one answer per signed-in user for each class poll.

2. New Columns
- `class_messages.class_id`, `author_id`, `body`, `created_at` identify the class, author, content, and time.
- `class_polls.class_id`, `teacher_id`, `question`, `is_open`, `created_at` connect a poll to a class and its teacher.
- `class_poll_options.poll_id`, `label`, `position` store ordered choices.
- `class_poll_votes.poll_id`, `option_id`, `user_id`, `created_at` store one user's answer.

3. Security
- Row level security is enabled on every new table.
- Only authenticated class members, the class teacher, or an administrator can read class chat and poll content.
- A user can only write chat as themselves and can only vote in a class they attend.
- Poll creation is available only through a server-side function that verifies the caller teaches the class.
- Vote totals and percentages are returned by a server-side function after checking class access.
- Client write grants exclude author, teacher, voter, timestamps, and moderation fields.

4. Important Notes
- Poll votes use one row per user and poll, so changing an answer remains atomic.
- Existing tables are not removed or renamed.
- Class chat is added to Supabase Realtime so new messages can appear without refreshing.
*/

CREATE TABLE IF NOT EXISTS public.class_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  class_id uuid NOT NULL REFERENCES public.classes(id) ON DELETE CASCADE,
  author_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  body text NOT NULL CHECK (length(trim(body)) BETWEEN 1 AND 2000),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.class_polls (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  class_id uuid NOT NULL REFERENCES public.classes(id) ON DELETE CASCADE,
  teacher_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  question text NOT NULL CHECK (length(trim(question)) BETWEEN 1 AND 500),
  is_open boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.class_poll_options (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  poll_id uuid NOT NULL REFERENCES public.class_polls(id) ON DELETE CASCADE,
  label text NOT NULL CHECK (length(trim(label)) BETWEEN 1 AND 250),
  position smallint NOT NULL CHECK (position >= 0),
  UNIQUE (poll_id, position)
);

CREATE TABLE IF NOT EXISTS public.class_poll_votes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  poll_id uuid NOT NULL REFERENCES public.class_polls(id) ON DELETE CASCADE,
  option_id uuid NOT NULL REFERENCES public.class_poll_options(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (poll_id, user_id)
);

CREATE INDEX IF NOT EXISTS class_messages_class_created_idx ON public.class_messages(class_id, created_at);
CREATE INDEX IF NOT EXISTS class_polls_class_created_idx ON public.class_polls(class_id, created_at DESC);
CREATE INDEX IF NOT EXISTS class_poll_options_poll_position_idx ON public.class_poll_options(poll_id, position);
CREATE INDEX IF NOT EXISTS class_poll_votes_poll_idx ON public.class_poll_votes(poll_id);

ALTER TABLE public.class_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.class_polls ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.class_poll_options ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.class_poll_votes ENABLE ROW LEVEL SECURITY;

GRANT SELECT, DELETE ON public.class_messages TO authenticated;
GRANT INSERT (class_id, body) ON public.class_messages TO authenticated;
GRANT SELECT ON public.class_polls, public.class_poll_options TO authenticated;

DROP POLICY IF EXISTS "class_messages_select_members" ON public.class_messages;
CREATE POLICY "class_messages_select_members" ON public.class_messages FOR SELECT TO authenticated
USING (
  EXISTS (SELECT 1 FROM public.classes c WHERE c.id = class_messages.class_id AND c.teacher_id = auth.uid())
  OR EXISTS (SELECT 1 FROM public.enrollments e WHERE e.class_id = class_messages.class_id AND e.user_id = auth.uid())
  OR public.is_admin()
);

DROP POLICY IF EXISTS "class_messages_insert_members" ON public.class_messages;
CREATE POLICY "class_messages_insert_members" ON public.class_messages FOR INSERT TO authenticated
WITH CHECK (
  author_id = auth.uid()
  AND (
    EXISTS (SELECT 1 FROM public.classes c WHERE c.id = class_messages.class_id AND c.teacher_id = auth.uid())
    OR EXISTS (SELECT 1 FROM public.enrollments e WHERE e.class_id = class_messages.class_id AND e.user_id = auth.uid())
    OR public.is_admin()
  )
);

DROP POLICY IF EXISTS "class_messages_delete_own" ON public.class_messages;
CREATE POLICY "class_messages_delete_own" ON public.class_messages FOR DELETE TO authenticated
USING (author_id = auth.uid() OR public.is_admin());

DROP POLICY IF EXISTS "class_polls_select_members" ON public.class_polls;
CREATE POLICY "class_polls_select_members" ON public.class_polls FOR SELECT TO authenticated
USING (
  EXISTS (SELECT 1 FROM public.classes c WHERE c.id = class_polls.class_id AND c.teacher_id = auth.uid())
  OR EXISTS (SELECT 1 FROM public.enrollments e WHERE e.class_id = class_polls.class_id AND e.user_id = auth.uid())
  OR public.is_admin()
);

DROP POLICY IF EXISTS "class_poll_options_select_members" ON public.class_poll_options;
CREATE POLICY "class_poll_options_select_members" ON public.class_poll_options FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1
    FROM public.class_polls p
    WHERE p.id = class_poll_options.poll_id
      AND (
        EXISTS (SELECT 1 FROM public.classes c WHERE c.id = p.class_id AND c.teacher_id = auth.uid())
        OR EXISTS (SELECT 1 FROM public.enrollments e WHERE e.class_id = p.class_id AND e.user_id = auth.uid())
        OR public.is_admin()
      )
  )
);

CREATE OR REPLACE FUNCTION public.create_class_poll(
  p_class_id uuid,
  p_question text,
  p_options text[]
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_poll_id uuid;
  v_option text;
  v_position smallint := 0;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not_authenticated'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.classes WHERE id = p_class_id AND teacher_id = auth.uid()) AND NOT public.is_admin() THEN
    RAISE EXCEPTION 'not_allowed';
  END IF;
  IF length(trim(coalesce(p_question, ''))) < 1 OR length(p_question) > 500 THEN
    RAISE EXCEPTION 'invalid_question';
  END IF;
  IF p_options IS NULL OR coalesce(array_length(p_options, 1), 0) < 2 OR array_length(p_options, 1) > 8 THEN
    RAISE EXCEPTION 'invalid_options';
  END IF;

  INSERT INTO public.class_polls(class_id, teacher_id, question)
  VALUES (p_class_id, auth.uid(), left(trim(p_question), 500))
  RETURNING id INTO v_poll_id;

  FOREACH v_option IN ARRAY p_options LOOP
    IF length(trim(coalesce(v_option, ''))) < 1 OR length(v_option) > 250 THEN
      RAISE EXCEPTION 'invalid_options';
    END IF;
    INSERT INTO public.class_poll_options(poll_id, label, position)
    VALUES (v_poll_id, left(trim(v_option), 250), v_position);
    v_position := v_position + 1;
  END LOOP;

  RETURN v_poll_id;
END;
$$;

CREATE OR REPLACE FUNCTION public.cast_class_poll_vote(p_poll_id uuid, p_option_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_class_id uuid;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not_authenticated'; END IF;
  SELECT class_id INTO v_class_id FROM public.class_polls WHERE id = p_poll_id AND is_open = true;
  IF v_class_id IS NULL THEN RAISE EXCEPTION 'poll_closed'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.enrollments WHERE class_id = v_class_id AND user_id = auth.uid())
     AND NOT EXISTS (SELECT 1 FROM public.classes WHERE id = v_class_id AND teacher_id = auth.uid())
     AND NOT public.is_admin() THEN
    RAISE EXCEPTION 'not_allowed';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM public.class_poll_options WHERE id = p_option_id AND poll_id = p_poll_id) THEN
    RAISE EXCEPTION 'invalid_option';
  END IF;

  INSERT INTO public.class_poll_votes(poll_id, option_id, user_id)
  VALUES (p_poll_id, p_option_id, auth.uid())
  ON CONFLICT (poll_id, user_id) DO UPDATE SET option_id = excluded.option_id, created_at = now();
END;
$$;

CREATE OR REPLACE FUNCTION public.get_class_poll_results(p_class_id uuid)
RETURNS TABLE(
  poll_id uuid,
  option_id uuid,
  option_label text,
  vote_count bigint,
  total_votes bigint,
  percentage numeric
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM public.classes WHERE id = p_class_id AND teacher_id = auth.uid())
     AND NOT EXISTS (SELECT 1 FROM public.enrollments WHERE class_id = p_class_id AND user_id = auth.uid())
     AND NOT public.is_admin() THEN
    RAISE EXCEPTION 'not_allowed';
  END IF;

  RETURN QUERY
  SELECT
    p.id,
    o.id,
    o.label,
    count(v.id),
    count(v.id) OVER (PARTITION BY p.id),
    CASE WHEN count(v.id) OVER (PARTITION BY p.id) = 0 THEN 0::numeric
         ELSE round((count(v.id)::numeric * 100) / count(v.id) OVER (PARTITION BY p.id), 1)
    END
  FROM public.class_polls p
  JOIN public.class_poll_options o ON o.poll_id = p.id
  LEFT JOIN public.class_poll_votes v ON v.poll_id = p.id AND v.option_id = o.id
  WHERE p.class_id = p_class_id
  GROUP BY p.id, o.id, o.label, o.position
  ORDER BY p.created_at DESC, o.position;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.create_class_poll(uuid, text, text[]) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.create_class_poll(uuid, text, text[]) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.cast_class_poll_vote(uuid, uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.cast_class_poll_vote(uuid, uuid) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.get_class_poll_results(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_class_poll_results(uuid) TO authenticated;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime' AND schemaname = 'public' AND tablename = 'class_messages'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.class_messages;
  END IF;
END
$$;
