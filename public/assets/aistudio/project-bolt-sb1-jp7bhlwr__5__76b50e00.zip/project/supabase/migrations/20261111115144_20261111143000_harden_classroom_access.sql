/*
# Harden classroom access and poll result calculation

1. Access Changes
- Remove inherited direct Data API privileges from the four new classroom tables for anonymous and signed-in clients.
- Restore only the minimum authenticated privileges required for reading chat and polls.
- Keep poll votes inaccessible through direct table reads; votes are written and aggregated only by protected database functions.

2. Function Changes
- Rebuild `get_class_poll_results` using a grouped count and a separate total per poll.
- Percentages are calculated from the database counts and rounded to one decimal place.

3. Security Notes
- Existing row-level security policies remain in place.
- No user can assign another author, teacher, or voter identity through the client.
- The change does not delete or rename any table or column.
*/

REVOKE ALL ON public.class_messages FROM anon, authenticated;
REVOKE ALL ON public.class_polls FROM anon, authenticated;
REVOKE ALL ON public.class_poll_options FROM anon, authenticated;
REVOKE ALL ON public.class_poll_votes FROM anon, authenticated;

GRANT SELECT, DELETE ON public.class_messages TO authenticated;
GRANT INSERT (class_id, body) ON public.class_messages TO authenticated;
GRANT SELECT ON public.class_polls, public.class_poll_options TO authenticated;

CREATE OR REPLACE FUNCTION public.get_class_poll_results(p_class_id uuid)
RETURNS TABLE(
  poll_id uuid,
  option_id uuid,
  option_label text,
  vote_count bigint,
  total_votes bigint,
  percentage numeric
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM public.classes WHERE id = p_class_id AND teacher_id = auth.uid())
     AND NOT EXISTS (SELECT 1 FROM public.enrollments WHERE class_id = p_class_id AND user_id = auth.uid())
     AND NOT public.is_admin() THEN
    RAISE EXCEPTION 'not_allowed';
  END IF;

  RETURN QUERY
  WITH counts AS (
    SELECT
      p.id AS poll_id,
      o.id AS option_id,
      o.label AS option_label,
      o.position,
      count(v.id)::bigint AS vote_count,
      p.created_at
    FROM public.class_polls p
    JOIN public.class_poll_options o ON o.poll_id = p.id
    LEFT JOIN public.class_poll_votes v ON v.poll_id = p.id AND v.option_id = o.id
    WHERE p.class_id = p_class_id
    GROUP BY p.id, o.id, o.label, o.position, p.created_at
  ), totals AS (
    SELECT poll_id, sum(vote_count)::bigint AS total_votes
    FROM counts
    GROUP BY poll_id
  )
  SELECT
    counts.poll_id,
    counts.option_id,
    counts.option_label,
    counts.vote_count,
    totals.total_votes,
    CASE WHEN totals.total_votes = 0 THEN 0::numeric
         ELSE round((counts.vote_count::numeric * 100) / totals.total_votes, 1)
    END
  FROM counts
  JOIN totals ON totals.poll_id = counts.poll_id
  ORDER BY counts.created_at DESC, counts.position;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.get_class_poll_results(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_class_poll_results(uuid) TO authenticated;
