/*
# Class videos: per-session recordings and extra class videos

1. New storage
- Private bucket `class-videos` (500 MB per file, MP4 / WebM / MOV). Files are stored under a folder named after the class id.

2. New table
- `class_videos`: id, class_id (the class), session_id (optional; the session the video belongs to, empty for extra class videos), uploaded_by (defaults to the signed-in user), title, storage_path (unique), mime_type, size_bytes, created_at.
- A video linked to a session must belong to a session of the same class.

3. Security
- RLS enabled on `class_videos` with four separate policies.
- Only the class teacher or an admin can add, rename, or delete videos.
- The class teacher, enrolled students, and admins can read video records.
- Clients can write only title on update.
- Storage rules for `class-videos` mirror the same rules, keyed on the class folder in the file path.
- Playback uses short-lived signed links; the bucket is never public.

4. Notes
- Each file path is `<class id>/<random id>-<file name>`.
- Deleting a session keeps its videos and clears their session link, so they remain available as extra class videos.
*/

INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'class-videos',
  'class-videos',
  false,
  524288000,
  ARRAY['video/mp4', 'video/webm', 'video/quicktime']
)
ON CONFLICT (id) DO UPDATE SET
  public = false,
  file_size_limit = 524288000,
  allowed_mime_types = ARRAY['video/mp4', 'video/webm', 'video/quicktime'];

CREATE TABLE IF NOT EXISTS public.class_videos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  class_id uuid NOT NULL REFERENCES public.classes(id) ON DELETE CASCADE,
  session_id uuid REFERENCES public.class_sessions(id) ON DELETE SET NULL,
  uploaded_by uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL CHECK (char_length(btrim(title)) BETWEEN 1 AND 200),
  storage_path text NOT NULL UNIQUE,
  mime_type text,
  size_bytes bigint NOT NULL CHECK (size_bytes >= 0),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS class_videos_class_idx ON public.class_videos (class_id, created_at DESC);
CREATE INDEX IF NOT EXISTS class_videos_session_idx ON public.class_videos (session_id);

ALTER TABLE public.class_videos ENABLE ROW LEVEL SECURITY;

REVOKE ALL ON public.class_videos FROM anon, authenticated;
GRANT SELECT, DELETE ON public.class_videos TO authenticated;
GRANT INSERT (class_id, session_id, title, storage_path, mime_type, size_bytes) ON public.class_videos TO authenticated;
GRANT UPDATE (title) ON public.class_videos TO authenticated;

DROP POLICY IF EXISTS "class_videos_select_members" ON public.class_videos;
CREATE POLICY "class_videos_select_members" ON public.class_videos FOR SELECT
TO authenticated
USING (
  public.is_admin()
  OR EXISTS (SELECT 1 FROM public.classes c WHERE c.id = class_videos.class_id AND c.teacher_id = auth.uid())
  OR EXISTS (SELECT 1 FROM public.enrollments e WHERE e.class_id = class_videos.class_id AND e.user_id = auth.uid())
);

DROP POLICY IF EXISTS "class_videos_insert_teacher" ON public.class_videos;
CREATE POLICY "class_videos_insert_teacher" ON public.class_videos FOR INSERT
TO authenticated
WITH CHECK (
  (
    public.is_admin()
    OR EXISTS (SELECT 1 FROM public.classes c WHERE c.id = class_videos.class_id AND c.teacher_id = auth.uid())
  )
  AND (
    session_id IS NULL
    OR EXISTS (SELECT 1 FROM public.class_sessions s WHERE s.id = class_videos.session_id AND s.class_id = class_videos.class_id)
  )
);

DROP POLICY IF EXISTS "class_videos_update_teacher" ON public.class_videos;
CREATE POLICY "class_videos_update_teacher" ON public.class_videos FOR UPDATE
TO authenticated
USING (
  public.is_admin()
  OR EXISTS (SELECT 1 FROM public.classes c WHERE c.id = class_videos.class_id AND c.teacher_id = auth.uid())
)
WITH CHECK (
  public.is_admin()
  OR EXISTS (SELECT 1 FROM public.classes c WHERE c.id = class_videos.class_id AND c.teacher_id = auth.uid())
);

DROP POLICY IF EXISTS "class_videos_delete_teacher" ON public.class_videos;
CREATE POLICY "class_videos_delete_teacher" ON public.class_videos FOR DELETE
TO authenticated
USING (
  public.is_admin()
  OR EXISTS (SELECT 1 FROM public.classes c WHERE c.id = class_videos.class_id AND c.teacher_id = auth.uid())
);

DROP POLICY IF EXISTS "class_videos_storage_select" ON storage.objects;
CREATE POLICY "class_videos_storage_select" ON storage.objects FOR SELECT
TO authenticated
USING (
  bucket_id = 'class-videos'
  AND (
    public.is_admin()
    OR EXISTS (
      SELECT 1 FROM public.classes c
      WHERE c.id::text = (storage.foldername(name))[1] AND c.teacher_id = auth.uid()
    )
    OR EXISTS (
      SELECT 1 FROM public.enrollments e
      WHERE e.class_id::text = (storage.foldername(name))[1] AND e.user_id = auth.uid()
    )
  )
);

DROP POLICY IF EXISTS "class_videos_storage_insert" ON storage.objects;
CREATE POLICY "class_videos_storage_insert" ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'class-videos'
  AND (
    public.is_admin()
    OR EXISTS (
      SELECT 1 FROM public.classes c
      WHERE c.id::text = (storage.foldername(name))[1] AND c.teacher_id = auth.uid()
    )
  )
);

DROP POLICY IF EXISTS "class_videos_storage_delete" ON storage.objects;
CREATE POLICY "class_videos_storage_delete" ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'class-videos'
  AND (
    public.is_admin()
    OR EXISTS (
      SELECT 1 FROM public.classes c
      WHERE c.id::text = (storage.foldername(name))[1] AND c.teacher_id = auth.uid()
    )
  )
);
