/*
# Live class polls and poll open/close control

1. Realtime
- Adds `class_polls` and `class_poll_options` to the realtime publication so that students' and teachers' screens update when a poll is published or closed without refreshing.
- Existing realtime publication entries are kept; each table is added only if it is missing.

2. New function
- `set_class_poll_open(p_poll_id, p_is_open)` lets the class teacher (or an admin) open or close a poll.
- Closed polls reject new votes through the existing vote function.

3. Security
- `set_class_poll_open` is SECURITY DEFINER with a fixed search_path.
- It checks the caller's identity with auth.uid() and only allows the class teacher or an admin.
- EXECUTE is revoked from PUBLIC and anon and granted only to authenticated.
- No table grants or row policies are changed.

4. Notes
- Votes are still not published to realtime, because clients have no direct read access to the vote table; vote totals are refreshed by the app on a short interval.
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime' AND schemaname = 'public' AND tablename = 'class_polls'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.class_polls;
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime' AND schemaname = 'public' AND tablename = 'class_poll_options'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.class_poll_options;
  END IF;
END $$;

CREATE OR REPLACE FUNCTION public.set_class_poll_open(p_poll_id uuid, p_is_open boolean)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'not_authenticated';
  END IF;

  IF NOT EXISTS (
    SELECT 1
    FROM public.class_polls p
    JOIN public.classes c ON c.id = p.class_id
    WHERE p.id = p_poll_id
      AND (c.teacher_id = auth.uid() OR public.is_admin())
  ) THEN
    RAISE EXCEPTION 'not_allowed';
  END IF;

  UPDATE public.class_polls SET is_open = p_is_open WHERE id = p_poll_id;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.set_class_poll_open(uuid, boolean) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.set_class_poll_open(uuid, boolean) TO authenticated;
