/*
# Add class end times and a secure exam engine

1. Modified Tables
- `classes.ends_at`: optional for old classes and required by the new class form; when present it closes the live room.
- `exams.class_id`: null for a general exam, or the class that owns a class-specific exam.
- `exams.duration_minutes`: the maximum time allowed after a student starts.

2. New Tables
- `exams`: general or class-specific scheduled exams.
- `exam_questions`: ordered multiple-choice questions with private correct answers.
- `exam_attempts`: one attempt per user and exam, including start, submission, and score.
- `exam_answers`: the selected answer for each question in an attempt.

3. New Secure Functions
- `create_exam`: teachers create exams for their own classes; administrators create class or general exams.
- `start_exam`: starts one permitted attempt during the exam window.
- `get_exam_questions`: returns questions without correct answers.
- `submit_exam`: validates answers and calculates the score on the server.
- `get_exam_results`: shows submitted scores to the responsible teacher or administrator.

4. Security
- Row level security is enabled on every new table.
- Correct answers are never exposed to students.
- Students can access only general exams or exams for classes where they are enrolled.
- Student answers, attempt ownership, time limits, and scores are checked on the database server.

5. Important Notes
- Existing classes and existing exam rows, if present, are preserved.
- Existing classes without an end time continue to work; newly edited or created classes use an end time.
- No table or column is dropped or renamed.
*/

ALTER TABLE public.classes ADD COLUMN IF NOT EXISTS ends_at timestamptz;
ALTER TABLE public.classes DROP CONSTRAINT IF EXISTS classes_time_order_check;
ALTER TABLE public.classes ADD CONSTRAINT classes_time_order_check CHECK (ends_at IS NULL OR starts_at IS NULL OR ends_at > starts_at);
CREATE INDEX IF NOT EXISTS classes_ends_at_idx ON public.classes(ends_at);

CREATE OR REPLACE FUNCTION public.get_class_room(p_class_id uuid)
RETURNS text LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE v_teacher uuid; v_published boolean; v_ends_at timestamptz; v_room text;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not_authenticated'; END IF;
  SELECT c.teacher_id, c.is_published, c.ends_at INTO v_teacher, v_published, v_ends_at FROM public.classes c WHERE c.id = p_class_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'class_not_available'; END IF;
  IF v_ends_at IS NOT NULL AND now() >= v_ends_at THEN RAISE EXCEPTION 'class_ended'; END IF;
  IF NOT (public.is_admin() OR v_teacher = auth.uid() OR (v_published AND EXISTS (SELECT 1 FROM public.enrollments e WHERE e.class_id = p_class_id AND e.user_id = auth.uid()))) THEN RAISE EXCEPTION 'not_allowed'; END IF;
  INSERT INTO public.class_rooms (class_id) VALUES (p_class_id) ON CONFLICT (class_id) DO NOTHING;
  SELECT r.room_name INTO v_room FROM public.class_rooms r WHERE r.class_id = p_class_id;
  RETURN v_room;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.get_class_room(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_class_room(uuid) TO authenticated;

CREATE TABLE IF NOT EXISTS public.exams (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), title text NOT NULL, description text NOT NULL DEFAULT '',
  class_id uuid REFERENCES public.classes(id) ON DELETE CASCADE,
  exam_type text NOT NULL DEFAULT 'online' CHECK (exam_type IN ('online','in_person')),
  starts_at timestamptz NOT NULL, ends_at timestamptz NOT NULL,
  duration_minutes integer NOT NULL DEFAULT 60 CHECK (duration_minutes BETWEEN 5 AND 300),
  location text NOT NULL DEFAULT '', capacity integer CHECK (capacity IS NULL OR capacity > 0),
  is_published boolean NOT NULL DEFAULT false, created_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.exams ADD COLUMN IF NOT EXISTS class_id uuid REFERENCES public.classes(id) ON DELETE CASCADE;
ALTER TABLE public.exams ADD COLUMN IF NOT EXISTS duration_minutes integer NOT NULL DEFAULT 60 CHECK (duration_minutes BETWEEN 5 AND 300);
CREATE INDEX IF NOT EXISTS exams_starts_at_idx ON public.exams(starts_at);
CREATE INDEX IF NOT EXISTS exams_class_id_idx ON public.exams(class_id);

CREATE TABLE IF NOT EXISTS public.exam_questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), exam_id uuid NOT NULL REFERENCES public.exams(id) ON DELETE CASCADE,
  prompt text NOT NULL CHECK (length(trim(prompt)) BETWEEN 1 AND 1000),
  options jsonb NOT NULL CHECK (jsonb_typeof(options) = 'array' AND jsonb_array_length(options) BETWEEN 2 AND 6),
  correct_option smallint NOT NULL CHECK (correct_option >= 0), position smallint NOT NULL CHECK (position >= 0),
  created_at timestamptz NOT NULL DEFAULT now(), UNIQUE(exam_id, position)
);
CREATE TABLE IF NOT EXISTS public.exam_attempts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), exam_id uuid NOT NULL REFERENCES public.exams(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  started_at timestamptz NOT NULL DEFAULT now(), submitted_at timestamptz, score numeric(5,2), UNIQUE(exam_id, user_id)
);
CREATE TABLE IF NOT EXISTS public.exam_answers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), attempt_id uuid NOT NULL REFERENCES public.exam_attempts(id) ON DELETE CASCADE,
  question_id uuid NOT NULL REFERENCES public.exam_questions(id) ON DELETE CASCADE,
  selected_option smallint NOT NULL CHECK (selected_option >= 0), is_correct boolean NOT NULL DEFAULT false,
  UNIQUE(attempt_id, question_id)
);
CREATE INDEX IF NOT EXISTS exam_questions_exam_position_idx ON public.exam_questions(exam_id, position);
CREATE INDEX IF NOT EXISTS exam_attempts_exam_idx ON public.exam_attempts(exam_id, submitted_at);
CREATE INDEX IF NOT EXISTS exam_answers_attempt_idx ON public.exam_answers(attempt_id);

ALTER TABLE public.exams ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.exam_questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.exam_attempts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.exam_answers ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON public.exams TO authenticated;
REVOKE ALL ON public.exam_questions FROM anon, authenticated;
REVOKE ALL ON public.exam_attempts FROM anon, authenticated;
REVOKE ALL ON public.exam_answers FROM anon, authenticated;

DROP POLICY IF EXISTS exams_published_read ON public.exams;
DROP POLICY IF EXISTS "exams_available_read" ON public.exams;
CREATE POLICY "exams_available_read" ON public.exams FOR SELECT TO authenticated USING (
  public.is_admin()
  OR (is_published = true AND (class_id IS NULL OR EXISTS (SELECT 1 FROM public.enrollments e WHERE e.class_id = public.exams.class_id AND e.user_id = auth.uid())))
  OR EXISTS (SELECT 1 FROM public.classes c WHERE c.id = public.exams.class_id AND c.teacher_id = auth.uid())
);
DROP POLICY IF EXISTS "exams_admin_insert" ON public.exams;
CREATE POLICY "exams_admin_insert" ON public.exams FOR INSERT TO authenticated WITH CHECK (public.is_admin());
DROP POLICY IF EXISTS "exams_admin_update" ON public.exams;
CREATE POLICY "exams_admin_update" ON public.exams FOR UPDATE TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());
DROP POLICY IF EXISTS "exams_admin_delete" ON public.exams;
CREATE POLICY "exams_admin_delete" ON public.exams FOR DELETE TO authenticated USING (public.is_admin());

CREATE OR REPLACE FUNCTION public.create_exam(p_title text, p_description text, p_class_id uuid, p_starts_at timestamptz, p_ends_at timestamptz, p_duration_minutes integer, p_questions jsonb)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_exam_id uuid; v_question jsonb; v_options jsonb; v_correct integer; v_position smallint := 0;
BEGIN
  IF auth.uid() IS NULL OR NOT public.is_teacher_or_admin() THEN RAISE EXCEPTION 'not_allowed'; END IF;
  IF length(trim(coalesce(p_title, ''))) < 1 OR length(p_title) > 250 THEN RAISE EXCEPTION 'invalid_exam'; END IF;
  IF p_starts_at IS NULL OR p_ends_at IS NULL OR p_ends_at <= p_starts_at THEN RAISE EXCEPTION 'invalid_exam_window'; END IF;
  IF p_duration_minutes IS NULL OR p_duration_minutes < 5 OR p_duration_minutes > 300 THEN RAISE EXCEPTION 'invalid_duration'; END IF;
  IF p_questions IS NULL OR jsonb_typeof(p_questions) <> 'array' OR jsonb_array_length(p_questions) < 1 OR jsonb_array_length(p_questions) > 100 THEN RAISE EXCEPTION 'invalid_questions'; END IF;
  IF p_class_id IS NULL AND NOT public.is_admin() THEN RAISE EXCEPTION 'class_exam_required'; END IF;
  IF p_class_id IS NOT NULL AND NOT public.is_admin() AND NOT EXISTS (SELECT 1 FROM public.classes c WHERE c.id = p_class_id AND c.teacher_id = auth.uid()) THEN RAISE EXCEPTION 'not_allowed'; END IF;
  INSERT INTO public.exams(title, description, class_id, starts_at, ends_at, duration_minutes, is_published, created_by)
  VALUES (left(trim(p_title), 250), left(coalesce(p_description, ''), 5000), p_class_id, p_starts_at, p_ends_at, p_duration_minutes, true, auth.uid()) RETURNING id INTO v_exam_id;
  FOR v_question IN SELECT value FROM jsonb_array_elements(p_questions) LOOP
    v_options := v_question->'options';
    IF jsonb_typeof(v_options) <> 'array' OR jsonb_array_length(v_options) < 2 OR jsonb_array_length(v_options) > 6 THEN RAISE EXCEPTION 'invalid_questions'; END IF;
    IF length(trim(coalesce(v_question->>'prompt', ''))) < 1 OR length(v_question->>'prompt') > 1000 THEN RAISE EXCEPTION 'invalid_questions'; END IF;
    IF NOT (v_question ? 'correct_index') THEN RAISE EXCEPTION 'invalid_questions'; END IF;
    v_correct := (v_question->>'correct_index')::integer;
    IF v_correct < 0 OR v_correct >= jsonb_array_length(v_options) THEN RAISE EXCEPTION 'invalid_questions'; END IF;
    INSERT INTO public.exam_questions(exam_id, prompt, options, correct_option, position) VALUES (v_exam_id, left(trim(v_question->>'prompt'), 1000), v_options, v_correct, v_position);
    v_position := v_position + 1;
  END LOOP;
  RETURN v_exam_id;
END;
$$;

CREATE OR REPLACE FUNCTION public.start_exam(p_exam_id uuid)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_attempt_id uuid; v_class_id uuid;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not_authenticated'; END IF;
  SELECT e.class_id INTO v_class_id FROM public.exams e WHERE e.id = p_exam_id AND e.is_published = true AND e.starts_at <= now() AND e.ends_at > now();
  IF NOT FOUND THEN RAISE EXCEPTION 'exam_unavailable'; END IF;
  IF v_class_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM public.enrollments e WHERE e.class_id = v_class_id AND e.user_id = auth.uid()) AND NOT EXISTS (SELECT 1 FROM public.classes c WHERE c.id = v_class_id AND c.teacher_id = auth.uid()) AND NOT public.is_admin() THEN RAISE EXCEPTION 'not_allowed'; END IF;
  IF EXISTS (SELECT 1 FROM public.exam_attempts a WHERE a.exam_id = p_exam_id AND a.user_id = auth.uid() AND a.submitted_at IS NOT NULL) THEN RAISE EXCEPTION 'exam_already_submitted'; END IF;
  INSERT INTO public.exam_attempts(exam_id, user_id) VALUES (p_exam_id, auth.uid()) ON CONFLICT (exam_id, user_id) DO NOTHING;
  SELECT a.id INTO v_attempt_id FROM public.exam_attempts a WHERE a.exam_id = p_exam_id AND a.user_id = auth.uid() AND a.submitted_at IS NULL;
  RETURN v_attempt_id;
END;
$$;

CREATE OR REPLACE FUNCTION public.get_exam_questions(p_exam_id uuid)
RETURNS TABLE(exam_id uuid, title text, description text, starts_at timestamptz, ends_at timestamptz, duration_minutes integer, question_id uuid, prompt text, options jsonb, question_position smallint)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM public.exam_attempts a WHERE a.exam_id = p_exam_id AND a.user_id = auth.uid() AND a.submitted_at IS NULL) THEN RAISE EXCEPTION 'exam_not_started'; END IF;
  RETURN QUERY SELECT e.id, e.title, e.description, e.starts_at, e.ends_at, e.duration_minutes, q.id, q.prompt, q.options, q.position FROM public.exams e JOIN public.exam_questions q ON q.exam_id = e.id WHERE e.id = p_exam_id ORDER BY q.position;
END;
$$;

CREATE OR REPLACE FUNCTION public.submit_exam(p_attempt_id uuid, p_answers jsonb)
RETURNS numeric LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_exam_id uuid; v_started_at timestamptz; v_ends_at timestamptz; v_duration integer; v_answer jsonb; v_question_id uuid; v_selected integer; v_correct integer; v_total integer; v_score numeric;
BEGIN
  SELECT a.exam_id, a.started_at, e.ends_at, e.duration_minutes INTO v_exam_id, v_started_at, v_ends_at, v_duration FROM public.exam_attempts a JOIN public.exams e ON e.id = a.exam_id WHERE a.id = p_attempt_id AND a.user_id = auth.uid() AND a.submitted_at IS NULL;
  IF NOT FOUND THEN RAISE EXCEPTION 'attempt_not_available'; END IF;
  IF now() > LEAST(v_ends_at, v_started_at + make_interval(mins => v_duration)) THEN RAISE EXCEPTION 'exam_time_over'; END IF;
  IF p_answers IS NULL OR jsonb_typeof(p_answers) <> 'array' THEN RAISE EXCEPTION 'invalid_answers'; END IF;
  FOR v_answer IN SELECT value FROM jsonb_array_elements(p_answers) LOOP
    v_question_id := (v_answer->>'question_id')::uuid; v_selected := (v_answer->>'selected_option')::integer;
    SELECT q.correct_option INTO v_correct FROM public.exam_questions q WHERE q.id = v_question_id AND q.exam_id = v_exam_id;
    IF NOT FOUND OR v_selected < 0 THEN RAISE EXCEPTION 'invalid_answers'; END IF;
    INSERT INTO public.exam_answers(attempt_id, question_id, selected_option, is_correct) VALUES (p_attempt_id, v_question_id, v_selected, v_selected = v_correct) ON CONFLICT (attempt_id, question_id) DO UPDATE SET selected_option = excluded.selected_option, is_correct = excluded.is_correct;
  END LOOP;
  SELECT count(*) INTO v_total FROM public.exam_questions q WHERE q.exam_id = v_exam_id;
  SELECT CASE WHEN v_total = 0 THEN 0 ELSE round((count(*) FILTER (WHERE ea.is_correct)::numeric * 100) / v_total, 2) END INTO v_score FROM public.exam_answers ea WHERE ea.attempt_id = p_attempt_id;
  UPDATE public.exam_attempts SET submitted_at = now(), score = v_score WHERE id = p_attempt_id;
  RETURN v_score;
END;
$$;

CREATE OR REPLACE FUNCTION public.get_exam_results(p_exam_id uuid)
RETURNS TABLE(attempt_id uuid, user_id uuid, full_name text, score numeric, submitted_at timestamptz)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.is_admin() AND NOT EXISTS (SELECT 1 FROM public.exams e JOIN public.classes c ON c.id = e.class_id WHERE e.id = p_exam_id AND c.teacher_id = auth.uid()) THEN RAISE EXCEPTION 'not_allowed'; END IF;
  RETURN QUERY SELECT a.id, a.user_id, coalesce(p.full_name, 'بدون نام'), a.score, a.submitted_at FROM public.exam_attempts a JOIN public.profiles p ON p.id = a.user_id WHERE a.exam_id = p_exam_id AND a.submitted_at IS NOT NULL ORDER BY a.submitted_at DESC;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.create_exam(text, text, uuid, timestamptz, timestamptz, integer, jsonb) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.create_exam(text, text, uuid, timestamptz, timestamptz, integer, jsonb) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.start_exam(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.start_exam(uuid) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.get_exam_questions(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_exam_questions(uuid) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.submit_exam(uuid, jsonb) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.submit_exam(uuid, jsonb) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.get_exam_results(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_exam_results(uuid) TO authenticated;
