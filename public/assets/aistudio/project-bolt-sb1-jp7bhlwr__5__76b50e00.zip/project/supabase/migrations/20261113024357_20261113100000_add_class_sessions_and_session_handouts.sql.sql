/*
# Class sessions and per-session handouts

1. New table
- `class_sessions`: one lesson meeting of a class. Columns: id, class_id, title, starts_at, ends_at, created_at. Each session must end after it starts.

2. Modified table
- `class_files` gets a nullable `session_id`. A handout can belong to one session of its class. Deleting a session keeps the file record and clears its session link.

3. Security
- RLS enabled on `class_sessions` with four separate policies.
- Reading sessions: admins, the class teacher, and enrolled students.
- Creating, editing, and deleting sessions: admins and the class teacher only.
- `class_files` insert policy now also requires that the chosen session belongs to the same class.
- Clients may insert `session_id` into `class_files` (added to the existing column-restricted grant).

4. Notes
- No existing data is changed or removed.
*/

CREATE TABLE IF NOT EXISTS public.class_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  class_id uuid NOT NULL REFERENCES public.classes(id) ON DELETE CASCADE,
  title text NOT NULL CHECK (char_length(btrim(title)) BETWEEN 1 AND 200),
  starts_at timestamptz NOT NULL,
  ends_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT class_sessions_window_check CHECK (ends_at > starts_at)
);

CREATE INDEX IF NOT EXISTS class_sessions_class_starts_idx ON public.class_sessions (class_id, starts_at);

ALTER TABLE public.class_sessions ENABLE ROW LEVEL SECURITY;

REVOKE ALL ON public.class_sessions FROM anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.class_sessions TO authenticated;

DROP POLICY IF EXISTS "class_sessions_select_members" ON public.class_sessions;
CREATE POLICY "class_sessions_select_members" ON public.class_sessions FOR SELECT
TO authenticated
USING (
  public.is_admin()
  OR EXISTS (SELECT 1 FROM public.classes c WHERE c.id = class_sessions.class_id AND c.teacher_id = auth.uid())
  OR EXISTS (SELECT 1 FROM public.enrollments e WHERE e.class_id = class_sessions.class_id AND e.user_id = auth.uid())
);

DROP POLICY IF EXISTS "class_sessions_insert_teacher" ON public.class_sessions;
CREATE POLICY "class_sessions_insert_teacher" ON public.class_sessions FOR INSERT
TO authenticated
WITH CHECK (
  public.is_admin()
  OR EXISTS (SELECT 1 FROM public.classes c WHERE c.id = class_sessions.class_id AND c.teacher_id = auth.uid())
);

DROP POLICY IF EXISTS "class_sessions_update_teacher" ON public.class_sessions;
CREATE POLICY "class_sessions_update_teacher" ON public.class_sessions FOR UPDATE
TO authenticated
USING (
  public.is_admin()
  OR EXISTS (SELECT 1 FROM public.classes c WHERE c.id = class_sessions.class_id AND c.teacher_id = auth.uid())
)
WITH CHECK (
  public.is_admin()
  OR EXISTS (SELECT 1 FROM public.classes c WHERE c.id = class_sessions.class_id AND c.teacher_id = auth.uid())
);

DROP POLICY IF EXISTS "class_sessions_delete_teacher" ON public.class_sessions;
CREATE POLICY "class_sessions_delete_teacher" ON public.class_sessions FOR DELETE
TO authenticated
USING (
  public.is_admin()
  OR EXISTS (SELECT 1 FROM public.classes c WHERE c.id = class_sessions.class_id AND c.teacher_id = auth.uid())
);

ALTER TABLE public.class_files ADD COLUMN IF NOT EXISTS session_id uuid REFERENCES public.class_sessions(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS class_files_session_idx ON public.class_files (session_id);

GRANT INSERT (session_id) ON public.class_files TO authenticated;

DROP POLICY IF EXISTS "class_files_insert_teacher" ON public.class_files;
CREATE POLICY "class_files_insert_teacher" ON public.class_files FOR INSERT
TO authenticated
WITH CHECK (
  (
    public.is_admin()
    OR EXISTS (SELECT 1 FROM public.classes c WHERE c.id = class_files.class_id AND c.teacher_id = auth.uid())
  )
  AND (
    session_id IS NULL
    OR EXISTS (SELECT 1 FROM public.class_sessions s WHERE s.id = class_files.session_id AND s.class_id = class_files.class_id)
  )
);
