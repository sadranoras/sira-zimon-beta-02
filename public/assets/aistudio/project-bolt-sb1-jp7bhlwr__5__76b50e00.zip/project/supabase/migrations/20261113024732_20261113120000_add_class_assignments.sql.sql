/*
# Class assignments and submissions

1. New tables
- `class_assignments`: a homework item for a class. Columns: id, class_id, title, description, due_at (optional deadline), created_by (defaults to the signed-in user), created_at.
- `class_assignment_submissions`: one answer per student per assignment. Columns: id, assignment_id, class_id, user_id (defaults to the signed-in user), body, submitted_at. A student has at most one submission per assignment.

2. Functions
- `get_class_assignment_submissions(p_class_id)`: returns every submission of a class with the student's name. Only admins and the class teacher may call it.

3. Security
- RLS enabled on both tables with four separate policies each.
- Assignments: readable by admins, the class teacher, and enrolled students. Managed by admins and the class teacher only.
- Submissions: enrolled students can create and edit their own answer; teachers and admins read answers through the function above.
- The submissions table is not readable directly by teachers, so student identities stay behind the function.

4. Notes
- No existing data is changed or removed.
*/

CREATE TABLE IF NOT EXISTS public.class_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  class_id uuid NOT NULL REFERENCES public.classes(id) ON DELETE CASCADE,
  title text NOT NULL CHECK (char_length(btrim(title)) BETWEEN 1 AND 250),
  description text NOT NULL DEFAULT '' CHECK (char_length(description) <= 5000),
  due_at timestamptz,
  created_by uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS class_assignments_class_idx ON public.class_assignments (class_id, created_at);

CREATE TABLE IF NOT EXISTS public.class_assignment_submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  assignment_id uuid NOT NULL REFERENCES public.class_assignments(id) ON DELETE CASCADE,
  class_id uuid NOT NULL REFERENCES public.classes(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  body text NOT NULL CHECK (char_length(btrim(body)) BETWEEN 1 AND 10000),
  submitted_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT class_assignment_submissions_one_per_student UNIQUE (assignment_id, user_id)
);

CREATE INDEX IF NOT EXISTS class_assignment_submissions_class_idx ON public.class_assignment_submissions (class_id);

ALTER TABLE public.class_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.class_assignment_submissions ENABLE ROW LEVEL SECURITY;

REVOKE ALL ON public.class_assignments FROM anon, authenticated;
REVOKE ALL ON public.class_assignment_submissions FROM anon, authenticated;

GRANT SELECT, INSERT, UPDATE, DELETE ON public.class_assignments TO authenticated;
GRANT SELECT, INSERT, UPDATE ON public.class_assignment_submissions TO authenticated;

DROP POLICY IF EXISTS "class_assignments_select_members" ON public.class_assignments;
CREATE POLICY "class_assignments_select_members" ON public.class_assignments FOR SELECT
TO authenticated
USING (
  public.is_admin()
  OR EXISTS (SELECT 1 FROM public.classes c WHERE c.id = class_assignments.class_id AND c.teacher_id = auth.uid())
  OR EXISTS (SELECT 1 FROM public.enrollments e WHERE e.class_id = class_assignments.class_id AND e.user_id = auth.uid())
);

DROP POLICY IF EXISTS "class_assignments_insert_teacher" ON public.class_assignments;
CREATE POLICY "class_assignments_insert_teacher" ON public.class_assignments FOR INSERT
TO authenticated
WITH CHECK (
  public.is_admin()
  OR EXISTS (SELECT 1 FROM public.classes c WHERE c.id = class_assignments.class_id AND c.teacher_id = auth.uid())
);

DROP POLICY IF EXISTS "class_assignments_update_teacher" ON public.class_assignments;
CREATE POLICY "class_assignments_update_teacher" ON public.class_assignments FOR UPDATE
TO authenticated
USING (
  public.is_admin()
  OR EXISTS (SELECT 1 FROM public.classes c WHERE c.id = class_assignments.class_id AND c.teacher_id = auth.uid())
)
WITH CHECK (
  public.is_admin()
  OR EXISTS (SELECT 1 FROM public.classes c WHERE c.id = class_assignments.class_id AND c.teacher_id = auth.uid())
);

DROP POLICY IF EXISTS "class_assignments_delete_teacher" ON public.class_assignments;
CREATE POLICY "class_assignments_delete_teacher" ON public.class_assignments FOR DELETE
TO authenticated
USING (
  public.is_admin()
  OR EXISTS (SELECT 1 FROM public.classes c WHERE c.id = class_assignments.class_id AND c.teacher_id = auth.uid())
);

DROP POLICY IF EXISTS "class_assignment_submissions_select_own" ON public.class_assignment_submissions;
CREATE POLICY "class_assignment_submissions_select_own" ON public.class_assignment_submissions FOR SELECT
TO authenticated
USING (user_id = auth.uid());

DROP POLICY IF EXISTS "class_assignment_submissions_insert_student" ON public.class_assignment_submissions;
CREATE POLICY "class_assignment_submissions_insert_student" ON public.class_assignment_submissions FOR INSERT
TO authenticated
WITH CHECK (
  user_id = auth.uid()
  AND EXISTS (
    SELECT 1
    FROM public.class_assignments a
    JOIN public.enrollments e ON e.class_id = a.class_id AND e.user_id = auth.uid()
    WHERE a.id = class_assignment_submissions.assignment_id
      AND a.class_id = class_assignment_submissions.class_id
      AND (a.due_at IS NULL OR a.due_at > now())
  )
);

DROP POLICY IF EXISTS "class_assignment_submissions_update_student" ON public.class_assignment_submissions;
CREATE POLICY "class_assignment_submissions_update_student" ON public.class_assignment_submissions FOR UPDATE
TO authenticated
USING (
  user_id = auth.uid()
  AND EXISTS (
    SELECT 1 FROM public.class_assignments a
    WHERE a.id = class_assignment_submissions.assignment_id
      AND (a.due_at IS NULL OR a.due_at > now())
  )
)
WITH CHECK (user_id = auth.uid());

CREATE OR REPLACE FUNCTION public.get_class_assignment_submissions(p_class_id uuid)
RETURNS TABLE (
  submission_id uuid,
  assignment_id uuid,
  student_user_id uuid,
  student_name text,
  body text,
  submitted_at timestamptz
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT s.id, s.assignment_id, s.user_id, COALESCE(p.full_name, ''), s.body, s.submitted_at
  FROM public.class_assignment_submissions s
  LEFT JOIN public.profiles p ON p.id = s.user_id
  WHERE s.class_id = p_class_id
    AND (
      public.is_admin()
      OR EXISTS (SELECT 1 FROM public.classes c WHERE c.id = p_class_id AND c.teacher_id = auth.uid())
    )
  ORDER BY s.submitted_at DESC;
$$;

REVOKE EXECUTE ON FUNCTION public.get_class_assignment_submissions(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_class_assignment_submissions(uuid) TO authenticated;
