import { Link } from 'react-router-dom';
import { ClassTable } from '../../components/ClassTable';
import { fetchAllEnrollments, fetchAllClasses } from '../../lib/api/admin';
import { useAsyncData } from '../../lib/useAsyncData';

export function AdminClasses() {
  const { data, error, loading, reload } = useAsyncData(
    () => Promise.all([fetchAllClasses(), fetchAllEnrollments()]),
    [],
  );

  const classes = data?.[0] ?? [];
  const enrollments = data?.[1] ?? [];
  const publishedCount = classes.filter((item) => item.is_published).length;
  const enrolledCount = (classId: string) => enrollments.filter((row) => row.class_id === classId).length;
  const metricValue = (value: number) => data ? value.toLocaleString('fa-IR') : '—';

  return (
    <>
      <header className="admin-page-heading">
        <div>
          <span className="admin-section-label">نمای کلی</span>
          <h1 className="page-title">مدیریت کلاس ها</h1>
          <p className="muted">کلاس ها را بسازید، منتشر کنید یا ویرایش کنید.</p>
        </div>
        <Link to="/admin/classes/new" className="btn btn-primary"><span aria-hidden="true">＋</span> ساخت کلاس جدید</Link>
      </header>

      <section className="admin-metrics" aria-label="آمار کلاس ها">
        <Metric icon="ک" label="همه کلاس ها" value={metricValue(classes.length)} tone="blue" />
        <Metric icon="ن" label="کلاس های منتشرشده" value={metricValue(publishedCount)} tone="green" />
        <Metric icon="ث" label="ثبت نام های کلاس ها" value={metricValue(enrollments.length)} tone="violet" />
      </section>

      <section className="card admin-list-panel">
        <header className="admin-list-heading">
          <div>
            <h2>فهرست کلاس ها</h2>
            <p className="muted small">وضعیت انتشار، ثبت نام ها و عملیات هر کلاس</p>
          </div>
          {data && <span className="admin-count-badge">{classes.length.toLocaleString('fa-IR')} کلاس</span>}
        </header>

        {loading && <p className="muted admin-state">در حال بارگذاری کلاس ها...</p>}
        {error && <div className="alert alert-error admin-state">بارگذاری کلاس ها انجام نشد: {error}</div>}
        {!loading && !error && classes.length === 0 && (
          <div className="empty-state admin-empty">هنوز کلاسی ثبت نشده است.</div>
        )}
        {classes.length > 0 && (
          <ClassTable
            classes={classes}
            editPath={(id) => `/admin/classes/${id}/edit`}
            enrolledCount={enrolledCount}
            onChanged={reload}
          />
        )}
      </section>
    </>
  );
}

function Metric({ icon, label, value, tone }: { icon: string; label: string; value: string; tone: 'blue' | 'green' | 'violet' }) {
  return (
    <article className={`card admin-metric admin-metric-${tone}`}>
      <span className="admin-metric-icon" aria-hidden="true">{icon}</span>
      <div><span className="admin-metric-label">{label}</span><strong>{value}</strong></div>
      <span className="admin-metric-caption">از داده های ثبت شده</span>
    </article>
  );
}
