import { Link, NavLink, Outlet } from 'react-router-dom';

const adminSections = [
  { to: '/admin/classes', label: 'کلاس ها', icon: 'ک' },
  { to: '/admin/categories', label: 'دسته بندی ها', icon: 'د' },
  { to: '/admin/users', label: 'کاربران', icon: 'ک' },
  { to: '/admin/exams', label: 'آزمون ها', icon: 'آ' },
];

export function AdminLayout() {
  return (
    <div className="container admin-shell">
      <header className="admin-hero card">
        <div className="admin-hero-copy">
          <span className="admin-hero-kicker">زیمون / مدیریت</span>
          <h1>پنل مدیریت</h1>
          <p>کلاس ها، دسته بندی ها، کاربران و آزمون ها را از یک جا مدیریت کنید</p>
        </div>
        <Link to="/" className="btn admin-hero-link">نمایش سایت <span aria-hidden="true">‹</span></Link>
      </header>

      <div className="admin-layout">
        <nav className="card admin-nav" aria-label="بخش های مدیریت">
          <div className="admin-nav-heading">
            <span className="admin-nav-mark" aria-hidden="true">ز</span>
            <div><strong>مدیریت سامانه</strong><span>دسترسی مدیریتی</span></div>
          </div>
          <p className="admin-nav-label">بخش های مدیریت</p>
          <div className="admin-nav-links">
            {adminSections.map((section) => (
              <NavLink key={section.to} to={section.to}>
                <span className="admin-nav-icon" aria-hidden="true">{section.icon}</span>
                <span>{section.label}</span>
                <span className="admin-nav-chevron" aria-hidden="true">‹</span>
              </NavLink>
            ))}
          </div>
          <div className="admin-nav-footnote">ابزارهای مدیریت محتوای آموزشی</div>
        </nav>

        <main className="admin-content"><Outlet /></main>
      </div>
    </div>
  );
}
