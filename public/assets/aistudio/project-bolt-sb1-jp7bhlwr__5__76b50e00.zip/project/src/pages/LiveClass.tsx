import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { ClassChat } from '../components/classroom/ClassChat';
import { ClassPolls } from '../components/classroom/ClassPolls';
import { VideoRoom } from '../components/classroom/VideoRoom';
import { useAuth } from '../context/AuthContext';
import { fetchClassById, fetchClassOccurrences } from '../lib/api/catalog';
import { fetchClassRoom } from '../lib/api/live';
import type { JoinMode } from '../lib/live';
import { formatDate } from '../lib/dates';
import { isOccurrenceLive } from '../lib/schedule';
import { useAsyncData } from '../lib/useAsyncData';

const HOUR_MS = 60 * 60 * 1000;

export function LiveClass() {
  const { id = '' } = useParams();
  const { isTeacher } = useAuth();
  const backPath = isTeacher ? '/teacher' : '/panel';
  const [mode, setMode] = useState<JoinMode>('standard');
  const [now, setNow] = useState(() => Date.now());
  const [refreshKey, setRefreshKey] = useState(0);
  const classQuery = useAsyncData(() => fetchClassById(id), [id]);
  const occurrenceQuery = useAsyncData(() => fetchClassOccurrences(id, new Date(Date.now() - 8 * HOUR_MS).toISOString(), new Date(Date.now() + 8 * HOUR_MS).toISOString()), [id, refreshKey]);
  const activeOccurrence = occurrenceQuery.data?.find((occurrence) => isOccurrenceLive(occurrence, now));
  const active = Boolean(activeOccurrence);
  const roomQuery = useAsyncData(() => active ? fetchClassRoom(id) : Promise.resolve(''), [id, active, refreshKey]);

  useEffect(() => {
    const timer = window.setInterval(() => { const current = Date.now(); setNow(current); setRefreshKey(current); }, 30_000);
    return () => window.clearInterval(timer);
  }, []);

  if (classQuery.loading || occurrenceQuery.loading || (active && roomQuery.loading)) return <div className="page-state">در حال آماده سازی کلاس...</div>;
  if (classQuery.error || occurrenceQuery.error) return <div className="page-state alert alert-error">این کلاس برای شما در دسترس نیست یا زمان‌بندی آن بارگذاری نشد.</div>;
  const item = classQuery.data;
  if (!item) return <div className="page-state"><p>این کلاس پیدا نشد.</p><Link to={backPath} className="btn btn-outline">بازگشت</Link></div>;
  if (!activeOccurrence) {
    const next = occurrenceQuery.data?.find((occurrence) => Date.parse(occurrence.starts_at) > now);
    return <div className="page-state"><h1 className="page-title">اکنون جلسه فعالی نیست</h1><p className="muted">ورود به اتاق، چت و نظرسنجی فقط در زمان واقعی یکی از جلسه‌های مجاز فعال می‌شود.</p>{next && <p className="muted">جلسه بعدی: {formatDate(next.starts_at, next.time_zone)}</p>}<Link to={backPath} className="btn btn-primary">بازگشت به پنل</Link></div>;
  }
  if (roomQuery.error || !roomQuery.data) return <div className="page-state alert alert-error">اجازه ورود به اتاق در این زمان تأیید نشد. زمان‌بندی و ثبت‌نام کلاس را بررسی کنید.</div>;

  return <div className="container section live-class-page"><header className="section-header live-class-header"><div><div className="class-meta"><span className="badge badge-success">جلسه در حال برگزاری</span><span className="badge badge-primary">اتاق اختصاصی</span></div><h1 className="page-title">{item.title}</h1><p className="muted">استاد: {item.instructor_name || '-'} | {formatDate(activeOccurrence.starts_at, activeOccurrence.time_zone)}{activeOccurrence.ends_at ? ` تا ${formatDate(activeOccurrence.ends_at, activeOccurrence.time_zone)}` : ''}</p></div><div className="btn-row"><select className="role-select" value={mode} onChange={(event) => setMode(event.target.value as JoinMode)} aria-label="حالت اتصال"><option value="standard">تصویر و صدا</option><option value="audio">فقط صدا</option></select><Link to={backPath} className="btn btn-ghost">خروج از کلاس</Link></div></header><div className="class-live-layout"><main className="class-live-main"><VideoRoom classId={id} audioOnly={mode === 'audio'} /><ClassPolls classId={id} /></main><aside className="class-live-sidebar"><ClassChat classId={id} /></aside></div></div>;
}
