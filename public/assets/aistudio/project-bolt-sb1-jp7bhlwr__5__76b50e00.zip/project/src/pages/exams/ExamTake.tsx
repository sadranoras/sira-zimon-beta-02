import { useEffect, useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { fetchExamQuestions, startExam, submitExam, type ExamQuestion } from '../../lib/api/exams';
import { errorMessage } from '../../lib/labels';
import { useAsyncData } from '../../lib/useAsyncData';

export function ExamTake() {
  const { id = '' } = useParams();
  const query = useAsyncData(async () => { const attemptId = await startExam(id); const questions = await fetchExamQuestions(id); return { attemptId, questions }; }, [id]);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [secondsLeft, setSecondsLeft] = useState<number | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [score, setScore] = useState<number | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);
  const questions = query.data?.questions ?? [];

  const deadline = useMemo(() => {
    const first = questions[0];
    if (!first) return null;
    return Math.min(Date.parse(first.ends_at), Date.now() + first.duration_minutes * 60_000);
  }, [questions]);

  useEffect(() => {
    if (!deadline || score !== null) return;
    const update = () => setSecondsLeft(Math.max(0, Math.ceil((deadline - Date.now()) / 1000)));
    update();
    const timer = window.setInterval(update, 1000);
    return () => window.clearInterval(timer);
  }, [deadline, score]);

  useEffect(() => { if (secondsLeft === 0 && score === null && !submitting) void submit(); }, [secondsLeft]);

  const submit = async () => {
    if (!query.data || submitting || score !== null) return;
    setSubmitting(true);
    setActionError(null);
    try {
      const result = await submitExam(query.data.attemptId, Object.entries(answers).map(([question_id, selected_option]) => ({ question_id, selected_option })));
      setScore(result);
    } catch (cause) {
      setActionError(errorMessage(cause));
    } finally {
      setSubmitting(false);
    }
  };

  if (query.loading) return <div className="page-state">در حال آماده‌سازی آزمون...</div>;
  if (query.error) return <div className="page-state alert alert-error">{query.error}</div>;
  if (score !== null) return <div className="page-state"><h1 className="page-title">آزمون با موفقیت ثبت شد</h1><p className="exam-score">{score} از ۱۰۰</p><p className="muted">نتیجه آزمون برای استاد ثبت شد.</p><Link to="/panel/exams" className="btn btn-primary">بازگشت به آزمون‌ها</Link></div>;

  return <div className="container section exam-take"><header className="section-header"><div><h1 className="page-title">{questions[0]?.title ?? 'آزمون'}</h1><p className="muted">به هر سوال پاسخ دهید و در پایان آزمون را ثبت کنید.</p></div><div className="exam-timer">زمان باقی‌مانده: {formatTimer(secondsLeft ?? 0)}</div></header>{actionError && <div className="alert alert-error">{actionError}</div>}<div className="exam-question-list">{questions.map((question, index) => <QuestionCard key={question.question_id} question={question} index={index} value={answers[question.question_id]} onChange={(value) => setAnswers((current) => ({ ...current, [question.question_id]: value }))} />)}</div><button type="button" className="btn btn-primary btn-lg" onClick={() => void submit()} disabled={submitting}>{submitting ? 'در حال ثبت پاسخ‌ها...' : 'ثبت نهایی آزمون'}</button></div>;
}

function QuestionCard({ question, index, value, onChange }: { question: ExamQuestion; index: number; value: number | undefined; onChange: (value: number) => void }) {
  return <fieldset className="card exam-take-question"><legend>سوال {index + 1}</legend><h2>{question.prompt}</h2><div className="exam-answer-list">{question.options.map((option, optionIndex) => <label className="exam-answer" key={optionIndex}><input type="radio" name={question.question_id} checked={value === optionIndex} onChange={() => onChange(optionIndex)} /><span>{option}</span></label>)}</div></fieldset>;
}

function formatTimer(seconds: number): string { const minutes = Math.floor(seconds / 60); const remainder = seconds % 60; return `${String(minutes).padStart(2, '0')}:${String(remainder).padStart(2, '0')}`; }
