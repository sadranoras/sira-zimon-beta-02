import { useState } from 'react';
import { ExamForm } from '../../components/exams/ExamForm';
import { fetchAllClasses } from '../../lib/api/admin';
import { fetchExamResults, fetchManagedExams, type ExamItem, type ExamResult } from '../../lib/api/exams';
import { fetchMyClasses } from '../../lib/api/teacher';
import { useAuth } from '../../context/AuthContext';
import { formatDate } from '../../lib/dates';
import { errorMessage } from '../../lib/labels';
import { useAsyncData } from '../../lib/useAsyncData';

export function ExamManagement({ admin = false }: { admin?: boolean }) {
  const { session } = useAuth();
  const query = useAsyncData(() => Promise.all([fetchManagedExams(), admin ? fetchAllClasses() : fetchMyClasses(session?.user.id ?? '')]), [admin, session?.user.id]);
  const [showForm, setShowForm] = useState(false);
  const [results, setResults] = useState<{ examId: string; rows: ExamResult[] } | null>(null);
  const [resultError, setResultError] = useState<string | null>(null);
  const exams = query.data?.[0] ?? [];
  const classes = (query.data?.[1] ?? []).map((item) => ({ id: item.id, title: item.title }));

  const loadResults = async (examId: string) => {
    setResultError(null);
    try { setResults({ examId, rows: await fetchExamResults(examId) }); } catch (cause) { setResultError(errorMessage(cause)); }
  };

  if (query.loading) return <p className="muted">در حال بارگذاری آزمون‌ها...</p>;
  if (query.error) return <div className="alert alert-error">بارگذاری آزمون‌ها انجام نشد.</div>;
  if (showForm) return <><header className="section-header"><div><h1 className="page-title">ساخت آزمون جدید</h1><p className="muted">آزمون با سوال‌های چهارگزینه‌ای منتشر می‌شود.</p></div></header><ExamForm classes={classes} requireClass={!admin} onSaved={() => { setShowForm(false); query.reload(); }} onCancel={() => setShowForm(false)} /></>;

  return <><header className="section-header"><div><h1 className="page-title">مدیریت آزمون‌ها</h1><p className="muted">{admin ? 'آزمون عمومی یا آزمون مخصوص یک کلاس بسازید.' : 'برای کلاس‌های خود آزمون برگزار کنید و نتیجه‌ها را ببینید.'}</p></div><button type="button" className="btn btn-primary" onClick={() => setShowForm(true)}>ساخت آزمون جدید</button></header>{resultError && <div className="alert alert-error">{resultError}</div>}{exams.length === 0 && <div className="card empty-state">هنوز آزمونی نساخته‌اید.</div>}<div className="exam-list">{exams.map((exam) => <ManagedExam key={exam.id} exam={exam} results={results?.examId === exam.id ? results.rows : null} onResults={() => void loadResults(exam.id)} />)}</div></>;
}

function ManagedExam({ exam, results, onResults }: { exam: ExamItem; results: ExamResult[] | null; onResults: () => void }) {
  return <article className="card exam-list-item"><div><span className={`badge ${exam.is_published ? 'badge-success' : 'badge-muted'}`}>{exam.is_published ? 'منتشر شده' : 'پیش‌نویس'}</span><h2>{exam.title}</h2><p className="muted small">{exam.class_id ? `کلاس: ${exam.classes?.title ?? '-'}` : 'آزمون عمومی'} | {formatDate(exam.starts_at)} تا {formatDate(exam.ends_at)}</p></div><div className="btn-row"><button type="button" className="btn btn-outline btn-sm" onClick={onResults}>مشاهده نتیجه‌ها</button></div>{results && <div className="exam-results">{results.length === 0 ? <p className="muted small">هنوز پاسخی ثبت نشده است.</p> : <table className="table"><thead><tr><th>نام</th><th>نمره</th><th>زمان ثبت</th></tr></thead><tbody>{results.map((result) => <tr key={result.attempt_id}><td>{result.full_name}</td><td>{result.score}</td><td>{formatDate(result.submitted_at)}</td></tr>)}</tbody></table>}</div>}</article>;
}
