import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { fetchAvailableExams, type ExamItem } from '../../lib/api/exams';
import { formatDate } from '../../lib/dates';
import { useAsyncData } from '../../lib/useAsyncData';

export function PanelExams() {
  const { data, error, loading } = useAsyncData(fetchAvailableExams, []);
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => { const timer = window.setInterval(() => setNow(Date.now()), 30_000); return () => window.clearInterval(timer); }, []);
  const exams = data ?? [];
  return <div className="section panel-exams"><header className="section-header"><div><h1 className="page-title">آزمون ها</h1><p className="muted">آزمون‌های عمومی و آزمون‌های کلاس‌های شما در این بخش قرار می‌گیرند.</p></div></header>{loading && <p className="muted">در حال بارگذاری آزمون‌ها...</p>}{error && <div className="alert alert-error">بارگذاری آزمون‌ها انجام نشد.</div>}{!loading && !error && exams.length === 0 && <div className="card empty-state">آزمونی برای شما منتشر نشده است.</div>}<div className="exam-list">{exams.map((exam) => <ExamListItem key={exam.id} exam={exam} now={now} />)}</div></div>;
}

function ExamListItem({ exam, now }: { exam: ExamItem; now: number }) {
  const start = Date.parse(exam.starts_at);
  const end = Date.parse(exam.ends_at);
  const active = now >= start && now < end;
  const upcoming = now < start;
  return <article className="card exam-list-item"><div><span className={`badge ${active ? 'badge-success' : upcoming ? 'badge-primary' : 'badge-muted'}`}>{active ? 'در حال برگزاری' : upcoming ? 'به زودی' : 'پایان یافته'}</span><h2>{exam.title}</h2><p className="muted small">{exam.class_id ? `کلاس: ${exam.classes?.title ?? '-'}` : 'آزمون عمومی'} | شروع: {formatDate(exam.starts_at)} | پایان: {formatDate(exam.ends_at)}</p><p className="muted small">مدت پاسخ‌گویی: {exam.duration_minutes} دقیقه</p></div>{active ? <Link to={`/exams/${exam.id}/take`} className="btn btn-primary">شروع آزمون</Link> : <span className="badge badge-muted">{upcoming ? 'هنوز فعال نشده' : 'امکان ورود ندارد'}</span>}</article>;
}
