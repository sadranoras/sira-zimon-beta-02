import { Link, useParams } from 'react-router-dom';
import { ClassAssignments } from '../../components/classroom/ClassAssignments';
import { ClassVideoPanel } from '../../components/classroom/ClassVideoPanel';
import { useAuth } from '../../context/AuthContext';
import { fetchClassById } from '../../lib/api/catalog';
import { fetchAvailableExams, type ExamItem } from '../../lib/api/exams';
import { formatDate } from '../../lib/dates';
import { levelLabels } from '../../lib/labels';
import { useAsyncData } from '../../lib/useAsyncData';

export function PanelClassDetail() {
  const { id = '' } = useParams();
  const { session, isAdmin } = useAuth();
  const { data, error, loading } = useAsyncData(
    () => Promise.all([fetchClassById(id), fetchAvailableExams()]),
    [id],
  );

  if (loading) {
    return (
      <div className="panel-class-detail">
        <div className="panel-detail-loading card">در حال بارگذاری اطلاعات کلاس...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="panel-class-detail">
        <div className="alert alert-error">اطلاعات کلاس بارگذاری نشد. لطفاً دوباره تلاش کنید.</div>
      </div>
    );
  }

  const [item, exams] = data ?? [null, []];
  if (!item) {
    return (
      <div className="panel-class-detail">
        <div className="card panel-detail-empty">این کلاس پیدا نشد یا دسترسی به آن امکان‌پذیر نیست.</div>
      </div>
    );
  }

  const now = Date.now();
  const startsAt = item.starts_at ? Date.parse(item.starts_at) : null;
  const endsAt = item.ends_at ? Date.parse(item.ends_at) : null;
  const ended = endsAt !== null && now >= endsAt;
  const live = startsAt !== null && endsAt !== null && now >= startsAt && now < endsAt;
  const upcoming = startsAt !== null && now < startsAt;
  const canManage = isAdmin || item.teacher_id === session?.user.id;
  const classExams = exams.filter((exam: ExamItem) => exam.class_id === item.id);
  const examStatus = (exam: ExamItem) => {
    const start = Date.parse(exam.starts_at);
    const end = Date.parse(exam.ends_at);
    if (now >= start && now < end) return { label: 'در حال برگزاری', className: 'is-live' };
    if (now >= end) return { label: 'پایان یافته', className: 'is-ended' };
    return { label: 'پیش رو', className: 'is-upcoming' };
  };

  return (
    <div className="panel-class-detail">
      <header className="panel-class-hero">
        <div className="panel-class-hero-pattern" aria-hidden="true" />
        <div className="panel-class-hero-content">
          <div className="panel-class-hero-copy">
            <div className="panel-class-kicker">
              <span className="panel-class-kicker-dot" />
              {item.categories?.name ?? 'کلاس آموزشی'}
            </div>
            <h1>{item.title}</h1>
            <div className="panel-class-hero-meta">
              <span>مدرس: {item.instructor_name || 'مشخص نشده'}</span>
              <span className="panel-hero-separator">•</span>
              <span>سطح: {levelLabels[item.level] ?? 'مشخص نشده'}</span>
            </div>
          </div>
          <div className="panel-class-hero-action">
            {live ? (
              <Link to={`/classes/${item.id}/live`} className="panel-class-join">
                <span aria-hidden="true">▶</span>
                ورود به کلاس
              </Link>
            ) : ended ? (
              <span className="panel-class-state">کلاس به پایان رسیده</span>
            ) : upcoming ? (
              <span className="panel-class-state">کلاس هنوز شروع نشده</span>
            ) : (
              <span className="panel-class-state">زمان برگزاری مشخص نشده</span>
            )}
          </div>
        </div>
        <div className="panel-class-hero-bottom">
          <span>جزئیات و محتوای آموزشی کلاس</span>
          <Link to="/panel/classes" className="panel-class-back">بازگشت به کلاس‌ها ←</Link>
        </div>
      </header>

      {item.description?.trim() && (
        <section className="panel-detail-card panel-class-description">
          <div className="panel-detail-heading">
            <span className="panel-detail-icon icon-blue" aria-hidden="true">▤</span>
            <div>
              <h2>درباره این کلاس</h2>
              <p>توضیحات و اطلاعات کلاس</p>
            </div>
          </div>
          <p className="panel-description-text">{item.description}</p>
        </section>
      )}

      <div className="panel-class-overview-grid">
        <section className="panel-detail-card">
          <div className="panel-detail-heading">
            <span className="panel-detail-icon icon-cyan" aria-hidden="true">▣</span>
            <div>
              <h2>جلسات کلاس</h2>
              <p>زمان‌بندی برگزاری کلاس</p>
            </div>
          </div>
          <div className="panel-session-list">
            <article className="panel-session-item">
              <div className="panel-session-number">۱</div>
              <div className="panel-session-info">
                <strong>{item.title}</strong>
                <span>{formatDate(item.starts_at)}{item.ends_at ? ` تا ${formatDate(item.ends_at)}` : ''}</span>
              </div>
              <span className={`panel-status ${live ? 'is-live' : ended ? 'is-ended' : 'is-upcoming'}`}>
                {live ? 'در حال برگزاری' : ended ? 'پایان یافته' : 'پیش رو'}
              </span>
            </article>
          </div>
          <Link to={`/panel/classes/${item.id}/sessions`} className="panel-class-back">مشاهده جلسات، ویدیو و جزوه ها ←</Link>
        </section>

        <section className="panel-detail-card">
          <div className="panel-detail-heading">
            <span className="panel-detail-icon icon-purple" aria-hidden="true">▣</span>
            <div>
              <h2>آزمون‌های کلاس</h2>
              <p>آزمون‌های مرتبط با این دوره</p>
            </div>
            <span className="panel-count">{classExams.length}</span>
          </div>
          {classExams.length === 0 ? (
            <div className="panel-section-empty">
              <span aria-hidden="true">✎</span>
              <p>هنوز آزمونی برای این کلاس منتشر نشده است.</p>
            </div>
          ) : (
            <div className="panel-session-list">
              {classExams.map((exam: ExamItem) => {
                const status = examStatus(exam);
                const active = status.className === 'is-live';
                return (
                  <article className="panel-session-item" key={exam.id}>
                    <div className="panel-session-number panel-exam-number">آ</div>
                    <div className="panel-session-info">
                      <strong>{exam.title}</strong>
                      <span>{formatDate(exam.starts_at)} تا {formatDate(exam.ends_at)}</span>
                    </div>
                    <div className="panel-session-actions">
                      <span className={`panel-status ${status.className}`}>{status.label}</span>
                      {active && (
                        <Link to={`/exams/${exam.id}/take`} className="btn btn-primary btn-sm">
                          شروع آزمون
                        </Link>
                      )}
                    </div>
                  </article>
                );
              })}
            </div>
          )}
        </section>
      </div>

      <div className="panel-class-lower-grid">
        <section className="panel-detail-card panel-video-section">
          <ClassVideoPanel
            classId={item.id}
            canManage={canManage}
            heading="ویدیوهای اضافی کلاس"
            description="ویدیوهایی که خارج از جلسات مشخص برای این کلاس بارگذاری شده اند."
            emptyText="در حال حاضر ویدیوی اضافی برای این کلاس ثبت نشده است."
          />
        </section>

        <ClassAssignments classId={item.id} canManage={canManage} />
      </div>

    </div>
  );
}
