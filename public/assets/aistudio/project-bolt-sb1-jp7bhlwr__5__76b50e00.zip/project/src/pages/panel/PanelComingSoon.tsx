export function PanelComingSoon({ title }: { title: string }) {
  return (
    <section className="card empty-state panel-coming-soon">
      <h1 className="page-title">{title}</h1>
      <p className="muted">این بخش به زودی فعال می شود.</p>
    </section>
  );
}
