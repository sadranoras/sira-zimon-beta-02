import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { fetchMyEnrollments } from '../../lib/api/account';
import { formatDate } from '../../lib/dates';
import { levelLabels } from '../../lib/labels';
import type { EnrolledClass } from '../../lib/types';
import { useAsyncData } from '../../lib/useAsyncData';

const DAY_MS = 24 * 60 * 60 * 1000;

interface Session {
  enrollment: EnrolledClass;
  time: number;
}

function startOfDay(timestamp: number): number {
  const date = new Date(timestamp);
  return new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime();
}

export function toSessions(enrollments: EnrolledClass[]): Session[] {
  return enrollments
    .flatMap((enrollment) => {
      const time = enrollment.classes.starts_at ? Date.parse(enrollment.classes.starts_at) : NaN;
      return Number.isNaN(time) ? [] : [{ enrollment, time }];
    })
    .sort((a, b) => a.time - b.time);
}

export function PanelHome() {
  const { profile } = useAuth();
  const { data, error, loading } = useAsyncData(fetchMyEnrollments, []);
  const [now, setNow] = useState(() => Date.now());
  const sessions = toSessions(data ?? []);
  const todayStart = startOfDay(now);
  const todayEnd = todayStart + DAY_MS;
  const todaySessions = sessions.filter((s) => s.time >= todayStart && s.time < todayEnd);
  const upcomingSessions = sessions.filter((s) => s.time >= todayEnd);

  useEffect(() => {
    const timer = window.setInterval(() => setNow(Date.now()), 30_000);
    return () => window.clearInterval(timer);
  }, []);

  return (
    <div className="panel-home">
      <header className="section-header panel-page-heading">
        <div><h1 className="page-title">صفحه شخصی</h1><p className="muted">{profile?.full_name ? `سلام ${profile.full_name}، ` : ''}برنامه امروز شما آماده است.</p></div>
        <Link to="/panel/calendar" className="btn btn-outline">مشاهده تقویم</Link>
      </header>

      <section className="panel-welcome card">
        <div><span className="panel-eyebrow">زیمون</span><h2>عصر بخیر{profile?.full_name ? `، ${profile.full_name}` : ''}</h2><p>با تمرکز ادامه بده؛ برنامه کلاس هایت همین جاست.</p></div>
        <div className="panel-welcome-orb">ک</div>
        <div className="panel-stats">
          <div><strong>{todaySessions.length}</strong><span>کلاس امروز</span></div>
          <div><strong>{upcomingSessions.length}</strong><span>کلاس پیش رو</span></div>
          <div><strong>{sessions.length}</strong><span>کلاس ثبت نام شده</span></div>
        </div>
      </section>

      <section className="panel-quick-actions">
        <Link to="/panel/classes" className="card quick-action"><span className="quick-action-mark">ک</span><strong>کلاس های من</strong><small>مدیریت کلاس ها</small></Link>
        <Link to="/panel/calendar" className="card quick-action"><span className="quick-action-mark">ت</span><strong>تقویم برنامه ها</strong><small>برنامه هفتگی</small></Link>
        <Link to="/panel/profile" className="card quick-action"><span className="quick-action-mark">پ</span><strong>پروفایل من</strong><small>اطلاعات حساب</small></Link>
      </section>

      {loading && <p className="muted">در حال بارگذاری برنامه...</p>}
      {error && <div className="alert alert-error">بارگذاری برنامه انجام نشد.</div>}
      {!loading && !error && sessions.length === 0 && <div className="card empty-state"><p>هنوز کلاسی برای شما برنامه ریزی نشده است.</p><Link to="/classes" className="btn btn-primary">مشاهده کلاس ها</Link></div>}
      {!loading && !error && sessions.length > 0 && <><SessionGroup title="کلاس های امروز" sessions={todaySessions} now={now} emptyText="امروز کلاسی ندارید." /><SessionGroup title="کلاس های پیش رو" sessions={upcomingSessions} now={now} emptyText="کلاس پیش رویی ندارید." /></>}
    </div>
  );
}

function SessionGroup({ title, sessions, now, emptyText }: { title: string; sessions: Session[]; now: number; emptyText: string }) {
  return <section className="panel-group"><div className="panel-group-heading"><h2>{title}</h2><span className="muted small">{sessions.length} مورد</span></div>{sessions.length === 0 ? <p className="muted">{emptyText}</p> : <div className="panel-session-list">{sessions.map(({ enrollment, time }) => <SessionRow key={enrollment.id} session={{ enrollment, time }} started={time <= now} />)}</div>}</section>;
}

function SessionRow({ session, started }: { session: Session; started: boolean }) {
  const item = session.enrollment.classes;
  const ended = Boolean(item.ends_at && Date.now() >= Date.parse(item.ends_at));
  return <article className="card panel-session"><div><div className="class-meta">{item.categories && <span className="badge badge-primary">{item.categories.name}</span>}<span className="badge">{levelLabels[item.level]}</span></div><h3>{item.title}</h3><p className="muted small">استاد: {item.instructor_name || '-'} | {formatDate(item.starts_at)} تا {formatDate(item.ends_at)}</p></div>{ended ? <span className="badge badge-muted">کلاس تمام شده</span> : started ? <Link to={`/classes/${item.id}/live`} className="btn btn-primary">ورود به کلاس</Link> : <span className="badge badge-muted">ورود از زمان شروع فعال می شود</span>}</article>;
}
