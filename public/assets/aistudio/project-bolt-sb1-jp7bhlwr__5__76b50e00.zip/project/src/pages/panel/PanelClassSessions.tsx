import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { ClassFiles } from '../../components/classroom/ClassFiles';
import { ClassSessionForm } from '../../components/classroom/ClassSessionForm';
import { ClassVideoPanel } from '../../components/classroom/ClassVideoPanel';
import { useAuth } from '../../context/AuthContext';
import { fetchClassById } from '../../lib/api/catalog';
import { fetchClassSessions, type ClassSession } from '../../lib/api/classSessions';
import { formatDate } from '../../lib/dates';
import { useAsyncData } from '../../lib/useAsyncData';
import './panel-class-sessions.css';

export function PanelClassSessions() {
  const { id = '' } = useParams();
  const { session, isAdmin } = useAuth();
  const { data, error, loading, reload } = useAsyncData(
    () => Promise.all([fetchClassById(id), fetchClassSessions(id)]),
    [id],
  );
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [adding, setAdding] = useState(false);

  const item = data?.[0] ?? null;
  const sessions = data?.[1] ?? [];
  const activeId = selectedId ?? sessions[0]?.id ?? null;
  const selected = sessions.find((entry) => entry.id === activeId) ?? null;

  useEffect(() => {
    if (selectedId && !sessions.some((entry) => entry.id === selectedId)) setSelectedId(null);
  }, [sessions, selectedId]);

  if (loading) return <p className="muted">در حال بارگذاری جلسات...</p>;
  if (error) return <div className="alert alert-error">اطلاعات جلسات بارگذاری نشد.</div>;
  if (!item) return <div className="card empty-state">این کلاس پیدا نشد.</div>;

  const canManage = isAdmin || item.teacher_id === session?.user.id;

  return (
    <div className="session-page">
      <header className="session-page-header">
        <div>
          <Link to={`/panel/classes/${item.id}`} className="muted small">بازگشت به جزئیات کلاس</Link>
          <h1 className="page-title">{item.title}</h1>
        </div>
        {canManage && <button type="button" className="btn btn-primary btn-sm" onClick={() => setAdding((open) => !open)}>{adding ? 'بستن فرم' : 'افزودن جلسه'}</button>}
      </header>

      {adding && canManage && (
        <ClassSessionForm
          classId={item.id}
          onSaved={() => { setAdding(false); reload(); }}
          onCancel={() => setAdding(false)}
        />
      )}

      <div className="session-layout">
        <main className="session-main">
          {selected ? (
            <>
              <section className="card session-current">
                <span className="panel-eyebrow">جلسه انتخاب شده</span>
                <h2>{selected.title}</h2>
                <p className="muted small">{formatDate(selected.starts_at)} تا {formatDate(selected.ends_at)}</p>
                <SessionLiveAction session={selected} classId={item.id} />
              </section>
              <section className="card session-video">
                <ClassVideoPanel
                  key={selected.id}
                  classId={item.id}
                  sessionId={selected.id}
                  canManage={canManage}
                  heading="ویدیوی این جلسه"
                  description="ویدیوی ضبط شده این جلسه که استاد بارگذاری کرده است."
                  emptyText="برای این جلسه ویدیویی ثبت نشده است."
                />
              </section>
              <ClassFiles key={`files-${selected.id}`} classId={item.id} sessionId={selected.id} canManage={canManage} />
            </>
          ) : (
            <div className="card empty-state">هنوز جلسه ای برای این کلاس ثبت نشده است.</div>
          )}
        </main>

        <aside className="card session-list" aria-label="فهرست جلسات">
          <h2>فهرست جلسات</h2>
          {sessions.length === 0 && <p className="muted small">جلسه ای ثبت نشده است.</p>}
          <ul>
            {sessions.map((entry, index) => (
              <li key={entry.id}>
                <button
                  type="button"
                  className={`session-list-item ${entry.id === activeId ? 'is-active' : ''}`}
                  onClick={() => setSelectedId(entry.id)}
                  aria-pressed={entry.id === activeId}
                >
                  <span className="session-number">{index + 1}</span>
                  <span>
                    <strong>{entry.title}</strong>
                    <small className="muted">{formatDate(entry.starts_at)}</small>
                  </span>
                </button>
              </li>
            ))}
          </ul>
        </aside>
      </div>
    </div>
  );
}

function SessionLiveAction({ session, classId }: { session: ClassSession; classId: string }) {
  const now = Date.now();
  const live = now >= Date.parse(session.starts_at) && now < Date.parse(session.ends_at);
  const over = now >= Date.parse(session.ends_at);
  if (live) return <Link to={`/classes/${classId}/live`} className="btn btn-primary btn-sm">ورود به کلاس</Link>;
  if (over) return <span className="badge badge-muted">این جلسه تمام شده است</span>;
  return <span className="badge badge-primary">پیش رو</span>;
}
