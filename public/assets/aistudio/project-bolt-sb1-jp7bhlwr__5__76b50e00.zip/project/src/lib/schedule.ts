export interface ClassOccurrence {
  class_id: string;
  starts_at: string;
  ends_at: string | null;
  time_zone: string | null;
}

export function isOccurrenceLive(occurrence: ClassOccurrence, now = Date.now()): boolean {
  const start = Date.parse(occurrence.starts_at);
  const end = occurrence.ends_at ? Date.parse(occurrence.ends_at) : Number.POSITIVE_INFINITY;
  return Number.isFinite(start) && start <= now && now < end;
}

export function isOccurrenceEnded(occurrence: ClassOccurrence, now = Date.now()): boolean {
  return Boolean(occurrence.ends_at && Date.parse(occurrence.ends_at) <= now);
}
