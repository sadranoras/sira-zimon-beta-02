import { supabase } from '../supabase';
import { stageError } from '../diagnostics';
import { createStorageId } from '../storageId';
export interface ClassFile { id:string; class_id:string; file_name:string; storage_path:string; mime_type:string|null; size_bytes:number; created_at:string; }
const BUCKET='class-files';
const VIDEO_FILE_EXTENSIONS=new Set(['mp4','m4v','webm','mov','ogv','ogg','avi','mkv','mpeg','mpg','3gp']);
export function isVideoClassFile(file:Pick<ClassFile,'file_name'|'mime_type'>):boolean {
 const mime=file.mime_type?.trim().toLowerCase()??'';
 const extension=file.file_name.trim().toLowerCase().split('.').pop()??'';
 return mime.startsWith('video/')||VIDEO_FILE_EXTENSIONS.has(extension);
}
export async function fetchClassFiles(classId:string):Promise<ClassFile[]> {
 const {data,error}=await supabase.from('class_files').select('id, class_id, file_name, storage_path, mime_type, size_bytes, created_at').eq('class_id',classId).order('created_at',{ascending:false});
 if(error) throw stageError('فهرست فایل‌های کلاس',error); return (data??[]) as ClassFile[];
}
export async function uploadClassFile(classId:string,file:File,mimeTypeOverride?:string):Promise<void> {
 if(file.size===0) throw stageError('بارگذاری فایل در فضای ذخیره‌سازی',{message:'invalid_file_size'});
 const fileName=file.name.trim().slice(0,200)||'file'; const safeName=fileName.replace(/[^\w.-]+/g,'_');
 const storagePath=`${classId}/${createStorageId()}-${safeName}`; const mimeType=mimeTypeOverride??(file.type||null);
 const {error:uploadError}=await supabase.storage.from(BUCKET).upload(storagePath,file,{contentType:mimeType||'application/octet-stream'});
 if(uploadError) throw stageError('بارگذاری فایل در فضای ذخیره‌سازی',uploadError);
 const {error}=await supabase.from('class_files').insert({class_id:classId,file_name:fileName,storage_path:storagePath,mime_type:mimeType,size_bytes:file.size});
 if(error){let cleanupCause:unknown;try{const {error:cleanupError}=await supabase.storage.from(BUCKET).remove([storagePath]);cleanupCause=cleanupError;}catch(cause){cleanupCause=cause;}throw stageError('ثبت اطلاعات فایل کلاس',error,cleanupCause);}
}
export async function getClassFileUrl(storagePath:string,expiresInSeconds=300):Promise<string> {
 const {data,error}=await supabase.storage.from(BUCKET).createSignedUrl(storagePath,expiresInSeconds);
 if(error) throw stageError('دریافت لینک فایل',error); if(!data?.signedUrl) throw stageError('دریافت لینک فایل',{code:'file_url_missing'}); return data.signedUrl;
}
export async function deleteClassFile(file:ClassFile):Promise<void> {
 const {data,error}=await supabase.from('class_files').delete().eq('id',file.id).eq('class_id',file.class_id).select('id');
 if(error) throw stageError('حذف اطلاعات فایل',error); if(!data?.length) throw stageError('حذف اطلاعات فایل',{code:'not_deleted'});
 const {error:storageError}=await supabase.storage.from(BUCKET).remove([file.storage_path]); if(storageError) throw stageError('حذف فایل از فضای ذخیره‌سازی',storageError);
}
