import { supabase } from '../supabase';
import type { ClassItem, EnrolledClass, Enrollment, Profile } from '../types';
import type { ClassOccurrence } from '../schedule';

export interface ScheduledEnrollment {
  enrollment: EnrolledClass;
  occurrence: ClassOccurrence;
}

export async function fetchProfile(userId: string): Promise<Profile | null> {
  const { data, error } = await supabase.from('profiles').select('*').eq('id', userId).maybeSingle();
  if (error) throw error;
  return data as Profile | null;
}

export async function updateProfile(userId: string, values: { full_name: string; phone: string }): Promise<void> {
  const { error } = await supabase.from('profiles').update(values).eq('id', userId);
  if (error) throw error;
}

export async function fetchMyEnrollments(): Promise<EnrolledClass[]> {
  // Constrain this personal list even if an administrator's RLS can read all enrollments.
  const { data: authData, error: authError } = await supabase.auth.getUser();
  if (authError) throw authError;
  if (!authData.user) throw new Error('not_authenticated');
  const { data, error } = await supabase.from('enrollments').select('id, class_id, created_at, classes(*, categories(id, name, slug))').eq('user_id', authData.user.id).order('created_at', { ascending: false });
  if (error) throw error;
  const rows = (data ?? []) as unknown as Array<Omit<EnrolledClass, 'classes'> & { classes: ClassItem | null }>;
  return rows.filter((row): row is EnrolledClass => row.classes !== null);
}

type ScheduleLoadStage = 'enrollments' | 'occurrences';

async function withScheduleLoadStage<T>(stage: ScheduleLoadStage, load: () => Promise<T>): Promise<T> {
  try {
    return await load();
  } catch (cause) {
    const rawCode = typeof cause === 'object' && cause !== null && 'code' in cause
      ? String((cause as { code?: unknown }).code ?? '')
      : '';
    const safeCode = /^[A-Za-z0-9_-]{1,20}$/.test(rawCode) ? rawCode : 'unknown';
    // Keep backend text and request data private; retain only the safe provider error code.
    throw new Error(`schedule_${stage}_failed:${safeCode}`);
  }
}

export interface MyScheduleResult {
  enrollments: EnrolledClass[];
  sessions: ScheduledEnrollment[];
  scheduleAvailable: boolean;
}

export async function fetchMySchedule(from?: string, to?: string): Promise<MyScheduleResult> {
  const now = Date.now();
  const rangeFrom = from ?? new Date(now - 24 * 60 * 60 * 1000).toISOString();
  const rangeTo = to ?? new Date(now + 365 * 24 * 60 * 60 * 1000).toISOString();
  const [enrollments, occurrences] = await Promise.all([
    withScheduleLoadStage('enrollments', fetchMyEnrollments),
    withScheduleLoadStage('occurrences', async (): Promise<ClassOccurrence[] | null> => {
      const { data, error } = await supabase.rpc('get_my_class_occurrences', { p_from: rangeFrom, p_to: rangeTo });
      // A missing RPC only: keep enrollment data, and explicitly report that scheduling is unavailable.
      // Other errors, including access and network errors, must remain errors.
      if (error?.code === 'PGRST202') return null;
      if (error) throw error;
      return (data ?? []) as ClassOccurrence[];
    }),
  ]);
  if (occurrences === null) return { enrollments, sessions: [], scheduleAvailable: false };
  const byClass = new Map(enrollments.map((enrollment) => [enrollment.class_id, enrollment]));
  const sessions = occurrences.flatMap((occurrence) => {
    const enrollment = byClass.get(occurrence.class_id);
    return enrollment ? [{ enrollment, occurrence }] : [];
  }).sort((a, b) => Date.parse(a.occurrence.starts_at) - Date.parse(b.occurrence.starts_at));
  return { enrollments, sessions, scheduleAvailable: true };
}

export async function fetchEnrollmentForClass(classId: string): Promise<Enrollment | null> {
  const { data, error } = await supabase.from('enrollments').select('id, user_id, class_id, created_at').eq('class_id', classId).maybeSingle();
  if (error) throw error;
  return data as Enrollment | null;
}

export async function enrollInClass(classId: string): Promise<void> {
  const { error } = await supabase.rpc('enroll_in_class', { p_class_id: classId });
  if (error) throw error;
}

export async function leaveClass(enrollmentId: string): Promise<void> {
  const { error } = await supabase.from('enrollments').delete().eq('id', enrollmentId);
  if (error) throw error;
}
