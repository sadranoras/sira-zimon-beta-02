import { supabase } from '../supabase';
import { stageError } from '../diagnostics';

export interface ExamItem {
  id: string;
  title: string;
  description: string;
  class_id: string | null;
  starts_at: string;
  ends_at: string;
  duration_minutes: number;
  is_published: boolean;
  results_published: boolean;
  classes: { title: string } | null;
}

export interface ExamQuestion {
  exam_id: string;
  title: string;
  description: string;
  starts_at: string;
  ends_at: string;
  duration_minutes: number;
  question_id: string;
  prompt: string;
  options: string[];
  question_position: number;
}

export interface ExamBookletState {
  attempt_id: string;
  exam_id: string;
  title: string;
  booklet_title: string;
  booklet_position: number;
  booklet_count: number;
  started_at: string;
  expires_at: string;
  duration_minutes: number;
  timed_out: boolean;
  questions: ExamQuestion[];
}

export interface ExamResult {
  attempt_id: string;
  user_id: string;
  full_name: string;
  score: number;
  submitted_at: string;
}

export interface MyExamResult {
  exam_id: string;
  submitted: boolean;
  results_published: boolean;
  score: number | null;
  submitted_at: string;
}

export interface ExamSubmission {
  exam_complete: boolean;
  results_published: boolean;
  score: number | null;
  next_booklet_position: number | null;
  submitted_at: string | null;
}

export type AvailableExamItem = Omit<ExamItem, 'results_published'>;
const availableExamSelect = 'id, title, description, class_id, starts_at, ends_at, duration_minutes, is_published, classes(title)';
const managedExamSelect = 'id, title, description, class_id, starts_at, ends_at, duration_minutes, is_published, results_published, classes(title)';

export async function fetchAvailableExams(): Promise<AvailableExamItem[]> {
  const { data, error } = await supabase.from('exams').select(availableExamSelect).eq('is_published', true).order('starts_at', { ascending: true });
  if (error) throw stageError('فهرست آزمون‌ها', error);
  return (data ?? []) as unknown as AvailableExamItem[];
}

export async function fetchManagedExams(): Promise<ExamItem[]> {
  const { data, error } = await supabase.from('exams').select(managedExamSelect).order('starts_at', { ascending: false });
  if (error) throw stageError('فهرست آزمون‌ها', error);
  return (data ?? []) as unknown as ExamItem[];
}

export async function createExam(input: { title: string; description: string; classId: string | null; startsAt: string; endsAt: string; booklets: Array<{ title: string; duration_minutes: number; questions: Array<{ prompt: string; options: string[]; correct_index: number }> }> }): Promise<string> {
  const { data, error } = await supabase.rpc('create_exam_with_booklets', {
    p_title: input.title.trim(),
    p_description: input.description.trim(),
    p_class_id: input.classId,
    p_starts_at: input.startsAt,
    p_ends_at: input.endsAt,
    p_booklets: input.booklets,
  });
  if (error) throw error;
  if (typeof data !== 'string') throw new Error('exam_not_created');
  return data;
}

export async function setExamResultsPublished(examId: string, published: boolean): Promise<void> {
  const { error } = await supabase.rpc('set_exam_results_published', { p_exam_id: examId, p_published: published });
  if (error) throw error;
}

export async function fetchMyExamResults(): Promise<MyExamResult[]> {
  const { data, error } = await supabase.rpc('get_my_exam_results');
  if (error) throw error;
  return (data ?? []) as MyExamResult[];
}

export async function startExam(examId: string): Promise<string> {
  const { data, error } = await supabase.rpc('start_exam', { p_exam_id: examId });
  if (error) throw error;
  if (typeof data !== 'string') throw new Error('exam_not_started');
  return data;
}

export async function fetchCurrentExamBooklet(examId: string): Promise<ExamBookletState> {
  const { data, error } = await supabase.rpc('get_current_exam_booklet', { p_exam_id: examId });
  if (error) throw error;
  if (!data || typeof data !== 'object') throw new Error('exam_not_started');
  const row = data as Omit<ExamBookletState, 'questions'> & { questions?: unknown };
  const questions = Array.isArray(row.questions) ? row.questions.map((question) => {
    const item = question as ExamQuestion & { options?: unknown };
    return { ...item, options: Array.isArray(item.options) ? item.options.filter((option): option is string => typeof option === 'string') : [] };
  }) : [];
  return { ...row, questions } as ExamBookletState;
}

export async function submitExamBooklet(attemptId: string, answers: Array<{ question_id: string; selected_option: number }>): Promise<ExamSubmission> {
  const { data, error } = await supabase.rpc('submit_exam_booklet', { p_attempt_id: attemptId, p_answers: answers });
  if (error) throw error;
  if (!data || typeof data !== 'object') throw new Error('exam_not_submitted');
  return data as ExamSubmission;
}

// Backward-compatible API helpers. The database still keeps these entry points,
// but question reads are limited to the current booklet and hidden scores return null.
export async function fetchExamQuestions(examId: string): Promise<ExamQuestion[]> {
  const { data, error } = await supabase.rpc('get_exam_questions', { p_exam_id: examId });
  if (error) throw error;
  return ((data ?? []) as Array<Omit<ExamQuestion, 'options'> & { options: unknown }>).map((question) => ({
    ...question,
    options: Array.isArray(question.options) ? question.options.filter((option): option is string => typeof option === 'string') : [],
  }));
}

export async function submitExam(attemptId: string, answers: Array<{ question_id: string; selected_option: number }>): Promise<number | null> {
  const { data, error } = await supabase.rpc('submit_exam', { p_attempt_id: attemptId, p_answers: answers });
  if (error) throw error;
  if (data !== null && typeof data !== 'number') throw new Error('exam_not_submitted');
  return data;
}

export async function fetchExamResults(examId: string): Promise<ExamResult[]> {
  const { data, error } = await supabase.rpc('get_exam_results', { p_exam_id: examId });
  if (error) throw error;
  return (data ?? []) as ExamResult[];
}
