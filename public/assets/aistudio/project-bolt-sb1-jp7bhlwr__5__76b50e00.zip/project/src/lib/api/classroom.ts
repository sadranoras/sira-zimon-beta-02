import { supabase } from '../supabase';

export interface ClassMessage {
  id: string;
  class_id: string;
  author_id: string;
  body: string;
  created_at: string;
}

export interface ClassPollOption {
  id: string;
  label: string;
  position: number;
}

export interface ClassPoll {
  id: string;
  class_id: string;
  teacher_id: string;
  question: string;
  is_open: boolean;
  created_at: string;
  options: ClassPollOption[];
}

export interface ClassPollResult {
  poll_id: string;
  option_id: string;
  option_label: string;
  vote_count: number;
  total_votes: number;
  percentage: number;
}

export async function fetchClassMessages(classId: string): Promise<ClassMessage[]> {
  const { data, error } = await supabase
    .from('class_messages')
    .select('id, class_id, author_id, body, created_at')
    .eq('class_id', classId)
    .order('created_at', { ascending: true });
  if (error) throw error;
  return (data ?? []) as ClassMessage[];
}

export async function sendClassMessage(classId: string, body: string): Promise<void> {
  const { error } = await supabase.from('class_messages').insert({ class_id: classId, body: body.trim() });
  if (error) throw error;
}

export async function fetchClassPolls(classId: string): Promise<ClassPoll[]> {
  const { data, error } = await supabase
    .from('class_polls')
    .select('id, class_id, teacher_id, question, is_open, created_at, class_poll_options(id, label, position)')
    .eq('class_id', classId)
    .order('created_at', { ascending: false });
  if (error) throw error;
  return ((data ?? []) as Array<Omit<ClassPoll, 'options'> & { class_poll_options: ClassPollOption[] | null }>).map((poll) => ({
    ...poll,
    options: [...(poll.class_poll_options ?? [])].sort((a, b) => a.position - b.position),
  }));
}

export async function createClassPoll(classId: string, question: string, options: string[]): Promise<void> {
  const { error } = await supabase.rpc('create_class_poll', {
    p_class_id: classId,
    p_question: question,
    p_options: options,
  });
  if (error) throw error;
}

export async function voteInClassPoll(pollId: string, optionId: string): Promise<void> {
  const { error } = await supabase.rpc('cast_class_poll_vote', {
    p_poll_id: pollId,
    p_option_id: optionId,
  });
  if (error) throw error;
}

export async function setClassPollOpen(pollId: string, isOpen: boolean): Promise<void> {
  const { error } = await supabase.rpc('set_class_poll_open', { p_poll_id: pollId, p_is_open: isOpen });
  if (error) throw error;
}

export async function fetchClassPollResults(classId: string): Promise<ClassPollResult[]> {
  const { data, error } = await supabase.rpc('get_class_poll_results', { p_class_id: classId });
  if (error) throw error;
  return (data ?? []) as ClassPollResult[];
}
