import { supabase } from '../supabase';
import { stageError } from '../diagnostics';
import { createStorageId } from '../storageId';
const BUCKET = 'class-files';
export interface ClassAssignment { id: string; class_id: string; title: string; description: string; due_at: string | null; created_at: string; }
export interface ClassAssignmentFile { id: string; assignment_id: string; file_name: string; storage_path: string; mime_type: string | null; size_bytes: number; created_at: string; }
export interface ClassAssignmentSubmission { id: string; assignment_id: string; student_id: string; body: string; submitted_at: string; student_name?: string; file_name: string | null; storage_path: string | null; mime_type: string | null; size_bytes: number | null; }
export async function fetchClassAssignments(classId: string): Promise<ClassAssignment[]> {
  const { data, error } = await supabase.from('class_assignments').select('id, class_id, title, description, due_at, created_at').eq('class_id', classId).order('created_at', { ascending: false });
  if (error) throw stageError('فهرست تکالیف', error); return (data ?? []) as ClassAssignment[];
}
export async function fetchClassAssignmentFiles(assignmentIds: string[]): Promise<ClassAssignmentFile[]> {
  if (assignmentIds.length === 0) return [];
  const { data, error } = await supabase.from('class_assignment_files').select('id, assignment_id, file_name, storage_path, mime_type, size_bytes, created_at').in('assignment_id', assignmentIds).order('created_at', { ascending: false });
  if (error) throw stageError('فهرست فایل‌های تکلیف', error); return (data ?? []) as ClassAssignmentFile[];
}
export async function fetchMyAssignmentSubmissions(assignmentIds: string[]): Promise<ClassAssignmentSubmission[]> {
  if (assignmentIds.length === 0) return [];
  const { data, error } = await supabase.from('class_assignment_submissions').select('id, assignment_id, student_id, body, submitted_at, file_name, storage_path, mime_type, size_bytes').in('assignment_id', assignmentIds).order('submitted_at', { ascending: false });
  if (error) throw stageError('فهرست پاسخ‌ها', error); return (data ?? []) as ClassAssignmentSubmission[];
}
export async function fetchClassAssignmentSubmissions(classId: string): Promise<ClassAssignmentSubmission[]> {
  const { data, error } = await supabase.rpc('get_class_assignment_submissions_with_files', { p_class_id: classId });
  if (error) throw stageError('فهرست پاسخ‌ها', error); return (data ?? []) as ClassAssignmentSubmission[];
}
export async function createClassAssignment(input: { classId: string; title: string; description: string; dueAt: string | null; }): Promise<void> {
  const { error } = await supabase.from('class_assignments').insert({ class_id: input.classId, title: input.title.trim(), description: input.description.trim(), due_at: input.dueAt });
  if (error) throw stageError('ثبت تکلیف', error);
}
export async function submitClassAssignment(assignmentId: string, body: string): Promise<void> {
  const { error } = await supabase.rpc('submit_class_assignment', { p_assignment_id: assignmentId, p_body: body.trim() });
  if (error) throw stageError('ثبت پاسخ تکلیف', error);
}
export async function submitClassAssignmentWithFile(assignment: ClassAssignment, body: string, file: File, previousStoragePath: string | null): Promise<{ cleanupWarning: boolean }> {
  if (file.size <= 0) throw new Error('invalid_file_size');
  const fileName = normalizeFileName(file.name);
  const storagePath = `${assignment.class_id}/assignments/${assignment.id}/submissions/${await currentUserId()}/${newObjectName(fileName)}`;
  const { error: uploadError } = await supabase.storage.from(BUCKET).upload(storagePath, file, { contentType: file.type || 'application/octet-stream' });
  if (uploadError) throw stageError('بارگذاری پاسخ تکلیف', uploadError);
  const { error } = await supabase.rpc('submit_class_assignment_file', { p_assignment_id: assignment.id, p_body: body.trim(), p_storage_path: storagePath, p_file_name: fileName, p_mime_type: file.type || null, p_size_bytes: file.size });
  if (error) {
    let cleanupCause: unknown;
    try { const { error: cleanupError } = await supabase.storage.from(BUCKET).remove([storagePath]); cleanupCause = cleanupError; } catch (cleanupError) { cleanupCause = cleanupError; }
    throw stageError('ثبت پاسخ تکلیف', error, cleanupCause);
  }
  if (previousStoragePath && previousStoragePath !== storagePath) {
    const { error: cleanupError } = await supabase.storage.from(BUCKET).remove([previousStoragePath]);
    if (cleanupError) return { cleanupWarning: true };
  }
  return { cleanupWarning: false };
}
export async function uploadClassAssignmentFile(assignment: ClassAssignment, file: File): Promise<void> {
  if (file.size <= 0) throw new Error('invalid_file_size');
  const fileName = normalizeFileName(file.name);
  const storagePath = `${assignment.class_id}/assignments/${assignment.id}/attachments/${newObjectName(fileName)}`;
  const { error: uploadError } = await supabase.storage.from(BUCKET).upload(storagePath, file, { contentType: file.type || 'application/octet-stream' });
  if (uploadError) throw stageError('بارگذاری فایل تکلیف', uploadError);
  const { error } = await supabase.rpc('register_class_assignment_attachment', { p_assignment_id: assignment.id, p_storage_path: storagePath, p_file_name: fileName, p_mime_type: file.type || null, p_size_bytes: file.size });
  if (error) {
    let cleanupCause: unknown;
    try { const { error: cleanupError } = await supabase.storage.from(BUCKET).remove([storagePath]); cleanupCause = cleanupError; } catch (cleanupError) { cleanupCause = cleanupError; }
    throw stageError('ثبت فایل تکلیف', error, cleanupCause);
  }
}
export async function getClassAssignmentFileUrl(storagePath: string, expiresInSeconds = 300): Promise<string> {
  const { data, error } = await supabase.storage.from(BUCKET).createSignedUrl(storagePath, expiresInSeconds);
  if (error) throw stageError('دریافت فایل تکلیف', error); if (!data?.signedUrl) throw stageError('دریافت فایل تکلیف', { code: 'file_url_missing' }); return data.signedUrl;
}
async function currentUserId(): Promise<string> {
  const { data, error } = await supabase.auth.getUser(); if (error) throw error; if (!data.user) throw new Error('not_authenticated'); return data.user.id;
}
function normalizeFileName(originalName: string): string { return originalName.trim().slice(0, 200) || 'file'; }
function newObjectName(fileName: string): string {
  const safeName = fileName.replace(/[^\w.-]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 120) || 'file';
  return `${createStorageId()}-${safeName}`;
}
