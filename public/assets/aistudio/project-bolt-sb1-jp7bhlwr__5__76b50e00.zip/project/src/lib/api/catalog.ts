import { supabase } from '../supabase';
import type { Category, ClassItem } from '../types';
import type { ClassOccurrence } from '../schedule';

const classSelect = '*, categories(id, name, slug)';

export async function fetchCategories(): Promise<Category[]> {
  const { data, error } = await supabase.from('categories').select('*').order('name');
  if (error) throw error;
  return (data ?? []) as Category[];
}

export async function fetchPublishedClasses(): Promise<ClassItem[]> {
  const { data, error } = await supabase.from('classes').select(classSelect).eq('is_published', true).order('starts_at', { ascending: true });
  if (error) throw error;
  return (data ?? []) as unknown as ClassItem[];
}

export async function fetchClassById(id: string): Promise<ClassItem | null> {
  const { data, error } = await supabase.from('classes').select(classSelect).eq('id', id).maybeSingle();
  if (error) throw error;
  return data as unknown as ClassItem | null;
}

export async function fetchClassOccurrences(classId: string, from: string, to: string): Promise<ClassOccurrence[]> {
  const { data, error } = await supabase.rpc('get_class_occurrences', { p_class_id: classId, p_from: from, p_to: to });
  if (error) throw error;
  return (data ?? []) as ClassOccurrence[];
}

// For detail screens only: do not turn a missing RPC into a fabricated occurrence.
// LiveClass deliberately continues to use the strict fetchClassOccurrences above.
export async function fetchClassOccurrencesOptional(classId: string, from: string, to: string): Promise<{ available: boolean; occurrences: ClassOccurrence[] }> {
  try {
    return { available: true, occurrences: await fetchClassOccurrences(classId, from, to) };
  } catch (cause) {
    if (typeof cause === 'object' && cause !== null && 'code' in cause && (cause as { code?: unknown }).code === 'PGRST202') {
      return { available: false, occurrences: [] };
    }
    throw cause;
  }
}
