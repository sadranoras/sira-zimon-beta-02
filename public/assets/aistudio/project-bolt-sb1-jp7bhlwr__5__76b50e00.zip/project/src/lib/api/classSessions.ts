import { supabase } from '../supabase';

export interface ClassSession {
  id: string;
  class_id: string;
  title: string;
  starts_at: string;
  ends_at: string;
  created_at: string;
}

export async function fetchClassSessions(classId: string): Promise<ClassSession[]> {
  const { data, error } = await supabase
    .from('class_sessions')
    .select('id, class_id, title, starts_at, ends_at, created_at')
    .eq('class_id', classId)
    .order('starts_at', { ascending: true });
  if (error) throw error;
  return (data ?? []) as ClassSession[];
}

export async function createClassSession(classId: string, input: { title: string; startsAt: string; endsAt: string }): Promise<void> {
  const { error } = await supabase.from('class_sessions').insert({
    class_id: classId,
    title: input.title.trim(),
    starts_at: input.startsAt,
    ends_at: input.endsAt,
  });
  if (error) throw error;
}
