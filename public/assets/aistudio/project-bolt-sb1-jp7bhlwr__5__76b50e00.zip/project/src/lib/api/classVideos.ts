import { supabase } from '../supabase';

export interface ClassVideo {
  id: string;
  class_id: string;
  session_id: string | null;
  title: string;
  storage_path: string;
  mime_type: string | null;
  size_bytes: number;
  created_at: string;
}

export const MAX_CLASS_VIDEO_BYTES = 500 * 1024 * 1024;
export const ALLOWED_CLASS_VIDEO_TYPES = ['video/mp4', 'video/webm', 'video/quicktime'];

const BUCKET = 'class-videos';

export async function fetchClassVideos(classId: string): Promise<ClassVideo[]> {
  const { data, error } = await supabase
    .from('class_videos')
    .select('id, class_id, session_id, title, storage_path, mime_type, size_bytes, created_at')
    .eq('class_id', classId)
    .order('created_at', { ascending: false });
  if (error) throw error;
  return (data ?? []) as ClassVideo[];
}

export async function uploadClassVideo(classId: string, sessionId: string | null, title: string, file: File): Promise<void> {
  if (file.size === 0 || file.size > MAX_CLASS_VIDEO_BYTES) throw new Error('invalid_file_size');
  if (!ALLOWED_CLASS_VIDEO_TYPES.includes(file.type)) throw new Error('invalid_video_type');
  const safeName = file.name.replace(/[^\w.-]+/g, '_').slice(0, 120) || 'video';
  const storagePath = `${classId}/${crypto.randomUUID()}-${safeName}`;

  const { error: uploadError } = await supabase.storage.from(BUCKET).upload(storagePath, file, { contentType: file.type });
  if (uploadError) throw uploadError;

  const { error } = await supabase.from('class_videos').insert({
    class_id: classId,
    session_id: sessionId,
    title: title.trim(),
    storage_path: storagePath,
    mime_type: file.type,
    size_bytes: file.size,
  });
  if (error) {
    await supabase.storage.from(BUCKET).remove([storagePath]);
    throw error;
  }
}

export async function getClassVideoUrl(storagePath: string): Promise<string> {
  const { data, error } = await supabase.storage.from(BUCKET).createSignedUrl(storagePath, 3600);
  if (error) throw error;
  if (!data?.signedUrl) throw new Error('file_url_missing');
  return data.signedUrl;
}

export async function deleteClassVideo(video: ClassVideo): Promise<void> {
  const { error } = await supabase.from('class_videos').delete().eq('id', video.id);
  if (error) throw error;
  const { error: storageError } = await supabase.storage.from(BUCKET).remove([video.storage_path]);
  if (storageError) throw storageError;
}
