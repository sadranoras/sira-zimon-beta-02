// Display only short stable codes/status. Never expose raw server text, signed URLs, or credentials.
export function stageError(stage: string, cause: unknown, cleanupCause?: unknown): unknown {
  const e = typeof cause === 'object' && cause !== null ? cause as {code?:unknown;status?:unknown;statusCode?:unknown} : {};
  return {stage,code:e.code,status:e.status ?? e.statusCode,cleanupFailed:Boolean(cleanupCause),cleanupCause,cause};
}
export function safeDiagnostic(stage: string, cause: unknown): string {
  const e = typeof cause === 'object' && cause !== null ? cause as {stage?:unknown;code?:unknown;status?:unknown;statusCode?:unknown;cleanupFailed?:unknown;message?:unknown;cause?:unknown;cleanupCause?:unknown} : {};
  const stages=['ساخت شناسه امن فایل','فهرست ویدیوها','فهرست فایل‌های کلاس','بارگذاری فایل در فضای ذخیره‌سازی','ثبت اطلاعات فایل کلاس','دریافت لینک فایل','حذف اطلاعات فایل','حذف فایل از فضای ذخیره‌سازی','ثبت تکلیف','بارگذاری فایل تکلیف','ثبت فایل تکلیف','بارگذاری پاسخ تکلیف','ثبت پاسخ تکلیف','فهرست تکالیف','فهرست فایل‌های تکلیف','فهرست پاسخ‌ها','دریافت فایل تکلیف','فهرست آزمون‌ها','ثبت آزمون','فهرست جزوه‌های ویدیو','بارگذاری جزوه ویدیو','ثبت جزوه ویدیو','دریافت جزوه ویدیو','حذف جزوه ویدیو'];
  const label=typeof e.stage==='string' && stages.includes(e.stage)?e.stage:stage;
  const rawCode=typeof e.code==='string'?e.code:'';
  const code=/^(?:[0-9A-Z]{5}|PGRST[0-9]{3})$/.test(rawCode)||['EntityTooLarge','PayloadTooLarge','not_deleted','secure_random_unavailable'].includes(rawCode)?rawCode:'';
  const rs=e.status??e.statusCode; const status=(typeof rs==='number'||(typeof rs==='string'&&/^\d{3}$/.test(rs)))&&Number(rs)>=100&&Number(rs)<=599?String(rs):'';
  const details=[code?`کد: ${code}`:'',status?`HTTP: ${status}`:''].filter(Boolean).join('، ');
  const c=typeof e.cleanupCause==='object'&&e.cleanupCause!==null?e.cleanupCause as {code?:unknown;status?:unknown;statusCode?:unknown}:{};
  const cc=typeof c.code==='string'?c.code:''; const cleanupCode=/^(?:[0-9A-Z]{5}|PGRST[0-9]{3})$/.test(cc)||['EntityTooLarge','PayloadTooLarge'].includes(cc)?cc:'';
  const cs=c.status??c.statusCode; const cleanupStatus=(typeof cs==='number'||(typeof cs==='string'&&/^\d{3}$/.test(cs)))&&Number(cs)>=100&&Number(cs)<=599?String(cs):'';
  const cleanupDetails=[cleanupCode?`کد: ${cleanupCode}`:'',cleanupStatus?`HTTP: ${cleanupStatus}`:''].filter(Boolean).join('، ');
  const cleanup=e.cleanupFailed?` پاک‌سازی فایل موقت هم ناموفق بود${cleanupDetails?` (${cleanupDetails})`:''}؛ مدیر باید فایل باقی‌مانده را بررسی کند.`:'';
  const original=typeof e.cause==='object'&&e.cause!==null?e.cause as {message?:unknown}:e; const reason=typeof original.message==='string'?original.message:'';
  let hint='';
  if(reason==='not_allowed') hint=' دسترسی حساب و نقش مدرس همین کلاس بررسی شود.';
  else if(reason==='assignment_closed') hint=' مهلت تکلیف تمام شده است.';
  else if(reason==='not_authenticated') hint=' دوباره وارد حساب شوید.';
  else if(reason==='invalid_assignment') hint=' اطلاعات تکلیف را بررسی کنید.';
  else if(reason==='video_not_found') hint=' انتخاب ویدیو و کلاس مقصد بررسی شود.';
  else if(reason==='invalid_video_note') hint=' اطلاعات جزوه و شناسه ویدیوی انتخاب‌شده بررسی شود.';
  else if(reason==='video_note_object_missing') hint=' فایل در فضای جزوه‌های خصوصی پیدا نشد؛ وضعیت آپلود و پاک‌سازی بررسی شود.';
  else if(reason==='secure_random_unavailable'||code==='secure_random_unavailable') hint=' مرورگر باید از مولد امن شناسه پشتیبانی کند؛ صفحه را در مرورگر به‌روز و اتصال امن باز کنید.';
  else if(reason==='Failed to fetch') hint=' اتصال شبکه و پاسخ سرویس بررسی شود.';
  else if(code==='42703'&&label==='فهرست آزمون‌ها') hint=' این کد نام ستون مشکل‌دار را مشخص نمی‌کند. فهرست دانش‌آموز در این نسخه results_published را نمی‌خواند؛ فهرست مدیریت و RPCهای نتیجه/دفترچه هنوز به migration 20261112103000_add_exam_result_visibility_and_booklets.sql وابسته‌اند. تاریخچه، پروژهٔ متصل، schema و schema cache را بررسی کنید.';
  else if(code==='42501'||status==='403') hint=' نقش حساب و سیاست‌های RLS/Storage برای همین مسیر بررسی شود.';
  else if(status==='401') hint=' نشست ورود را تازه کنید و دوباره وارد حساب شوید.';
  else if(['بارگذاری فایل در فضای ذخیره‌سازی','ثبت اطلاعات فایل کلاس','بارگذاری جزوه ویدیو','ثبت جزوه ویدیو'].includes(label)&&status==='404') hint=' نام bucket خصوصی و پروژهٔ Supabase متصل، و migrationهای Storage در همان محیط بررسی شوند.';
  else if(['بارگذاری فایل در فضای ذخیره‌سازی','بارگذاری جزوه ویدیو'].includes(label)&&status==='400') hint=' فرمت/MIME فایل و محدودیت‌های bucket در محیط staging بررسی شوند.';
  else if(status==='413'||code==='EntityTooLarge'||code==='PayloadTooLarge') hint=' سقف bucket، طرح ذخیره‌سازی و محدودیت‌های سرویس بررسی شود.';
  else if(['42P01','42703','PGRST202','PGRST204','PGRST205'].includes(code)) hint=' ساختار داده، migrationهای محیط درست و schema cache بررسی شود.';
  else if(reason==='invalid_file_size') hint=' فایل خالی است.';
  return `${label} ناموفق بود${details?` (${details})`:' (کد فنی دریافت نشد)'}.${hint}${cleanup}`;
}
