export function formatDate(value: string | null, timeZone?: string | null): string {
  if (!value) return 'به زودی';
  const options: Intl.DateTimeFormatOptions = { dateStyle: 'medium', timeStyle: 'short' };
  if (timeZone) options.timeZone = timeZone;
  return new Intl.DateTimeFormat('fa-IR', options).format(new Date(value));
}

export function formatDay(value: string, timeZone?: string | null): string {
  const options: Intl.DateTimeFormatOptions = { dateStyle: 'medium' };
  if (timeZone) options.timeZone = timeZone;
  return new Intl.DateTimeFormat('fa-IR', options).format(new Date(value));
}

export function dateKeyInZone(value: string | number, timeZone?: string | null): string {
  const options: Intl.DateTimeFormatOptions = { year: 'numeric', month: '2-digit', day: '2-digit', calendar: 'gregory', numberingSystem: 'latn' };
  if (timeZone) options.timeZone = timeZone;
  const parts = new Intl.DateTimeFormat('en-US', options).formatToParts(new Date(value));
  const part = (type: string) => parts.find((entry) => entry.type === type)?.value ?? '';
  return `${part('year')}-${part('month')}-${part('day')}`;
}

export function toDateTimeInput(value: string | null): string {
  if (!value) return '';
  const date = new Date(value);
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

export function fromDateTimeInput(value: string): string | null {
  return value ? new Date(value).toISOString() : null;
}
