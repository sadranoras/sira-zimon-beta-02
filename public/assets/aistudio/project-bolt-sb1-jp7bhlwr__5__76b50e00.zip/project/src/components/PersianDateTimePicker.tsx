import { useState } from 'react';

// The stored value uses the same local datetime format as the original forms.
const persianParts = new Intl.DateTimeFormat('fa-IR-u-ca-persian-nu-latn', { year: 'numeric', month: 'numeric', day: 'numeric' });
const headerFormat = new Intl.DateTimeFormat('fa-IR-u-ca-persian', { year: 'numeric', month: 'long' });
const fa = (n: number) => n.toLocaleString('fa-IR');
const pad = (n: number) => String(n).padStart(2, '0');
function parts(date: Date): { year: number; month: number; day: number } {
  const p = persianParts.formatToParts(date);
  const read = (type: string) => Number(p.find((v) => v.type === type)?.value);
  return { year: read('year'), month: read('month'), day: read('day') };
}
function dayOnly(date: Date): Date { return new Date(date.getFullYear(), date.getMonth(), date.getDate(), 12); }
function moveDays(date: Date, delta: number): Date {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate() + delta, 12);
}
function firstDay(date: Date): Date {
  const p = parts(date);
  return moveDays(date, 1 - p.day);
}
function localValue(date: Date, time: string): string {
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${time}`;
}
function parseLocal(value: string): Date | null {
  if (!value) return null;
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? null : d;
}

export function PersianDateTimePicker({ value, onChange, required = false }: { value: string; onChange: (value: string) => void; required?: boolean }) {
  const selected = parseLocal(value);
  const [month, setMonth] = useState(() => firstDay(dayOnly(selected ?? new Date())));
  const first = firstDay(month);
  const firstWeekOffset = (first.getDay() + 1) % 7;
  const start = moveDays(first, -firstWeekOffset);
  const chosen = selected ? dayOnly(selected) : null;
  const chosenTime = value.includes('T') ? value.slice(11, 16) : '00:00';
  const [hour = '00', minute = '00'] = chosenTime.split(':');
  const inMonth = parts(first);
  const updateTime = (h: string, m: string) => { if (chosen) onChange(localValue(chosen, `${h}:${m}`)); };
  return <div className="persian-picker" dir="rtl">
    <div className="persian-picker-head">
      <button type="button" className="btn btn-ghost btn-sm" aria-label="ماه قبل" onClick={() => setMonth(firstDay(moveDays(first, -1)))}>‹</button>
      <strong aria-live="polite">{headerFormat.format(first)}</strong>
      <button type="button" className="btn btn-ghost btn-sm" aria-label="ماه بعد" onClick={() => setMonth(firstDay(moveDays(first, 35)))}>›</button>
    </div>
    <div className="persian-picker-grid" role="group" aria-label="روزهای ماه">
      {['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'].map((d, i) => <span className="persian-picker-weekday" key={i}>{d}</span>)}
      {Array.from({ length: 42 }, (_, i) => {
        const date = moveDays(start, i); const p = parts(date);
        const sameMonth = p.month === inMonth.month && p.year === inMonth.year;
        const isSelected = chosen?.getFullYear() === date.getFullYear() && chosen?.getMonth() === date.getMonth() && chosen?.getDate() === date.getDate();
        return <button type="button" key={i} className={`persian-picker-day ${isSelected ? 'is-selected' : ''} ${sameMonth ? '' : 'is-outside'}`} aria-pressed={Boolean(isSelected)} aria-label={new Intl.DateTimeFormat('fa-IR-u-ca-persian', { dateStyle: 'full' }).format(date)} onClick={() => { onChange(localValue(date, chosenTime)); if (!sameMonth) setMonth(firstDay(date)); }}>{fa(p.day)}</button>;
      })}
    </div>
    <div className="persian-picker-time">
      <span>{selected ? new Intl.DateTimeFormat('fa-IR-u-ca-persian', { dateStyle: 'medium' }).format(selected) : required ? 'انتخاب تاریخ الزامی است' : 'تاریخ انتخاب نشده'}</span>
      <label>ساعت <select aria-label="ساعت" value={hour} disabled={!chosen} onChange={(e) => updateTime(e.target.value, minute)}>{Array.from({ length: 24 }, (_, i) => <option value={pad(i)} key={i}>{fa(i)}</option>)}</select></label>
      <label>دقیقه <select aria-label="دقیقه" value={minute} disabled={!chosen} onChange={(e) => updateTime(hour, e.target.value)}>{Array.from({ length: 60 }, (_, i) => <option value={pad(i)} key={i}>{fa(i)}</option>)}</select></label>
      {!required && value && <button type="button" className="btn btn-ghost btn-sm" onClick={() => onChange('')}>پاک کردن</button>}
    </div>
  </div>;
}
