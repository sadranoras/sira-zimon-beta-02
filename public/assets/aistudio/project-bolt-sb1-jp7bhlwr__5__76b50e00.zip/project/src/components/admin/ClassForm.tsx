import { useState, type FormEvent } from 'react';
import { PersianDateTimePicker } from '../PersianDateTimePicker';
import { createClass, updateClass, type ClassInput } from '../../lib/api/admin';
import { fromDateTimeInput, toDateTimeInput } from '../../lib/dates';
import { classFormErrorMessage, levelLabels, levelOptions } from '../../lib/labels';
import type { Category, ClassItem, Level, ScheduleKind } from '../../lib/types';

interface ClassFormProps {
  classItem: ClassItem | null;
  categories: Category[];
  teacherId: string;
  onSaved: () => void;
  onCancel: () => void;
}

interface FormState {
  title: string;
  description: string;
  category_id: string;
  instructor_name: string;
  cover_image_url: string;
  level: Level;
  starts_at: string;
  ends_at: string;
  schedule_kind: ScheduleKind;
  schedule_start: string;
  schedule_end_date: string;
  schedule_time_zone: string;
  schedule_duration_minutes: string;
  schedule_weekdays: number[];
  capacity: string;
  is_published: boolean;
}

const weekdays = [
  { value: 6, label: 'شنبه' }, { value: 7, label: 'یکشنبه' }, { value: 1, label: 'دوشنبه' },
  { value: 2, label: 'سه شنبه' }, { value: 3, label: 'چهارشنبه' }, { value: 4, label: 'پنجشنبه' }, { value: 5, label: 'جمعه' },
];
const datePart = (value: string | null | undefined) => value ? `${value.slice(0, 10)}T12:00` : '';
const timePart = (value: string | null | undefined) => value ? value.slice(0, 5) : '';

function initialState(classItem: ClassItem | null, categories: Category[]): FormState {
  return {
    title: classItem?.title ?? '', description: classItem?.description ?? '',
    category_id: classItem?.category_id ?? categories[0]?.id ?? '',
    instructor_name: classItem?.instructor_name ?? '', cover_image_url: classItem?.cover_image_url ?? '',
    level: classItem?.level ?? 'beginner', starts_at: toDateTimeInput(classItem?.starts_at ?? null),
    ends_at: toDateTimeInput(classItem?.ends_at ?? null), schedule_kind: classItem?.schedule_kind ?? 'single',
    schedule_start: classItem?.schedule_start_date && classItem.schedule_start_time
      ? `${classItem.schedule_start_date}T${timePart(classItem.schedule_start_time)}` : '',
    schedule_end_date: datePart(classItem?.schedule_end_date), schedule_time_zone: classItem?.schedule_time_zone ?? '',
    schedule_duration_minutes: String(classItem?.schedule_duration_minutes ?? 60),
    schedule_weekdays: classItem?.schedule_weekdays ?? [], capacity: String(classItem?.capacity ?? 20),
    is_published: classItem?.is_published ?? false,
  };
}

export function ClassForm({ classItem, categories, teacherId, onSaved, onCancel }: ClassFormProps) {
  const [form, setForm] = useState<FormState>(() => initialState(classItem, categories));
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const update = <K extends keyof FormState>(key: K, value: FormState[K]) => setForm((current) => ({ ...current, [key]: value }));

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const capacity = Number(form.capacity);
    if (!Number.isInteger(capacity) || capacity < 1) { setError('ظرفیت باید عددی صحیح و بزرگ تر از صفر باشد.'); return; }
    if (!form.category_id) { setError('ابتدا یک دسته بندی بسازید و سپس کلاس را ثبت کنید.'); return; }

    let scheduleFields: Pick<ClassInput, 'starts_at' | 'ends_at' | 'schedule_kind' | 'schedule_start_date' | 'schedule_end_date' | 'schedule_start_time' | 'schedule_duration_minutes' | 'schedule_weekdays' | 'schedule_time_zone'>;
    if (form.schedule_kind === 'legacy') {
      if (!form.starts_at || !form.ends_at || new Date(form.ends_at) <= new Date(form.starts_at)) {
        setError('زمان پایان باید بعد از زمان شروع باشد.'); return;
      }
      scheduleFields = { starts_at: fromDateTimeInput(form.starts_at), ends_at: fromDateTimeInput(form.ends_at), schedule_kind: 'legacy', schedule_start_date: null, schedule_end_date: null, schedule_start_time: null, schedule_duration_minutes: null, schedule_weekdays: null, schedule_time_zone: null };
    } else {
      const [startDate, startTime] = form.schedule_start.split('T');
      const duration = Number(form.schedule_duration_minutes);
      if (!/^\d{4}-\d{2}-\d{2}$/.test(startDate ?? '') || !/^\d{2}:\d{2}$/.test(startTime ?? '')) {
        setError('تاریخ و ساعت شروع را انتخاب کنید.'); return;
      }
      if (!form.schedule_time_zone.trim()) { setError('منطقه زمانی کلاس را با شناسه IANA وارد کنید.'); return; }
      if (!Number.isInteger(duration) || duration < 5 || duration > 480) { setError('مدت جلسه باید بین ۵ تا ۴۸۰ دقیقه باشد.'); return; }
      if (form.schedule_kind === 'weekly') {
        const endDate = form.schedule_end_date.slice(0, 10);
        if (!/^\d{4}-\d{2}-\d{2}$/.test(endDate) || endDate < startDate) { setError('تاریخ پایان برنامه هفتگی باید بعد از تاریخ شروع باشد.'); return; }
        if (form.schedule_weekdays.length === 0) { setError('حداقل یک روز هفته را انتخاب کنید.'); return; }
        scheduleFields = { starts_at: null, ends_at: null, schedule_kind: 'weekly', schedule_start_date: startDate, schedule_end_date: endDate, schedule_start_time: startTime, schedule_duration_minutes: duration, schedule_weekdays: [...new Set(form.schedule_weekdays)].sort((a, b) => a - b), schedule_time_zone: form.schedule_time_zone.trim() };
      } else {
        scheduleFields = { starts_at: null, ends_at: null, schedule_kind: 'single', schedule_start_date: startDate, schedule_end_date: null, schedule_start_time: startTime, schedule_duration_minutes: duration, schedule_weekdays: null, schedule_time_zone: form.schedule_time_zone.trim() };
      }
    }

    const input: ClassInput = {
      title: form.title.trim(), description: form.description.trim(), category_id: form.category_id,
      instructor_name: form.instructor_name.trim(), cover_image_url: form.cover_image_url.trim(), level: form.level,
      ...scheduleFields, capacity, is_published: form.is_published,
    };
    setSaving(true); setError(null);
    try {
      if (classItem) await updateClass(classItem.id, input);
      else await createClass(input, teacherId);
      onSaved();
    } catch (err) { setError(classFormErrorMessage(err)); }
    finally { setSaving(false); }
  };

  const toggleWeekday = (day: number, checked: boolean) => update('schedule_weekdays', checked
    ? [...form.schedule_weekdays, day] : form.schedule_weekdays.filter((value) => value !== day));

  return (
    <form className="card form" style={{ padding: 24 }} onSubmit={handleSubmit}>
      <label className="field"><span>عنوان کلاس</span><input type="text" required value={form.title} onChange={(e) => update('title', e.target.value)} /></label>
      <label className="field"><span>توضیحات</span><textarea value={form.description} onChange={(e) => update('description', e.target.value)} /></label>
      <div className="form-grid">
        <label className="field"><span>دسته بندی</span><select required value={form.category_id} onChange={(e) => update('category_id', e.target.value)}>{categories.map((category) => <option key={category.id} value={category.id}>{category.name}</option>)}</select></label>
        <label className="field"><span>سطح</span><select value={form.level} onChange={(e) => update('level', e.target.value as Level)}>{levelOptions.map((level) => <option key={level} value={level}>{levelLabels[level]}</option>)}</select></label>
        <label className="field"><span>نام استاد</span><input type="text" value={form.instructor_name} onChange={(e) => update('instructor_name', e.target.value)} /></label>
        <label className="field"><span>ظرفیت</span><input type="number" min={1} required value={form.capacity} onChange={(e) => update('capacity', e.target.value)} /></label>
      </div>

      <label className="field"><span>نوع زمان بندی</span><select value={form.schedule_kind} onChange={(e) => update('schedule_kind', e.target.value as ScheduleKind)}>
        <option value="single">یک جلسه</option><option value="weekly">برنامه هفتگی</option>
        {classItem && <option value="legacy">زمان بندی قبلی</option>}
      </select></label>

      {form.schedule_kind === 'legacy' ? <div className="form-grid">
        <div className="field"><span>زمان شروع</span><PersianDateTimePicker required value={form.starts_at} onChange={(value) => update('starts_at', value)} /></div>
        <div className="field"><span>زمان پایان</span><PersianDateTimePicker required value={form.ends_at} onChange={(value) => update('ends_at', value)} /></div>
      </div> : <>
        <div className="form-grid">
          <div className="field"><span>{form.schedule_kind === 'weekly' ? 'شروع بازه و ساعت جلسه' : 'تاریخ و ساعت جلسه'}</span><PersianDateTimePicker required value={form.schedule_start} onChange={(value) => update('schedule_start', value)} /></div>
          {form.schedule_kind === 'weekly' && <div className="field"><span>آخرین روز برنامه</span><PersianDateTimePicker required value={form.schedule_end_date} onChange={(value) => update('schedule_end_date', value)} /></div>}
          <label className="field"><span>مدت هر جلسه، دقیقه</span><input type="number" min={5} max={480} required value={form.schedule_duration_minutes} onChange={(e) => update('schedule_duration_minutes', e.target.value)} /></label>
          <label className="field"><span>منطقه زمانی کلاس، شناسه IANA</span><input type="text" required dir="ltr" placeholder="مثلاً Asia/Tehran" value={form.schedule_time_zone} onChange={(e) => update('schedule_time_zone', e.target.value)} /></label>
        </div>
        {form.schedule_kind === 'weekly' && <fieldset className="field"><legend>روزهای برگزاری</legend><div className="form-grid">{weekdays.map((day) => <label className="checkbox-row" key={day.value}><input type="checkbox" checked={form.schedule_weekdays.includes(day.value)} onChange={(e) => toggleWeekday(day.value, e.target.checked)} /><span>{day.label}</span></label>)}</div></fieldset>}
        <p className="muted small">منطقه زمانی باید شناسه معتبر IANA باشد. ساعت واردشده بر اساس همان منطقه زمانی ذخیره و نمایش داده می‌شود.</p>
      </>}

      <label className="field"><span>آدرس تصویر کاور</span><input type="url" value={form.cover_image_url} onChange={(e) => update('cover_image_url', e.target.value)} /></label>
      <label className="checkbox-row"><input type="checkbox" checked={form.is_published} onChange={(e) => update('is_published', e.target.checked)} /><span>منتشر شود (برای کاربران قابل مشاهده باشد)</span></label>
      {error && <div className="alert alert-error">{error}</div>}
      <div className="btn-row"><button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'در حال ذخیره...' : classItem ? 'ذخیره تغییرات' : 'ایجاد کلاس'}</button><button type="button" className="btn btn-ghost" onClick={onCancel} disabled={saving}>انصراف</button></div>
    </form>
  );
}
