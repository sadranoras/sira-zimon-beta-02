import { useState, type FormEvent } from 'react';
import { PersianDateTimePicker } from '../PersianDateTimePicker';
import { createExam } from '../../lib/api/exams';
import { fromDateTimeInput } from '../../lib/dates';
import { errorMessage } from '../../lib/labels';

interface ExamClassOption { id: string; title: string }
interface QuestionDraft { prompt: string; options: string[]; correct_index: number }
interface BookletDraft { title: string; duration_minutes: string; questions: QuestionDraft[] }

function localDateTime(offsetMinutes: number): string {
  const date = new Date(Date.now() + offsetMinutes * 60_000);
  const pad = (value: number) => String(value).padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

const newQuestion = (): QuestionDraft => ({ prompt: '', options: ['', '', '', ''], correct_index: 0 });
const newBooklet = (index: number): BookletDraft => ({ title: `دفترچه ${index + 1}`, duration_minutes: '60', questions: [newQuestion()] });

export function ExamForm({ classes, requireClass, onSaved, onCancel, fixedClassId }: { classes: ExamClassOption[]; requireClass: boolean; onSaved: () => void; onCancel: () => void; fixedClassId?: string }) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [classId, setClassId] = useState(fixedClassId ?? classes[0]?.id ?? '');
  const [startsAt, setStartsAt] = useState(localDateTime(30));
  const [endsAt, setEndsAt] = useState(localDateTime(150));
  const [booklets, setBooklets] = useState<BookletDraft[]>([newBooklet(0)]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const updateBooklet = (bookletIndex: number, update: Partial<BookletDraft>) => {
    setBooklets((current) => current.map((booklet, index) => index === bookletIndex ? { ...booklet, ...update } : booklet));
  };
  const updateQuestion = (bookletIndex: number, questionIndex: number, update: Partial<QuestionDraft>) => {
    setBooklets((current) => current.map((booklet, index) => index !== bookletIndex ? booklet : {
      ...booklet, questions: booklet.questions.map((question, qIndex) => qIndex === questionIndex ? { ...question, ...update } : question),
    }));
  };
  const updateOption = (bookletIndex: number, questionIndex: number, optionIndex: number, value: string) => {
    setBooklets((current) => current.map((booklet, index) => index !== bookletIndex ? booklet : {
      ...booklet, questions: booklet.questions.map((question, qIndex) => qIndex !== questionIndex ? question : {
        ...question, options: question.options.map((option, position) => position === optionIndex ? value : option),
      }),
    }));
  };

  const importQuestions = async (file?: File) => {
    if (!file) return;
    try {
      const raw: unknown = JSON.parse(await file.text());
      if (!Array.isArray(raw) || raw.length < 1 || raw.length > 100) throw new Error('invalid');
      const clean: QuestionDraft[] = raw.map((value: unknown) => {
        if (!value || typeof value !== 'object') throw new Error('invalid');
        const q = value as { prompt?: unknown; options?: unknown; correct_index?: unknown };
        if (typeof q.prompt !== 'string' || !q.prompt.trim() || q.prompt.length > 1000 || !Array.isArray(q.options) || q.options.length < 2 || q.options.length > 6 || q.options.some((o: unknown) => typeof o !== 'string' || !o.trim()) || typeof q.correct_index !== 'number' || !Number.isInteger(q.correct_index) || q.correct_index < 0 || q.correct_index >= q.options.length) throw new Error('invalid');
        return { prompt: q.prompt, options: q.options as string[], correct_index: q.correct_index };
      });
      setBooklets((current) => current.map((booklet, index) => index === 0 ? { ...booklet, questions: clean } : booklet));
      setError(null);
    } catch { setError('فایل JSON معتبر نیست؛ نمونه راهنمای همراه پروژه را بررسی کنید.'); }
  };

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const cleanBooklets = booklets.map((booklet) => ({
      title: booklet.title.trim(),
      duration_minutes: Number(booklet.duration_minutes),
      questions: booklet.questions.map((question) => ({ ...question, prompt: question.prompt.trim(), options: question.options.map((option) => option.trim()) })),
    }));
    const questionCount = cleanBooklets.reduce((total, booklet) => total + booklet.questions.length, 0);
    if (requireClass && !classId) return setError('برای آزمون استاد، انتخاب کلاس الزامی است.');
    if (!title.trim()) return setError('عنوان آزمون را وارد کنید.');
    if (!startsAt || !endsAt || new Date(endsAt) <= new Date(startsAt)) return setError('زمان پایان آزمون باید بعد از زمان شروع باشد.');
    if (cleanBooklets.length < 1 || cleanBooklets.length > 20) return setError('تعداد دفترچه‌ها باید بین ۱ تا ۲۰ باشد.');
    if (cleanBooklets.some((booklet) => !booklet.title || !Number.isInteger(booklet.duration_minutes) || booklet.duration_minutes < 5 || booklet.duration_minutes > 300)) return setError('برای هر دفترچه عنوان و زمان ۵ تا ۳۰۰ دقیقه‌ای وارد کنید.');
    if (questionCount > 100 || cleanBooklets.some((booklet) => booklet.questions.length < 1 || booklet.questions.some((question) => !question.prompt || question.options.length < 2 || question.options.length > 6 || question.options.some((option) => !option) || question.correct_index < 0 || question.correct_index >= question.options.length))) return setError('هر دفترچه باید سوال معتبر داشته باشد؛ تعداد کل سوال‌ها حداکثر ۱۰۰ است.');

    setSaving(true);
    setError(null);
    try {
      await createExam({ title, description, classId: classId || null, startsAt: fromDateTimeInput(startsAt) ?? startsAt, endsAt: fromDateTimeInput(endsAt) ?? endsAt, booklets: cleanBooklets });
      onSaved();
    } catch (cause) {
      setError(errorMessage(cause));
    } finally {
      setSaving(false);
    }
  };

  return (
    <form className="card form exam-form" onSubmit={submit}>
      <div className="form-grid">
        <label className="field"><span>عنوان آزمون</span><input required value={title} onChange={(event) => setTitle(event.target.value)} placeholder="مثلا آزمون فصل اول" /></label>
        <label className="field"><span>کلاس مرتبط</span><select disabled={Boolean(fixedClassId)} required={requireClass} value={classId} onChange={(event) => setClassId(event.target.value)}><option value="">آزمون عمومی</option>{classes.map((item) => <option key={item.id} value={item.id}>{item.title}</option>)}</select></label>
      </div>
      <label className="field"><span>توضیحات</span><textarea value={description} onChange={(event) => setDescription(event.target.value)} placeholder="راهنمای کوتاه برای دانش‌آموزان" /></label>
      <div className="form-grid">
        <div className="field"><span>شروع آزمون</span><PersianDateTimePicker required value={startsAt} onChange={setStartsAt} /></div>
        <div className="field"><span>پایان آزمون</span><PersianDateTimePicker required value={endsAt} onChange={setEndsAt} /></div>
      </div>
      <p className="field-hint">زمان هر دفترچه جداگانه از لحظه ورود به همان دفترچه محاسبه می‌شود و سرور پایان آن را ثبت می‌کند</p>
      <label className="field"><span>بارگذاری سوال‌ها از JSON برای دفترچه اول</span><input type="file" accept=".json,application/json" onChange={(event) => { const file = event.target.files?.[0]; event.target.value = ''; void importQuestions(file); }} /><span className="field-hint">پس از بارگذاری، سوال‌ها را بررسی کنید و برای ثبت روی انتشار آزمون بزنید</span></label>
      <div className="exam-question-list">
        {booklets.map((booklet, bookletIndex) => <fieldset className="exam-question-editor" key={bookletIndex}>
          <legend>دفترچه {bookletIndex + 1}</legend>
          <div className="form-grid">
            <label className="field"><span>عنوان دفترچه</span><input required maxLength={120} value={booklet.title} onChange={(event) => updateBooklet(bookletIndex, { title: event.target.value })} /></label>
            <label className="field"><span>مدت این دفترچه، دقیقه</span><input type="number" min={5} max={300} required value={booklet.duration_minutes} onChange={(event) => updateBooklet(bookletIndex, { duration_minutes: event.target.value })} /></label>
          </div>
          {booklet.questions.map((question, questionIndex) => <fieldset className="exam-question-editor" key={questionIndex}>
            <legend>سوال {questionIndex + 1}</legend>
            <label className="field"><span>متن سوال</span><textarea required value={question.prompt} onChange={(event) => updateQuestion(bookletIndex, questionIndex, { prompt: event.target.value })} /></label>
            <div className="exam-options-editor">{question.options.map((option, optionIndex) => <div className="field" key={optionIndex}><label className="field"><span>گزینه {optionIndex + 1}</span><input required value={option} onChange={(event) => updateOption(bookletIndex, questionIndex, optionIndex, event.target.value)} /></label><label className="checkbox-row"><input type="radio" name={`correct-${bookletIndex}-${questionIndex}`} checked={question.correct_index === optionIndex} onChange={() => updateQuestion(bookletIndex, questionIndex, { correct_index: optionIndex })} /> پاسخ صحیح</label></div>)}</div>
            {booklet.questions.length > 1 && <button type="button" className="btn btn-ghost btn-sm" onClick={() => updateBooklet(bookletIndex, { questions: booklet.questions.filter((_, index) => index !== questionIndex) })}>حذف این سوال</button>}
            <button type="button" className="btn btn-outline btn-sm" onClick={() => updateBooklet(bookletIndex, { questions: [...booklet.questions, newQuestion()] })}>افزودن سوال به این دفترچه</button>
          </fieldset>)}
          {booklets.length > 1 && <button type="button" className="btn btn-ghost btn-sm" onClick={() => setBooklets((current) => current.filter((_, index) => index !== bookletIndex))}>حذف دفترچه</button>}
        </fieldset>)}
      </div>
      {error && <div className="alert alert-error">{error}</div>}
      <div className="btn-row"><button type="button" className="btn btn-outline" onClick={() => setBooklets((current) => [...current, newBooklet(current.length)])} disabled={booklets.length >= 20}>افزودن دفترچه</button><button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'در حال انتشار...' : 'انتشار آزمون'}</button><button type="button" className="btn btn-ghost" onClick={onCancel} disabled={saving}>انصراف</button></div>
    </form>
  );
}
