import { useEffect, useMemo, useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { supabase } from '../../lib/supabase';
import { createClassPoll, fetchClassPollResults, fetchClassPolls, setClassPollOpen, voteInClassPoll, type ClassPoll, type ClassPollResult } from '../../lib/api/classroom';
import { errorMessage } from '../../lib/labels';
import { useAsyncData } from '../../lib/useAsyncData';

const RESULTS_REFRESH_MS = 5000;

export function ClassPolls({ classId }: { classId: string }) {
  const { isTeacher } = useAuth();
  const pollsQuery = useAsyncData(() => fetchClassPolls(classId), [classId]);
  const resultsQuery = useAsyncData(() => fetchClassPollResults(classId), [classId]);
  const { reload: reloadPolls } = pollsQuery;
  const { reload: reloadResults } = resultsQuery;
  const [togglingPoll, setTogglingPoll] = useState<string | null>(null);

  useEffect(() => {
    const channel = supabase
      .channel(`class-polls-${classId}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'class_polls', filter: `class_id=eq.${classId}` }, () => { reloadPolls(); reloadResults(); })
      .subscribe();
    const timer = window.setInterval(reloadResults, RESULTS_REFRESH_MS);
    return () => {
      window.clearInterval(timer);
      void supabase.removeChannel(channel);
    };
  }, [classId, reloadPolls, reloadResults]);
  const [selected, setSelected] = useState<Record<string, string>>({});
  const [question, setQuestion] = useState('');
  const [options, setOptions] = useState(['', '']);
  const [saving, setSaving] = useState(false);
  const [voting, setVoting] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);

  const resultsByPoll = useMemo(() => groupResults(resultsQuery.data ?? []), [resultsQuery.data]);

  const addOption = () => {
    if (options.length < 8) setOptions((current) => [...current, '']);
  };

  const updateOption = (index: number, value: string) => {
    setOptions((current) => current.map((option, optionIndex) => optionIndex === index ? value : option));
  };

  const submitPoll = async () => {
    const cleanOptions = options.map((option) => option.trim()).filter(Boolean);
    if (!question.trim() || cleanOptions.length < 2 || saving) return;
    setSaving(true);
    setActionError(null);
    try {
      await createClassPoll(classId, question, cleanOptions);
      setQuestion('');
      setOptions(['', '']);
      pollsQuery.reload();
      resultsQuery.reload();
    } catch (cause) {
      setActionError(errorMessage(cause));
    } finally {
      setSaving(false);
    }
  };

  const togglePollOpen = async (poll: ClassPoll) => {
    if (togglingPoll) return;
    setTogglingPoll(poll.id);
    setActionError(null);
    try {
      await setClassPollOpen(poll.id, !poll.is_open);
      pollsQuery.reload();
    } catch (cause) {
      setActionError(errorMessage(cause));
    } finally {
      setTogglingPoll(null);
    }
  };

  const submitVote = async (pollId: string) => {
    const optionId = selected[pollId];
    if (!optionId || voting) return;
    setVoting(pollId);
    setActionError(null);
    try {
      await voteInClassPoll(pollId, optionId);
      resultsQuery.reload();
    } catch (cause) {
      setActionError(errorMessage(cause));
    } finally {
      setVoting(null);
    }
  };

  return (
    <section className="class-tool card class-polls">
      <div className="class-tool-header">
        <div>
          <h2>نظرسنجی کلاس</h2>
          <p className="muted small">بازخورد سریع کلاس را همین جا بگیرید.</p>
        </div>
      </div>
      {isTeacher && <PollCreator question={question} options={options} saving={saving} onQuestionChange={setQuestion} onOptionChange={updateOption} onAddOption={addOption} onSubmit={submitPoll} />}
      {actionError && <p className="error-text small">{actionError}</p>}
      {pollsQuery.loading && <p className="muted small">در حال بارگذاری نظرسنجی ها...</p>}
      {!pollsQuery.loading && (pollsQuery.data ?? []).length === 0 && <p className="muted small">هنوز نظرسنجی ای برای این کلاس ثبت نشده است.</p>}
      <div className="poll-list">
        {(pollsQuery.data ?? []).map((poll) => (
          <PollCard key={poll.id} poll={poll} results={resultsByPoll.get(poll.id) ?? []} selected={selected[poll.id] ?? ''} voting={voting === poll.id} canManage={isTeacher} toggling={togglingPoll === poll.id} onSelect={(optionId) => setSelected((current) => ({ ...current, [poll.id]: optionId }))} onVote={() => submitVote(poll.id)} onToggleOpen={() => togglePollOpen(poll)} />
        ))}
      </div>
    </section>
  );
}

function PollCreator({ question, options, saving, onQuestionChange, onOptionChange, onAddOption, onSubmit }: { question: string; options: string[]; saving: boolean; onQuestionChange: (value: string) => void; onOptionChange: (index: number, value: string) => void; onAddOption: () => void; onSubmit: () => void }) {
  return (
    <div className="poll-creator">
      <h3>ساخت نظرسنجی جدید</h3>
      <label className="field">
        سوال
        <input value={question} onChange={(event) => onQuestionChange(event.target.value)} maxLength={500} placeholder="مثلا: سرعت تدریس امروز چطور بود؟" />
      </label>
      <div className="poll-options-editor">
        {options.map((option, index) => <input key={index} value={option} onChange={(event) => onOptionChange(index, event.target.value)} maxLength={250} placeholder={`گزینه ${index + 1}`} />)}
      </div>
      <div className="btn-row">
        <button type="button" className="btn btn-ghost btn-sm" onClick={onAddOption} disabled={options.length >= 8}>افزودن گزینه</button>
        <button type="button" className="btn btn-primary btn-sm" onClick={onSubmit} disabled={saving || !question.trim() || options.filter((option) => option.trim()).length < 2}>{saving ? 'در حال ثبت...' : 'انتشار نظرسنجی'}</button>
      </div>
    </div>
  );
}

function PollCard({ poll, results, selected, voting, canManage, toggling, onSelect, onVote, onToggleOpen }: { poll: ClassPoll; results: ClassPollResult[]; selected: string; voting: boolean; canManage: boolean; toggling: boolean; onSelect: (optionId: string) => void; onVote: () => void; onToggleOpen: () => void }) {
  const hasResults = results.length > 0;
  return (
    <article className="poll-card">
      <div className="poll-card-title">
        <h3>{poll.question}</h3>
        <span className={`badge ${poll.is_open ? 'badge-success' : 'badge-muted'}`}>{poll.is_open ? 'باز' : 'بسته'}</span>
      </div>
      <div className="poll-choice-list">
        {poll.options.map((option) => {
          const result = results.find((item) => item.option_id === option.id);
          return (
            <label key={option.id} className="poll-choice">
              <input type="radio" name={`poll-${poll.id}`} value={option.id} checked={selected === option.id} onChange={() => onSelect(option.id)} disabled={!poll.is_open} />
              <span className="poll-choice-label">{option.label}</span>
              {hasResults && <span className="poll-result"><span className="poll-result-bar"><span style={{ width: `${result?.percentage ?? 0}%` }} /></span><strong>{result?.percentage ?? 0}%</strong></span>}
            </label>
          );
        })}
      </div>
      <div className="btn-row">
        {poll.is_open && <button type="button" className="btn btn-outline btn-sm" onClick={onVote} disabled={voting || !selected}>{voting ? 'در حال ثبت...' : 'ثبت پاسخ'}</button>}
        {canManage && <button type="button" className="btn btn-ghost btn-sm" onClick={onToggleOpen} disabled={toggling}>{toggling ? 'در حال ذخیره...' : poll.is_open ? 'بستن نظرسنجی' : 'بازگشایی نظرسنجی'}</button>}
      </div>
      {hasResults && <p className="muted small">تعداد پاسخ ها: {results[0]?.total_votes ?? 0}</p>}
    </article>
  );
}

function groupResults(results: ClassPollResult[]): Map<string, ClassPollResult[]> {
  const grouped = new Map<string, ClassPollResult[]>();
  for (const result of results) grouped.set(result.poll_id, [...(grouped.get(result.poll_id) ?? []), result]);
  return grouped;
}
