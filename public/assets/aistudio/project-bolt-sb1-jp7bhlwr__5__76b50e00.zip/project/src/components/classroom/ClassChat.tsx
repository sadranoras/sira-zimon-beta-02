import { useEffect, useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { fetchClassMessages, sendClassMessage, type ClassMessage } from '../../lib/api/classroom';
import { errorMessage } from '../../lib/labels';
import { supabase } from '../../lib/supabase';
import { useAsyncData } from '../../lib/useAsyncData';

export function ClassChat({
  classId,
  title = 'گفتگوی کلاس',
  subtitle = 'پیام های این کلاس فقط برای اعضای آن نمایش داده می شود.',
}: {
  classId: string;
  title?: string;
  subtitle?: string;
}) {
  const { session } = useAuth();
  const { data, error, loading, reload } = useAsyncData(() => fetchClassMessages(classId), [classId]);
  const [body, setBody] = useState('');
  const [sending, setSending] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);

  useEffect(() => {
    const channel = supabase
      .channel(`class-chat-${classId}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'class_messages', filter: `class_id=eq.${classId}` }, reload)
      .subscribe();
    return () => {
      void supabase.removeChannel(channel);
    };
  }, [classId, reload]);

  const submit = async () => {
    if (!body.trim() || sending) return;
    setSending(true);
    setActionError(null);
    try {
      await sendClassMessage(classId, body);
      setBody('');
      reload();
    } catch (cause) {
      setActionError(errorMessage(cause));
    } finally {
      setSending(false);
    }
  };

  return (
    <section className="class-tool card class-chat">
      <div className="class-tool-header">
        <div>
          <h2>{title}</h2>
          <p className="muted small">{subtitle}</p>
        </div>
        <span className="live-dot">زنده</span>
      </div>
      <div className="chat-messages" aria-live="polite">
        {loading && <p className="muted small">در حال بارگذاری پیام ها...</p>}
        {!loading && !error && (data ?? []).length === 0 && <p className="muted small">هنوز پیامی ارسال نشده است.</p>}
        {error && <p className="error-text small">بارگذاری پیام ها انجام نشد.</p>}
        {(data ?? []).map((message) => <MessageBubble key={message.id} message={message} own={message.author_id === session?.user.id} />)}
      </div>
      {actionError && <p className="error-text small">{actionError}</p>}
      <div className="chat-compose">
        <textarea
          value={body}
          onChange={(event) => setBody(event.target.value)}
          placeholder="پیام یا پرسش خود را بنویسید..."
          maxLength={2000}
          rows={2}
          aria-label="پیام کلاس"
        />
        <button type="button" className="btn btn-primary" onClick={submit} disabled={sending || !body.trim()}>
          {sending ? 'در حال ارسال...' : 'ارسال پیام'}
        </button>
      </div>
    </section>
  );
}

function MessageBubble({ message, own }: { message: ClassMessage; own: boolean }) {
  return (
    <article className={`chat-message ${own ? 'chat-message-own' : ''}`}>
      <div className="chat-message-meta">
        <strong>{own ? 'شما' : 'شرکت کننده کلاس'}</strong>
        <time dateTime={message.created_at}>{new Intl.DateTimeFormat('fa-IR', { timeStyle: 'short' }).format(new Date(message.created_at))}</time>
      </div>
      <p>{message.body}</p>
    </article>
  );
}
