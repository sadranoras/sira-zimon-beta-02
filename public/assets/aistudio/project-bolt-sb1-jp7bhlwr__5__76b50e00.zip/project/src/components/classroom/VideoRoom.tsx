import { useEffect, useRef, useState } from 'react';
import { supabase } from '../../lib/supabase';

interface RemoteVideo { id: string; stream: MediaStream; }
interface SignalPayload {
  from: string; to: string; kind: 'offer' | 'answer' | 'ice';
  data: RTCSessionDescriptionInit | RTCIceCandidateInit;
}

function getIceServers(): RTCIceServer[] {
  const env = (import.meta as ImportMeta & { env: Record<string, string | undefined> }).env;
  const username = env.VITE_METERED_TURN_USERNAME?.trim();
  const credential = env.VITE_METERED_TURN_CREDENTIAL?.trim();
  const servers: RTCIceServer[] = [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun.relay.metered.ca:80' },
  ];
  if (username && credential) {
    servers.push({
      urls: [
        'turn:global.relay.metered.ca:80',
        'turn:global.relay.metered.ca:80?transport=tcp',
        'turn:global.relay.metered.ca:443',
        'turns:global.relay.metered.ca:443?transport=tcp',
      ],
      username, credential,
    });
  } else {
    console.warn('[class-video] Metered TURN credentials are missing; STUN only.');
  }
  return servers;
}

export function VideoRoom({ classId, audioOnly }: { classId: string; audioOnly: boolean }) {
  const localVideo = useRef<HTMLVideoElement>(null);
  const localStream = useRef<MediaStream | null>(null);
  const peers = useRef(new Map<string, RTCPeerConnection>());
  const participantId = useRef(crypto.randomUUID());
  const channelRef = useRef<ReturnType<typeof supabase.channel> | null>(null);
  const [remoteVideos, setRemoteVideos] = useState<RemoteVideo[]>([]);
  const [mediaError, setMediaError] = useState<string | null>(null);
  const [muted, setMuted] = useState(false);
  const [cameraOff, setCameraOff] = useState(audioOnly);
  const [connectionLabel, setConnectionLabel] = useState('در حال آماده‌سازی رسانه...');

  useEffect(() => {
    let active = true;
    const pendingCandidates = new Map<string, RTCIceCandidateInit[]>();
    const makingOffer = new Set<string>();
    const ignoredOffer = new Set<string>();
    const restartTimers = new Map<string, ReturnType<typeof setTimeout>>();

    void start();

    async function start() {
      let stream: MediaStream;
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: audioOnly ? false : { width: { ideal: 640, max: 640 }, height: { ideal: 360, max: 480 }, frameRate: { ideal: 20, max: 20 } },
          audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
        });
      } catch (error) {
        console.error('[class-video] getUserMedia failed:', error);
        try {
          stream = await navigator.mediaDevices.getUserMedia({ video: false, audio: true });
          setCameraOff(true);
          setMediaError('دوربین در دسترس نیست؛ کلاس با صدا ادامه پیدا می‌کند.');
        } catch (audioError) {
          console.error('[class-video] microphone failed:', audioError);
          setMediaError('دسترسی به میکروفن ممکن نیست. مجوز میکروفن مرورگر را بررسی کنید.');
          setConnectionLabel('میکروفن در دسترس نیست');
          return;
        }
      }
      if (!active) { stream.getTracks().forEach(t => t.stop()); return; }
      localStream.current = stream;
      if (localVideo.current) localVideo.current.srcObject = stream;

      const channel = supabase.channel(`class-video-${classId}`, { config: { presence: { key: participantId.current } } });
      channelRef.current = channel;
      channel
        .on('presence', { event: 'sync' }, () => {
          const ids = Object.keys(channel.presenceState()).filter(id => id !== participantId.current);
          setConnectionLabel(ids.length ? `حاضر در کلاس؛ ${ids.length} کاربر دیگر` : 'در انتظار ورود کاربر دیگر');
          ids.filter(id => participantId.current < id).forEach(id => void createOffer(id));
        })
        .on('presence', { event: 'join' }, ({ key }) => {
          if (key !== participantId.current && participantId.current < key) void createOffer(key);
        })
        .on('presence', { event: 'leave' }, ({ key }) => {
          const peer = peers.current.get(key);
          if (peer) peer.close();
          peers.current.delete(key);
          pendingCandidates.delete(key);
          setRemoteVideos(current => current.filter(video => video.id !== key));
        })
        .on('broadcast', { event: 'signal' }, ({ payload }) => void handleSignal(payload as SignalPayload))
        .subscribe(async status => {
          console.info('[class-video] Supabase channel:', status);
          if (status === 'SUBSCRIBED') {
            await channel.track({ joined_at: new Date().toISOString() });
            setConnectionLabel('به اتاق کلاس متصل شدی؛ منتظر هم‌کلاسی...');
          } else if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') {
            setConnectionLabel('ارتباط هماهنگی Supabase برقرار نیست');
          }
        });
    }

    async function sendSignal(payload: SignalPayload) {
      const channel = channelRef.current;
      if (!channel) { console.error('[class-video] channel not ready'); return; }
      const result = await channel.send({ type: 'broadcast', event: 'signal', payload });
      if (result !== 'ok') console.error('[class-video] signal send failed:', result, payload.kind);
    }

    async function createOffer(remoteId: string, iceRestart = false) {
      const peer = getPeer(remoteId);
      if (makingOffer.has(remoteId) || peer.signalingState !== 'stable') return;
      try {
        makingOffer.add(remoteId);
        const offer = await peer.createOffer(iceRestart ? { iceRestart: true } : undefined);
        if (!active || peer.signalingState !== 'stable') return;
        await peer.setLocalDescription(offer);
        if (peer.localDescription) await sendSignal({
          from: participantId.current, to: remoteId, kind: 'offer',
          data: peer.localDescription.toJSON(),
        });
      } catch (error) {
        console.error('[class-video] createOffer failed:', error);
        setConnectionLabel('ساخت درخواست تماس ناموفق بود');
      } finally { makingOffer.delete(remoteId); }
    }

    async function handleSignal(signal: SignalPayload) {
      if (!active || !signal || signal.to !== participantId.current) return;
      const peer = getPeer(signal.from);
      try {
        if (signal.kind === 'offer') {
          const collision = makingOffer.has(signal.from) || peer.signalingState !== 'stable';
          const polite = participantId.current > signal.from;
          if (collision && !polite) { ignoredOffer.add(signal.from); return; }
          if (collision && polite) await peer.setLocalDescription({ type: 'rollback' });
          await peer.setRemoteDescription(signal.data as RTCSessionDescriptionInit);
          await flushCandidates(signal.from, peer);
          const answer = await peer.createAnswer();
          await peer.setLocalDescription(answer);
          if (peer.localDescription) await sendSignal({
            from: participantId.current, to: signal.from, kind: 'answer',
            data: peer.localDescription.toJSON(),
          });
        } else if (signal.kind === 'answer') {
          if (peer.signalingState !== 'have-local-offer') {
            console.warn('[class-video] answer in unexpected state:', peer.signalingState); return;
          }
          await peer.setRemoteDescription(signal.data as RTCSessionDescriptionInit);
          await flushCandidates(signal.from, peer);
        } else if (signal.kind === 'ice') {
          if (ignoredOffer.has(signal.from)) return;
          const candidate = signal.data as RTCIceCandidateInit;
          if (peer.remoteDescription) await peer.addIceCandidate(candidate);
          else {
            const queue = pendingCandidates.get(signal.from) ?? [];
            queue.push(candidate); pendingCandidates.set(signal.from, queue);
          }
        }
      } catch (error) {
        console.error(`[class-video] handle ${signal.kind} failed:`, error);
        setConnectionLabel('خطا در تبادل اطلاعات تماس؛ کنسول مرورگر را بررسی کنید');
      }
    }

    async function flushCandidates(remoteId: string, peer: RTCPeerConnection) {
      const queue = pendingCandidates.get(remoteId) ?? [];
      pendingCandidates.delete(remoteId);
      for (const candidate of queue) {
        try { await peer.addIceCandidate(candidate); }
        catch (error) { console.warn('[class-video] queued ICE candidate rejected:', error); }
      }
    }

    function getPeer(remoteId: string): RTCPeerConnection {
      const existing = peers.current.get(remoteId);
      if (existing) return existing;
      const peer = new RTCPeerConnection({ iceServers: getIceServers(), iceTransportPolicy: 'all' });
      localStream.current?.getTracks().forEach(track => peer.addTrack(track, localStream.current as MediaStream));
      peer.onicecandidate = event => {
        if (event.candidate) {
          console.info('[class-video] local candidate:', event.candidate.type, event.candidate.protocol);
          void sendSignal({ from: participantId.current, to: remoteId, kind: 'ice', data: event.candidate.toJSON() });
        } else console.info('[class-video] ICE gathering complete:', remoteId);
      };
      peer.ontrack = event => {
        const stream = event.streams[0] ?? new MediaStream([event.track]);
        setRemoteVideos(current => current.some(v => v.id === remoteId)
          ? current.map(v => v.id === remoteId ? { id: remoteId, stream } : v)
          : [...current, { id: remoteId, stream }]);
      };
      peer.oniceconnectionstatechange = () => {
        console.info('[class-video] ICE state:', peer.iceConnectionState, remoteId);
        if (peer.iceConnectionState === 'checking') setConnectionLabel('در حال آزمایش مسیر اینترنت...');
        if (peer.iceConnectionState === 'connected' || peer.iceConnectionState === 'completed') setConnectionLabel('مسیر انتقال صدا و تصویر برقرار شد');
        if (peer.iceConnectionState === 'failed') setConnectionLabel('مسیر ارتباط ناموفق بود؛ در حال تلاش مجدد');
        if (peer.iceConnectionState === 'disconnected') setConnectionLabel('اتصال ناپایدار شده؛ منتظر بازیابی...');
      };
      peer.onconnectionstatechange = () => {
        console.info('[class-video] Peer state:', peer.connectionState, remoteId);
        if (peer.connectionState === 'connected') {
          const timer = restartTimers.get(remoteId);
          if (timer) clearTimeout(timer);
          restartTimers.delete(remoteId);
          setConnectionLabel('تماس صوتی و تصویری برقرار است');
        } else if (peer.connectionState === 'failed' && participantId.current < remoteId && !restartTimers.has(remoteId)) {
          const timer = setTimeout(() => {
            restartTimers.delete(remoteId);
            if (active && peer.connectionState !== 'closed') void createOffer(remoteId, true);
          }, 1500);
          restartTimers.set(remoteId, timer);
        }
      };
      peer.onicegatheringstatechange = () => console.info('[class-video] gathering:', peer.iceGatheringState, remoteId);
      peers.current.set(remoteId, peer);
      return peer;
    }

    return () => {
      active = false;
      restartTimers.forEach(clearTimeout);
      localStream.current?.getTracks().forEach(track => track.stop());
      localStream.current = null;
      peers.current.forEach(peer => peer.close());
      peers.current.clear();
      pendingCandidates.clear();
      if (channelRef.current) void supabase.removeChannel(channelRef.current);
      channelRef.current = null;
    };
  }, [audioOnly, classId]);

  const toggleMute = () => {
    const track = localStream.current?.getAudioTracks()[0];
    if (!track) return;
    track.enabled = !track.enabled;
    setMuted(!track.enabled);
  };
  const toggleCamera = () => {
    const track = localStream.current?.getVideoTracks()[0];
    if (!track) return;
    track.enabled = !track.enabled;
    setCameraOff(!track.enabled);
  };

  return (
    <section className="video-room card">
      <div className="video-room-stage">
        {remoteVideos.map(video => (
          <video key={video.id} className="remote-video" autoPlay playsInline
            ref={element => {
              if (element && element.srcObject !== video.stream) {
                element.srcObject = video.stream;
                void element.play().catch(error => console.warn('[class-video] autoplay blocked:', error));
              }
            }} />
        ))}
        {remoteVideos.length === 0 && <div className="video-waiting">
          <strong>اتاق کلاس آماده است</strong><span>با ورود سایر اعضا، تصویر آن‌ها اینجا نمایش داده می‌شود.</span>
        </div>}
        <video ref={localVideo} className="local-video" autoPlay muted playsInline />
      </div>
      {mediaError && <div className="alert alert-error">{mediaError}</div>}
      <div className="video-room-controls">
        <button type="button" className="btn btn-outline" onClick={toggleMute}>{muted ? 'فعال کردن میکروفن' : 'خاموش کردن میکروفن'}</button>
        {!audioOnly && (localStream.current?.getVideoTracks().length ?? 0) > 0 &&
          <button type="button" className="btn btn-outline" onClick={toggleCamera}>{cameraOff ? 'فعال کردن دوربین' : 'خاموش کردن دوربین'}</button>}
        <span className="badge badge-success">{connectionLabel}</span>
      </div>
      <p className="text-sm text-muted">برای استفاده از میکروفن و دوربین، سایت باید با HTTPS باز شود و مجوزهای مرورگر فعال باشند.</p>
    </section>
  );
}
