import { useState } from 'react';
import { deleteVideoNote, fetchVideoNotes, getVideoNoteUrl, uploadVideoNote, type VideoNote } from '../../lib/api/classVideoNotes';
import { safeDiagnostic } from '../../lib/diagnostics';
import { useAsyncData } from '../../lib/useAsyncData';
export function ClassVideoNotes({ classId, videoId, canManage }: { classId: string; videoId: string; canManage: boolean }) {
  const query = useAsyncData(() => fetchVideoNotes(classId, videoId), [classId, videoId]);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const upload = async (file?: File) => { if (!file || busy) return; setBusy(true); setMessage(null); try { await uploadVideoNote(classId, videoId, file); query.reload(); } catch (cause) { setMessage(safeDiagnostic('بارگذاری جزوه ویدیو', cause)); } finally { setBusy(false); } };
  const download = async (note: VideoNote) => { setMessage(null); try { window.open(await getVideoNoteUrl(note), '_blank', 'noopener,noreferrer'); } catch (cause) { setMessage(safeDiagnostic('دریافت جزوه ویدیو', cause)); } };
  const remove = async (note: VideoNote) => { if (busy || !window.confirm(`جزوه «${note.file_name}» حذف شود؟`)) return; setBusy(true); setMessage(null); try { await deleteVideoNote(note); query.reload(); } catch (cause) { setMessage(safeDiagnostic('حذف جزوه ویدیو', cause)); } finally { setBusy(false); } };
  return <section className="class-video-notes"><h3>جزوه‌های همین ویدیو</h3>
    {canManage && <label className="btn btn-outline btn-sm">{busy ? 'در حال انجام...' : 'افزودن جزوه'}<input type="file" hidden disabled={busy} onChange={(e) => { const file = e.target.files?.[0]; e.target.value = ''; void upload(file); }} /></label>}
    {message && <p className="alert alert-error" role="alert">{message}</p>}
    {query.loading && <p>در حال بارگذاری جزوه‌ها...</p>}
    {query.error && <p className="alert alert-error" role="alert">{query.error} <button type="button" onClick={query.reload}>تلاش دوباره</button></p>}
    {!query.loading && !query.error && (query.data ?? []).length === 0 && <p>برای این ویدیو جزوه‌ای ثبت نشده است</p>}
    {!query.error && <ul>{(query.data ?? []).map((note) => <li key={note.id}><span>{note.file_name}</span> <button type="button" onClick={() => void download(note)}>دانلود</button> {canManage && <button type="button" disabled={busy} onClick={() => void remove(note)}>حذف</button>}</li>)}</ul>}
    {canManage && <p className="muted small">برای حذف ویدیو ابتدا جزوه‌های مرتبط با آن را حذف کنید</p>}
  </section>;
}
