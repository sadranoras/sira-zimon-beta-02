import { useState } from 'react';
import { deleteClassFile, fetchClassFiles, getClassFileUrl, isVideoClassFile, uploadClassFile, type ClassFile } from '../../lib/api/classFiles';
import { formatDate } from '../../lib/dates';
import { errorMessage } from '../../lib/labels';
import { useAsyncData } from '../../lib/useAsyncData';

export function ClassFiles({ classId, canManage }: { classId: string; canManage: boolean }) {
  const { data, error, loading, reload } = useAsyncData(() => fetchClassFiles(classId), [classId]);
  const [busy, setBusy] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);
  const resources = (data ?? []).filter((file) => !isVideoClassFile(file));

  const handleUpload = async (file: File | undefined) => {
    if (!file || busy) return;
    setBusy(true);
    setActionError(null);
    try {
      await uploadClassFile(classId, file);
      reload();
    } catch (cause) {
      setActionError(errorMessage(cause));
    } finally {
      setBusy(false);
    }
  };

  const handleDownload = async (file: ClassFile) => {
    setActionError(null);
    try {
      const url = await getClassFileUrl(file.storage_path);
      window.open(url, '_blank', 'noopener,noreferrer');
    } catch (cause) {
      setActionError(errorMessage(cause));
    }
  };

  const handleDelete = async (file: ClassFile) => {
    if (busy || !window.confirm(`فایل «${file.file_name}» حذف شود؟`)) return;
    setBusy(true);
    setActionError(null);
    try {
      await deleteClassFile(file);
      reload();
    } catch (cause) {
      setActionError(errorMessage(cause));
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="card class-files">
      <div className="class-tool-header">
        <div>
          <h2>جزوه و منابع کلاس</h2>
          <p className="muted small">فایل‌های آموزشی در بخش ویدیوها یا جزوه‌ها نمایش داده می‌شوند. سقف و شرایط بارگذاری به سرویس ذخیره‌سازی بستگی دارد.</p>
        </div>
        {canManage && (
          <label className={`btn btn-primary btn-sm file-upload-button ${busy ? 'is-disabled' : ''}`}>
            {busy ? 'در حال بارگذاری...' : 'بارگذاری فایل'}
            <input
              type="file"
              hidden
              disabled={busy}
              onChange={(event) => {
                const file = event.target.files?.[0];
                event.target.value = '';
                void handleUpload(file);
              }}
            />
          </label>
        )}
      </div>
      {actionError && <p className="error-text small">{actionError}</p>}
      {loading && <p className="muted small">در حال بارگذاری فایل‌ها...</p>}
      {error && <p className="error-text small">فهرست فایل‌ها بارگذاری نشد: {error} <button type="button" onClick={reload}>تلاش دوباره</button></p>}
      {!loading && !error && resources.length === 0 && <p className="muted small">هنوز جزوه یا فایل آموزشی برای این کلاس بارگذاری نشده است.</p>}
      <ul className="class-file-list">
        {resources.map((file) => (
          <li key={file.id} className="class-file-item">
            <div>
              <strong>{file.file_name}</strong>
              <span className="muted small">{formatFileSize(file.size_bytes)} | {formatDate(file.created_at)}</span>
            </div>
            <div className="btn-row">
              <button type="button" className="btn btn-outline btn-sm" onClick={() => void handleDownload(file)}>دانلود</button>
              {canManage && <button type="button" className="btn btn-ghost btn-sm" onClick={() => void handleDelete(file)} disabled={busy}>حذف</button>}
            </div>
          </li>
        ))}
      </ul>
    </section>
  );
}

function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} بایت`;
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} کیلوبایت`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} مگابایت`;
}
