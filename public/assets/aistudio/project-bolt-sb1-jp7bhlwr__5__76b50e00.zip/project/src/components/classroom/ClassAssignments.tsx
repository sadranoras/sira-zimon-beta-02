import { useState, type FormEvent } from 'react';
import { PersianDateTimePicker } from '../PersianDateTimePicker';
import { createClassAssignment, fetchClassAssignmentFiles, fetchClassAssignmentSubmissions, fetchClassAssignments, fetchMyAssignmentSubmissions, getClassAssignmentFileUrl, submitClassAssignment, submitClassAssignmentWithFile, uploadClassAssignmentFile, type ClassAssignment, type ClassAssignmentFile, type ClassAssignmentSubmission } from '../../lib/api/classAssignments';
import { formatDate } from '../../lib/dates';
import { errorMessage } from '../../lib/labels';
import { useAsyncData } from '../../lib/useAsyncData';

export function ClassAssignments({ classId, canManage }: { classId: string; canManage: boolean }) {
  const query = useAsyncData(async () => {
    const assignments = await fetchClassAssignments(classId);
    const [files, submissions] = await Promise.all([
      fetchClassAssignmentFiles(assignments.map((assignment) => assignment.id)),
      assignments.length === 0 ? Promise.resolve([] as ClassAssignmentSubmission[]) : canManage ? fetchClassAssignmentSubmissions(classId) : fetchMyAssignmentSubmissions(assignments.map((assignment) => assignment.id)),
    ]);
    return { assignments, files, submissions };
  }, [classId, canManage]);
  const [title, setTitle] = useState(''); const [description, setDescription] = useState(''); const [dueAt, setDueAt] = useState('');
  const [drafts, setDrafts] = useState<Record<string, string>>({}); const [submissionFiles, setSubmissionFiles] = useState<Record<string, File | undefined>>({});
  const [saving, setSaving] = useState(false); const [submittingId, setSubmittingId] = useState<string | null>(null); const [uploadingId, setUploadingId] = useState<string | null>(null); const [actionError, setActionError] = useState<string | null>(null);

  const handleCreate = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault(); if (!title.trim() || saving) return;
    const deadline = dueAt ? new Date(dueAt) : null;
    if (deadline && Number.isNaN(deadline.getTime())) { setActionError('زمان مهلت معتبر نیست.'); return; }
    setSaving(true); setActionError(null);
    try { await createClassAssignment({ classId, title, description, dueAt: deadline ? deadline.toISOString() : null }); setTitle(''); setDescription(''); setDueAt(''); query.reload(); }
    catch (cause) { setActionError(errorMessage(cause)); } finally { setSaving(false); }
  };
  const handleSubmit = async (event: FormEvent<HTMLFormElement>, assignment: ClassAssignment, existing: ClassAssignmentSubmission | null) => {
    event.preventDefault(); const body = (drafts[assignment.id] ?? existing?.body ?? '').trim(); const file = submissionFiles[assignment.id];
    if ((!body && !file) || submittingId) return;
    setSubmittingId(assignment.id); setActionError(null);
    try {
      if (file) { const result = await submitClassAssignmentWithFile(assignment, body, file, existing?.storage_path ?? null); if (result.cleanupWarning) setActionError('پاسخ ثبت شد، اما پاک‌سازی فایل قبلی ناموفق بود؛ مدیر باید آن را بررسی کند.'); }
      else await submitClassAssignment(assignment.id, body);
      setSubmissionFiles((current) => ({ ...current, [assignment.id]: undefined })); query.reload();
    } catch (cause) { setActionError(errorMessage(cause)); } finally { setSubmittingId(null); }
  };
  const handleAttachmentUpload = async (assignment: ClassAssignment, file: File | undefined) => {
    if (!file || uploadingId) return; setUploadingId(assignment.id); setActionError(null);
    try { await uploadClassAssignmentFile(assignment, file); query.reload(); }
    catch (cause) { setActionError(errorMessage(cause)); } finally { setUploadingId(null); }
  };
  const handleDownload = async (file: Pick<ClassAssignmentFile, 'storage_path'> | Pick<ClassAssignmentSubmission, 'storage_path'>) => {
    if (!file.storage_path) return; setActionError(null);
    try { const url = await getClassAssignmentFileUrl(file.storage_path); window.open(url, '_blank', 'noopener,noreferrer'); }
    catch (cause) { setActionError(errorMessage(cause)); }
  };
  const assignments = query.data?.assignments ?? []; const files = query.data?.files ?? []; const submissions = query.data?.submissions ?? [];
  return <section className="panel-detail-card panel-homework-section">
    <div className="panel-detail-heading"><span className="panel-detail-icon icon-orange" aria-hidden="true">▤</span><div><h2>تکالیف کلاس</h2><p>تکالیف، فایل‌های پیوست و پاسخ‌های ثبت‌شده</p></div><span className="panel-count">{assignments.length}</span></div>
    {canManage && <form className="assignment-create-form" onSubmit={(event) => void handleCreate(event)}>
      <h3>ثبت تکلیف جدید</h3><label className="field">عنوان تکلیف<input value={title} onChange={(event) => setTitle(event.target.value)} required maxLength={250} /></label>
      <label className="field">توضیحات<textarea value={description} onChange={(event) => setDescription(event.target.value)} rows={3} maxLength={5000} /></label>
      <div className="field"><span>مهلت تحویل (اختیاری)</span><PersianDateTimePicker value={dueAt} onChange={setDueAt} /></div>
      <button type="submit" className="btn btn-primary btn-sm" disabled={saving || !title.trim()}>{saving ? 'در حال ثبت...' : 'ثبت تکلیف'}</button>
    </form>}
    {actionError && <p className="error-text small assignment-action-message">{actionError}</p>}
    {query.loading && <p className="muted small">در حال بارگذاری تکالیف...</p>}{query.error && <p className="error-text small">تکالیف بارگذاری نشدند: {query.error} <button type="button" onClick={query.reload}>تلاش دوباره</button></p>}
    {!query.loading && !query.error && assignments.length === 0 && <div className="panel-section-empty"><span aria-hidden="true">✓</span><p>هنوز تکلیفی برای این کلاس ثبت نشده است.</p></div>}
    <div className="assignment-list">{assignments.map((assignment) => {
      const assignmentSubmissions = submissions.filter((submission) => submission.assignment_id === assignment.id); const mySubmission = canManage ? null : assignmentSubmissions[0] ?? null;
      const assignmentFiles = files.filter((file) => file.assignment_id === assignment.id); const closed = Boolean(assignment.due_at && Date.now() >= Date.parse(assignment.due_at));
      return <article className="assignment-card" key={assignment.id}>
        <div className="assignment-card-heading"><h3>{assignment.title}</h3>{assignment.due_at && <span className="muted small">مهلت: {formatDate(assignment.due_at)}</span>}</div>
        {assignment.description && <p className="assignment-description">{assignment.description}</p>}
        <div className="assignment-files"><div className="assignment-files-heading"><strong>فایل‌های پیوست استاد</strong>{canManage && <label className={`btn btn-outline btn-sm assignment-file-picker ${uploadingId === assignment.id ? 'is-disabled' : ''}`}>
          {uploadingId === assignment.id ? 'در حال بارگذاری...' : 'افزودن فایل'}<input type="file" hidden disabled={uploadingId === assignment.id} onChange={(event) => { const file = event.target.files?.[0]; event.target.value = ''; void handleAttachmentUpload(assignment, file); }} />
        </label>}</div>
          {assignmentFiles.length === 0 ? <p className="muted small">فایلی پیوست نشده است.</p> : <ul className="assignment-file-list">{assignmentFiles.map((file) => <li key={file.id}><span>{file.file_name} <small className="muted">({formatFileSize(file.size_bytes)})</small></span><button type="button" className="btn btn-ghost btn-sm" onClick={() => void handleDownload(file)}>دانلود</button></li>)}</ul>}
        </div>
        {canManage ? <div className="assignment-submissions"><strong>پاسخ‌های ثبت‌شده: {assignmentSubmissions.length}</strong>
          {assignmentSubmissions.length === 0 ? <p className="muted small">هنوز پاسخی ارسال نشده است.</p> : assignmentSubmissions.map((submission: ClassAssignmentSubmission) => <div className="assignment-submission" key={submission.id}>
            <div className="assignment-submission-meta"><strong>{submission.student_name || 'دانش‌آموز'}</strong><time dateTime={submission.submitted_at}>{formatDate(submission.submitted_at)}</time></div>
            {submission.body && <p>{submission.body}</p>}{submission.storage_path && submission.file_name && <div className="assignment-submission-file"><span>{submission.file_name} <small className="muted">({formatFileSize(submission.size_bytes ?? 0)})</small></span><button type="button" className="btn btn-outline btn-sm" onClick={() => void handleDownload(submission)}>دانلود فایل پاسخ</button></div>}
          </div>)}
        </div> : mySubmission ? <div className="assignment-own-submission"><strong>پاسخ شما ثبت شده</strong>{mySubmission.body && <p className="assignment-description">{mySubmission.body}</p>}
          {mySubmission.storage_path && mySubmission.file_name && <div className="assignment-submission-file"><span>{mySubmission.file_name} <small className="muted">({formatFileSize(mySubmission.size_bytes ?? 0)})</small></span><button type="button" className="btn btn-outline btn-sm" onClick={() => void handleDownload(mySubmission)}>دانلود فایل شما</button></div>}
          {closed ? <span className="muted small">مهلت تحویل به پایان رسیده است.</span> : <SubmissionForm existing={mySubmission} body={drafts[assignment.id] ?? mySubmission.body} file={submissionFiles[assignment.id]} busy={submittingId === assignment.id} onBodyChange={(value) => setDrafts((current) => ({ ...current, [assignment.id]: value }))} onFileChange={(file) => setSubmissionFiles((current) => ({ ...current, [assignment.id]: file }))} onSubmit={(event) => void handleSubmit(event, assignment, mySubmission)} />}
        </div> : closed ? <p className="muted small">مهلت تحویل این تکلیف به پایان رسیده است.</p> : <SubmissionForm existing={null} body={drafts[assignment.id] ?? ''} file={submissionFiles[assignment.id]} busy={submittingId === assignment.id} onBodyChange={(value) => setDrafts((current) => ({ ...current, [assignment.id]: value }))} onFileChange={(file) => setSubmissionFiles((current) => ({ ...current, [assignment.id]: file }))} onSubmit={(event) => void handleSubmit(event, assignment, null)} />}
      </article>;
    })}</div>
  </section>;
}
function SubmissionForm({ existing, body, file, busy, onBodyChange, onFileChange, onSubmit }: { existing: ClassAssignmentSubmission | null; body: string; file: File | undefined; busy: boolean; onBodyChange: (value: string) => void; onFileChange: (file: File | undefined) => void; onSubmit: (event: FormEvent<HTMLFormElement>) => void; }) {
  const hasContent = Boolean(body.trim() || file);
  return <form className="assignment-submit-form assignment-file-submit-form" onSubmit={onSubmit}>
    <label className="field">پاسخ متنی (اختیاری برای تحویل فایل)<textarea value={body} onChange={(event) => onBodyChange(event.target.value)} rows={3} maxLength={10000} placeholder="می‌توانید متن، فایل یا هر دو را ارسال کنید" /></label>
    <label className="field">فایل پاسخ (اختیاری)<input type="file" onChange={(event) => { onFileChange(event.target.files?.[0]); event.target.value = ''; }} /></label>
    {file && <span className="muted small">فایل انتخاب‌شده: {file.name}</span>}
    <button type="submit" className="btn btn-primary btn-sm" disabled={busy || !hasContent}>{busy ? 'در حال ذخیره...' : existing ? 'ذخیره پاسخ' : 'ارسال پاسخ'}</button>
  </form>;
}
function formatFileSize(bytes: number): string { if (bytes < 1024) return `${bytes} بایت`; if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} کیلوبایت`; return `${(bytes / (1024 * 1024)).toFixed(1)} مگابایت`; }
