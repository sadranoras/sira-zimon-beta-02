import { useState, type FormEvent } from 'react';
import { createClassSession } from '../../lib/api/classSessions';
import { fromDateTimeInput } from '../../lib/dates';
import { errorMessage } from '../../lib/labels';

function defaultStart(): string {
  const date = new Date(Date.now() + 24 * 60 * 60_000);
  date.setMinutes(0, 0, 0);
  const pad = (value: number) => String(value).padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

export function ClassSessionForm({ classId, onSaved, onCancel }: { classId: string; onSaved: () => void; onCancel: () => void }) {
  const [title, setTitle] = useState('');
  const [startsAt, setStartsAt] = useState(defaultStart);
  const [endsAt, setEndsAt] = useState(defaultStart);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!title.trim()) return setError('عنوان جلسه را وارد کنید.');
    if (!startsAt || !endsAt || new Date(endsAt) <= new Date(startsAt)) return setError('زمان پایان جلسه باید بعد از زمان شروع باشد.');
    const start = fromDateTimeInput(startsAt);
    const end = fromDateTimeInput(endsAt);
    if (!start || !end) return setError('زمان جلسه معتبر نیست.');

    setSaving(true);
    setError(null);
    try {
      await createClassSession(classId, { title, startsAt: start, endsAt: end });
      onSaved();
    } catch (cause) {
      setError(errorMessage(cause));
    } finally {
      setSaving(false);
    }
  };

  return (
    <form className="card form session-form" onSubmit={submit}>
      <label className="field"><span>عنوان جلسه</span><input required maxLength={200} value={title} onChange={(event) => setTitle(event.target.value)} placeholder="مثلا جلسه ۲۹ - معادلات درجه دوم" /></label>
      <div className="form-grid">
        <label className="field"><span>زمان شروع</span><input type="datetime-local" required value={startsAt} onChange={(event) => setStartsAt(event.target.value)} /></label>
        <label className="field"><span>زمان پایان</span><input type="datetime-local" required value={endsAt} onChange={(event) => setEndsAt(event.target.value)} /></label>
      </div>
      {error && <div className="alert alert-error">{error}</div>}
      <div className="btn-row">
        <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'در حال ذخیره...' : 'افزودن جلسه'}</button>
        <button type="button" className="btn btn-ghost" onClick={onCancel} disabled={saving}>انصراف</button>
      </div>
    </form>
  );
}
