import { useEffect,useState } from 'react';
import { ClassVideoNotes } from './ClassVideoNotes';
import { safeDiagnostic } from '../../lib/diagnostics';
import { deleteClassFile,fetchClassFiles,getClassFileUrl,isVideoClassFile,uploadClassFile,type ClassFile } from '../../lib/api/classFiles';
import { formatDate } from '../../lib/dates';
import { errorMessage } from '../../lib/labels';
import { useAsyncData } from '../../lib/useAsyncData';
const VIDEO_MIME_BY_EXTENSION:Record<string,string>={mp4:'video/mp4',m4v:'video/x-m4v',webm:'video/webm',mov:'video/quicktime',ogv:'video/ogg',ogg:'video/ogg',avi:'video/x-msvideo',mkv:'video/x-matroska',mpeg:'video/mpeg',mpg:'video/mpeg','3gp':'video/3gpp'};
const MIME_ALIASES_BY_EXTENSION:Record<string,string[]>={mkv:['application/x-matroska'],avi:['application/x-msvideo'],mp4:['application/mp4']};
function resolveVideoMimeType(file:File):string|null {
 const reported=file.type.trim().toLowerCase(); if(reported.startsWith('video/')) return reported;
 const extension=file.name.split('.').pop()?.toLowerCase()??''; const fallback=VIDEO_MIME_BY_EXTENSION[extension];
 if(!fallback) return null;
 if(!reported||reported==='application/octet-stream'||reported==='binary/octet-stream'||(MIME_ALIASES_BY_EXTENSION[extension]??[]).includes(reported)) return fallback;
 return null;
}
export function ClassVideos({classId,classTitle,canManage}:{classId:string;classTitle:string;canManage:boolean}) {
 const {data,error,loading,reload}=useAsyncData(async()=>(await fetchClassFiles(classId)).filter(isVideoClassFile),[classId]);
 const [selected,setSelected]=useState<ClassFile|null>(null); const [url,setUrl]=useState<string|null>(null); const [videoError,setVideoError]=useState<string|null>(null); const [busy,setBusy]=useState(false);
 useEffect(()=>{let cancelled=false;setUrl(null);setVideoError(null);if(selected)getClassFileUrl(selected.storage_path,3600).then(value=>{if(!cancelled)setUrl(value);}).catch(cause=>{if(!cancelled)setVideoError(safeDiagnostic('دریافت لینک فایل',cause));});return()=>{cancelled=true;};},[selected?.storage_path]);
 useEffect(()=>{setSelected(null);setUrl(null);},[classId]);
 useEffect(()=>{if(!loading&&!error&&selected&&!(data??[]).some(file=>file.id===selected.id))setSelected(null);},[data,loading,error,selected]);
 const upload=async(file?:File)=>{if(!file||busy)return;const mimeType=resolveVideoMimeType(file);if(!mimeType||file.size===0){setVideoError(file.size===0?'فایل خالی است؛ یک فایل ویدیویی غیرخالی انتخاب کنید':file.type&&!file.type.toLowerCase().includes('octet-stream')?'نوع فایل ویدیویی شناخته نشد؛ فرمت MP4، WebM، MOV، AVI یا MKV انتخاب کنید':'مرورگر نوع فایل را تشخیص نداد؛ پسوند فایل باید یکی از فرمت‌های ویدیویی پشتیبانی‌شده باشد');return;}setBusy(true);setVideoError(null);try{await uploadClassFile(classId,file,mimeType);reload();}catch(cause){setVideoError(errorMessage(cause));}finally{setBusy(false);}};
 const remove=async(file:ClassFile)=>{if(busy||!window.confirm(`ویدیوی «${file.file_name}» حذف شود؟`))return;setBusy(true);setVideoError(null);try{await deleteClassFile(file);if(selected?.id===file.id)setSelected(null);reload();}catch(cause){setVideoError(errorMessage(cause));}finally{setBusy(false);}};
 return <section className="class-video-workspace" dir="rtl"><header className="class-video-banner"><div><h2>ویدیوهای کلاس</h2><span>{classTitle}</span></div>{canManage&&<label className="btn btn-outline file-upload-button">{busy?'در حال انجام...':'افزودن ویدیو'}<input type="file" accept="video/*,.mp4,.m4v,.webm,.mov,.ogv,.avi,.mkv,.mpeg,.mpg,.3gp" hidden disabled={busy} onChange={e=>{const f=e.target.files?.[0];e.target.value='';void upload(f);}}/></label>}</header>
 {videoError&&<p className="alert alert-error" role="alert">{videoError}</p>}
 <div className="class-video-layout"><div className="class-video-main"><div className="class-video-stage">{selected?<><h3>{selected.file_name}</h3>{url?<video className="class-video-screen" controls preload="metadata" playsInline src={url}/>:!videoError&&<p>در حال آماده‌سازی پخش...</p>}</>:<div className="class-video-placeholder"><span aria-hidden="true">▶</span><h3>یک ویدیو انتخاب کن</h3><p>برای شروع، یک ویدیو از فهرست انتخاب کن</p>{(data??[]).length>0&&<button type="button" className="btn btn-outline" onClick={()=>setSelected((data??[])[0])}>پخش اولین ویدیو</button>}</div>}</div>{selected&&selected.class_id===classId&&<ClassVideoNotes key={`${classId}:${selected.id}`} classId={classId} videoId={selected.id} canManage={canManage}/>}</div>
 <aside className="class-video-library"><h3>فهرست ویدیوها</h3><p className="muted small">{(data??[]).length.toLocaleString('fa-IR')} ویدیو</p>{loading&&<p>در حال بارگذاری...</p>}{error&&<p className="error-text">{error} <button type="button" onClick={reload}>تلاش دوباره</button></p>}{!loading&&!error&&(data??[]).length===0&&<p className="muted">هنوز ویدیویی اضافه نشده است</p>}{(data??[]).map(file=><div className="class-video-row" key={file.id}><button type="button" className="class-video-select" aria-pressed={selected?.id===file.id} onClick={()=>setSelected(file)}><strong>{file.file_name}</strong><span>{formatDate(file.created_at)}</span></button>{canManage&&<button type="button" className="btn btn-ghost btn-sm" disabled={busy} onClick={()=>void remove(file)}>حذف</button>}</div>)}</aside></div></section>;
}
