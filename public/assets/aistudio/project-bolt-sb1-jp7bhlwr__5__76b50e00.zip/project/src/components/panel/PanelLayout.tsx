import { NavLink, Outlet } from 'react-router-dom';

const panelLinks = [
  { to: '/panel', label: 'صفحه شخصی', end: true },
  { to: '/panel/messages', label: 'پیام ها', end: false },
  { to: '/panel/classes', label: 'کلاس ها', end: false },
  { to: '/panel/exams', label: 'آزمون ها', end: false },
  { to: '/panel/in-person-exams', label: 'آزمون حضوری', end: false },
  { to: '/panel/calendar', label: 'تقویم برنامه ها', end: false },
  { to: '/panel/wallet', label: 'کیف پول', end: false },
  { to: '/panel/stars', label: 'ستاره ها', end: false },
  { to: '/panel/coins', label: 'سکه', end: false },
  { to: '/panel/support', label: 'ارتباط با تک رقمی', end: false },
  { to: '/panel/invoices', label: 'فاکتورها', end: false },
  { to: '/panel/attendance', label: 'حضور و غیاب', end: false },
  { to: '/panel/profile', label: 'پروفایل', end: false },
];

export function PanelLayout() {
  return (
    <div className="container panel-layout">
      <nav className="card panel-nav" aria-label="بخش های پنل کاربری">
        <div className="panel-nav-brand">
          <span className="panel-brand-mark">ز</span>
          <div><strong>پنل کاربری</strong><span>زیمون</span></div>
        </div>
        <p className="panel-nav-label">دسترسی سریع</p>
        {panelLinks.map((link) => (
          <NavLink key={link.to} to={link.to} end={link.end}>
            <span className="panel-nav-line" />
            {link.label}
          </NavLink>
        ))}
      </nav>
      <div className="panel-content"><Outlet /></div>
    </div>
  );
}
