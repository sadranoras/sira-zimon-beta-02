import { Link } from 'react-router-dom';
import type { ClassItem } from '../lib/types';
import { levelLabels } from '../lib/labels';
import { formatDate } from '../lib/dates';

const weekdayLabels: Record<number, string> = { 1: 'دوشنبه', 2: 'سه شنبه', 3: 'چهارشنبه', 4: 'پنجشنبه', 5: 'جمعه', 6: 'شنبه', 7: 'یکشنبه' };

export function ClassCard({ item }: { item: ClassItem }) {
  return (
    <article className="card class-card">
      <div className="class-cover">
        {item.cover_image_url ? <img src={item.cover_image_url} alt={item.title} loading="lazy" /> : null}
      </div>
      <div className="class-card-body">
        <div className="class-meta">
          {item.categories && <span className="badge badge-primary">{item.categories.name}</span>}
          <span className="badge">{levelLabels[item.level]}</span>
        </div>
        <h3>{item.title}</h3>
        <p className="muted">استاد: {item.instructor_name || 'به زودی اعلام می شود'}</p>
        <p className="muted small">{item.schedule_kind === 'weekly' ? `هر هفته، ${item.schedule_weekdays?.map((day) => weekdayLabels[day]).join('، ') ?? ''}، ساعت ${item.schedule_start_time?.slice(0, 5) ?? ''} (${item.schedule_time_zone ?? 'منطقه زمانی نامشخص'})` : `شروع: ${formatDate(item.starts_at, item.schedule_time_zone)}`}</p>
        <Link to={`/classes/${item.id}`} className="btn btn-outline btn-block">مشاهده جزئیات</Link>
      </div>
    </article>
  );
}
